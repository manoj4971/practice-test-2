#!/bin/bash

#ODBC setup
pwsh /mnt/win/OneClickTools/wget-files.ps1 -url "https://downloads.cloudera.com/connectors/HDXSimbaHive_ODBC_2.6.5.1005/hive-odbc-native-2.6.5.1005-1.x86_64.rpm"
yum install unixODBC* -y
yum install cyrus-sasl* -y
rpm -ivh hive-odbc-native-2.6.5.1005-1.x86_64.rpm

IP=$(hostname -I|cut -d" " -f 1)
yes | cp odbc.ini /usr/lib/hive/lib/native/hiveodbc/Setup/
sed -i "s|{hadoopip}|$IP|g" /usr/lib/hive/lib/native/hiveodbc/Setup/odbc.ini

yes | cp /usr/lib/hive/lib/native/hiveodbc/Setup/odbcinst.ini /etc/
yes | cp /usr/lib/hive/lib/native/hiveodbc/Setup/odbc.ini /etc/