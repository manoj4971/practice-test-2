#!/bin/bash

#######Install nodejs

sudo yum clean all 
yum install -y gcc-c++ make
yum -y install nodejs
