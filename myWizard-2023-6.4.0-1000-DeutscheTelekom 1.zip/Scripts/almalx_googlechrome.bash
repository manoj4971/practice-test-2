#!/bin/bash
#######Install googlechrome
cd /tmp
wget https://dl.google.com/linux/direct/google-chrome-stable_current_x86_64.rpm
sudo yum install libdrm -y
sudo yum install lib* --nobest -y
sudo yum install liberation-fonts -y
sudo yum install xdg-utils -y
sudo yum install libvu* -y
sudo yum install libgbm -y
sudo yum install ./google-chrome-stable_current_*.rpm -y
