Clear-Host
Remove-Item -Path /var/Scanfiles/*.csv -Force
$Folder = $_.PSIsContainer
$Type = $_.Extension

$ip=$(hostname -I|cut -d" " -f 1)

[string[]]$volumes = $("/var/www","/mnt/myWizard-Phoenix")
$destination = $( "/var/Scanfiles/"+ $ip +  "_scanfiles_"+ (Get-Date -Format "yyyy-MM-dd"))
    $filepath = $($destination + ".csv")


foreach($drive in $volumes) {


            $found = Get-ChildItem -Path $drive -Recurse -File -ErrorAction SilentlyContinue |
                        Where-Object {
                                        $_.Extension -in '.doc', '.xlsx', '.xls', '.pdf', '.docx', '.csv', '.json', '.xml' -and(
                                            $_.Name -notmatch ".dll" -or
                                            $_.Name -notmatch ".exe" -or



                                            $_.FullName -notmatch "AWS SDK for .NET" -or
                                            $_.FullName -notmatch "LCU" -or
                                            $_.FullName -notmatch "WinSxS" -or
                                            $_.FullName -notmatch "ServiceProfiles" -or
                                            $_.FullName -notmatch "Openxml")
                                        } |
                        Select-Object  Name,Directory,Length,@{Name="Owner";Expression={(stat -c %U $_.Fullname)}},@{N="FileType";E={$_.Extension.ToLower()}},@{Name="ModifiedTime";Expression={(stat -c ‘%y’ $_.Fullname)}},@{Name="AccessTime";Expression={(stat -c ‘%x’ $_.Fullname)}},CreationTime
    $found |  ConvertTo-Csv | Add-Content -Path $filepath


}
