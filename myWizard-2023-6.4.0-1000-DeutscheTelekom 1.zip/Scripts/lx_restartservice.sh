#!/bin/bash
for f in myWizard*.service;  do systemctl restart ${f}; done