#!/bin/bash

######Install zip and unzip utilities
yum -y install dos2unix