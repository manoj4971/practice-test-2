﻿param (
    $mountUserName = "",
    $mountPassword = "",
    $ipAddress = "",
    $AdminUser = "",
    $AdminPassword = "",
    $smbPath = "",
    $mntPath = ""
)


Configuration LinuxMountDrive
{
    param (
        $mntPath,
        $smbPath,
        $nxLogFile
    )
    Import-DscResource -Module nx
	   
    Node $ipAddress {
        nxScript "LinuxMountDrive" {
            GetScript  = @"
#!/bin/pwsh
Write-Host "mounting drive"
"@
            TestScript = @"
#!/bin/pwsh
Write-Host "mounting drive test"
exit 1
"@
            SetScript  = @"
#!/bin/pwsh
New-Item -ItemType Directory -Path $mntPath -Force -ErrorAction SilentlyContinue | Out-Null
chmod -R 777 $mntPath
#mount -t cifs '$smbPath' $mntPath -o username=$mountUserName,password=$("'" + $mountPassword + "'"),vers=2.0,guest,noacl,noperm,rw
mount -t cifs '$smbPath' -o username=$mountUserName,password=$mountPassword,vers=2.0,guest,noacl,noperm,rw $mntPath

Add-Content -Path $nxLogFile -Value "New-Item -ItemType Directory -Path $mntPath -Force -ErrorAction SilentlyContinue | Out-Null"
Add-Content -Path $nxLogFile -Value "chmod -R 777 $mntPath"
Add-Content -Path $nxLogFile -Value "mount -t cifs $smbPath $mntPath -o username=$mountUserName,password=$("'" + $mountPassword + "'"),vers=2.0,guest,noacl,noperm,rw"
Add-Content -Path $nxLogFile -Value ""
"@
        }
    }
}

function Init {
    param (
    )
    begin {
        Clear-Host
        [securestring]$password = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
        $credentials = New-Object System.Management.Automation.PSCredential ($AdminUser, $password)
        $sessOpt = New-CimSessionOption -UseSsl -SkipCACheck -SkipCNCheck -SkipRevocationCheck
        $session = New-CimSession -Credential $credentials -ComputerName $ipAddress -Port 5986 -Authentication basic -SessionOption $sessOpt -OperationTimeoutSec 900

        $thisPath = $(Split-Path -Path $PSCommandPath -Parent)
        $MOFPath = $($thisPath + "\MOF\")
        $sourceIP = (Get-NetIPAddress | Where-Object {$_.AddressFamily -eq "IPv4" -and $_.InterfaceAlias -match "Ethernet"}).IPAddress
        $smbPath = $smbPath.Replace([System.IO.Path]::GetPathRoot($smbPath),"\\"+$sourceIP+"\")
		$smbPath = $smbPath -replace "\\", "/"

        $logFile = $("DSCLog_" + $ipAddress + "_" + (Get-Date -Format "yyyyMMdd_HHmm") + ".txt")
        $logPath = $($thisPath + "\Logs\" + $logFile)
        Start-Transcript -Path $logPath -Force | Out-Null
    }
    process {
        New-Item -ItemType Directory -Path $MOFPath -Force -ErrorAction SilentlyContinue | Out-Null
        Write-Host "Starting for server " $ipAddress -BackgroundColor DarkGreen
        Write-Host
        Stop-DscConfiguration -Force -ErrorAction SilentlyContinue -InformationAction SilentlyContinue -WarningAction SilentlyContinue | Out-Null
        Remove-DscConfigurationDocument -Force -Stage Current -ErrorAction SilentlyContinue -InformationAction SilentlyContinue -WarningAction SilentlyContinue | Out-Null
        Remove-DscConfigurationDocument -Force -Stage Pending -ErrorAction SilentlyContinue -InformationAction SilentlyContinue -WarningAction SilentlyContinue | Out-Null
        Remove-DscConfigurationDocument -Force -Stage Previous -ErrorAction SilentlyContinue -InformationAction SilentlyContinue -WarningAction SilentlyContinue | Out-Null

        Write-Host "This Path : "$thisPath -BackgroundColor DarkCyan
        Write-Host "MOF Path : "$MOFPath -BackgroundColor DarkCyan
        Write-Host "SMB Path : "$smbPath -BackgroundColor DarkCyan
        Write-Host "Mount Path : "$mntPath -BackgroundColor DarkCyan
        Write-Host "Log Path : "$logPath -BackgroundColor DarkCyan

        Write-Host "Mounting drive..." -BackgroundColor Yellow -ForegroundColor Black
        LinuxMountDrive -OutputPath $MOFPath -mntPath $mntPath -smbPath $smbPath -nxLogFile $logPath | Out-Null
        Start-DscConfiguration -Path $MOFPath -CimSession $session -Wait -Force -ErrorAction Stop
        Move-Item -Path $($MOFPath + "\" + $ipAddress + ".mof") -Destination $($MOFPath + "\LinuxMountDrive_" + $ipAddress + ".mof") -Force
        Write-Host "Mounting drive complete..."
    }
    end {
        Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
    }
}


Init