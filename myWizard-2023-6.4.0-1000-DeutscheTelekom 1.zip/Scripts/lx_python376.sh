######Install python3.7
# 1 set up env

yum-config-manager --enable offline.repo

yum --disablerepo=* --enablerepo=offline.repo install -y install gcc gcc-c++ openssl-devel bzip2-devel sqlite-devel zlib-devel libcurl-devel sqlite libffi libffi-devel

# 2 Download python to /tmp
cd /mnt/win/OneClickTools/Softwares/zip

# 3 extract 
tar -xzf Python-3.7.6.tgz

# 4 install python
cd Python-3.7.6

# compile python source
./configure --enable-optimizations

# Install postgresql-devel
sudo yum install -y python-devel postgresql-devel

# install
make altinstall

export PATH=$PATH:/usr/local/bin

ln -s /usr/local/bin/python3.7 /usr/bin/python3.7

# check installation
python3.7 --version