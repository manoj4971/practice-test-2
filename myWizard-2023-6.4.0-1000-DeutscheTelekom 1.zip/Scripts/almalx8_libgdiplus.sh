#!/bin/bash

######Install libgdiplus
yum -y install libgdiplus
