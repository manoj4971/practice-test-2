#!/bin/bash


if ! which python3.7 > /dev/null 2>&1; then
######Install python3.7
# 1 set up env
yum -y install gcc openssl-devel bzip2-devel sqlite-devel zlib-devel libcurl-devel sqlite libffi libffi-devel

# 2 Download python to /tmp
cd /tmp && curl -O https://www.python.org/ftp/python/3.7.6/Python-3.7.6.tgz

# 3 extract 
tar -xzf Python-3.7.6.tgz

# 4 install python
cd Python-3.7.6

# compile python source
./configure --enable-optimizations

# install
make altinstall

export PATH=$PATH:/usr/local/bin

ln -s /usr/local/bin/python3.7 /usr/bin/python3.7

#required for postgres installation
yum install python-devel -y

wget https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
yum localinstall --nogpgcheck epel-release-latest-7.noarch.rpm

yum install -y https://download.postgresql.org/pub/repos/yum/reporpms/EL-7-x86_64/pgdg-redhat-repo-latest.noarch.rpm

wget https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
yum localinstall --nogpgcheck llvm5.0-devel

wget http://mirror.centos.org/centos/7/sclo/x86_64/rh/Packages/l/llvm-toolset-7-clang-5.0.1-4.el7.x86_64.rpm
yum localinstall --nogpgcheck llvm-toolset-7-clang-5.0.1-4.el7.x86_64.rpm

wget https://download.postgresql.org/pub/repos/yum/12/redhat/rhel-7-x86_64/postgresql12-devel-12.7-1PGDG.rhel7.x86_64.rpm
yum localinstall --nogpgcheck postgresql12-devel-12.7-1PGDG.rhel7.x86_64.rpm

sudo yum -y install gcc

sudo yum install gcc-c++

# check installation
python3.7 --version
fi

