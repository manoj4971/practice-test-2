#!/bin/bash

######Install zip and unzip utilities
yum -y install zip
yum -y install unzip