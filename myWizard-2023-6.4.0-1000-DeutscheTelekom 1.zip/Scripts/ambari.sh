#!/bin/bash
#
##################################################################################
# This script is created to perform MySQL, Ambari installation and HDP creation
# Created by Shabana
# MySQL Version 5.7
# Ambari Version 2.7.4.0
# HDP Version 3.1.4
##################################################################################
# Setting variables to get hostame
hostname=$(hostname)

# Performing MySQL installation and setup MySQL user
cp -rf hadoop /home/centos/
cd /home/centos/hadoop/
sudo chmod -R 777 .
echo "*****************************Performing MySQL installation and setup MySQL user*****************************" 
sudo bash -x mysql_installation.sh 

# Performing ambari Installation
echo "*****************************Performing ambari Installation*****************************" 
sudo bash -x ambari_setup.sh 

######################################################################################################
# Performing HDP Creation
# Usage: $./create_cluster.sh <ambari_hostname> <blueprint_name> <target_cluster_name>
# Arguments:
#  ambari_hostname : Our hostname with port 8090 Eg:-hostname.domain.local:8090
#  blueprint_name
#  target_cluster_name
######################################################################################################
echo "*****************************Performing HDP Creation*****************************" 
sudo bash -x create_cluster_via_blueprint.sh "http://$hostname:8090" Hadoop HadoopCluster 