﻿param(
    [string]$packagePath = 'C:\Accenture\myWizard\Apps\Mongo.DataLoader',
    [string]$MongoDatabaseName = 'mywizard-phoenix',
	[string]$MongoDatabaseIP = '192.168.16.164',
	[string]$MongoDatabaseHost = 'EC2AMAZ-GJUDE8I.MYWIZARD360.LOCAL:27017',
    [string]$IsReplicated = 'true',
    [string]$IsDropDatabase = 'true',
    [string]$IsAuthenticated = 'true',
    [string]$DBUserName = 'admin',
    [string]$DBPassword = 'password',
    [string]$IsExecPSScript = 'true',
    [string]$ReplicationPartners = '',
    [string]$ClientCustomizationPath='\\192.168.16.100\Accenture\\myWizard\\myWizard-Installer-BOM-PROD-01.00.201903\\DataLoader',
    [string]$LocalClientCustomizationPath='C:\Accenture\myWizard\myWizard-Installer-BOM-PROD-01.00.201903',
    [string]$ConnectionString='mongodb://admin:password@EC2AMAZ-GJUDE8I.MYWIZARD360.LOCAL:27017,EC2AMAZ-DF9IGB6.MYWIZARD360.LOCAL:27017/mywizard-pheonix?replicaSet=myWizardMongoRS&readPreference=secondaryPreferred&w=majority&authSource=admin',
    [string]$PackageDataPath='C:\Accenture\myWizard\Apps\Mongo.DataLoader\ObjectJSON'  ,
    [string]$MongoBinPath='C:\Program Files\MongoDB\Server\4.0\bin' ,
    [string]$InstalledVersion='01.00.201903',
    [string]$MongoDBCertFolder='C:\\mongo\\server',
    [string]$MongoDBKeyFile='keyfile.key',
	[string]$IsSSL = 'true',
    [string]$MongoDBCertificatePassKey = ''
)

$ShouldExecuteCustomizations = $true



# Copy Custom Data provided by Client and execute PreDeployment script
if($ShouldExecuteCustomizations)
{
    
    Write-Host "Copying Client Data to Mongo data json folder"

    if(!(Test-Path -Path $PackageDataPath))
    {
        New-Item -Path $PackageDataPath -ItemType 'Directory'
    }

    $customDataPath = $ClientCustomizationPath+ "/Data/$InstalledVersion/*" 
    Copy-Item $customDataPath -Destination $PackageDataPath -Force -Recurse
}

$ReplicationPartnersObj = $ReplicationPartners | ConvertFrom-Json
Write-Host $ReplicationPartnersObj.Value.Value

$pushpath = $packagePath + "/Release"

Write-Verbose "Updating the AppServiceDeploymentDef.xml file for this deployment"

$DefinitionFile = $packagePath + "/Release/AppServiceDeploymentDef.xml"
$BackupDefFile = $packagePath + "/Release/Backup-AppServiceDeploymentDef.xml"

Write-Host "DefinitionFile: $DefinitionFile"
Write-Host "BackupDefFile: $BackupDefFile"

Copy-Item $DefinitionFile $BackupDefFile
[xml]$AppDefination = Get-Content $DefinitionFile
$WKFolder = $packagePath + "/Release/"
$ObjJson = $packagePath + "/ObjectJSON/"
$ViewJson = $packagePath + "/Views/"
Write-Host "WkFolder: $WKFolder"
Write-Host "ObjJson: $ObjJson"
Write-Host "Views: $ViewJson"
Write-Host "EnvironmentDataFolderPath: $ObjJson"

Add-Type -AssemblyName System.Web
$DBPasswordEncode = [System.Web.HttpUtility]::UrlEncode($DBPassword) 
$AppDefination.AppServiceConfiguration.Environments.Environment.WorkingFolderPath = [string]$WKFolder
$AppDefination.AppServiceConfiguration.Environments.Environment.DataFolderPath = [string]$ObjJson
$AppDefination.AppServiceConfiguration.Environments.Environment.EnvironmentDataFolderPath  = [string]$ObjJson
$AppDefination.AppServiceConfiguration.Environments.Environment.ViewFolderPath  = [string]$ViewJson
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.Database = [string]$MongoDatabaseName
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.DatabaseHost = [string]$MongoDatabaseHost
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.IsReplicated = [string]$IsReplicated  
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.BinaryFolderPath = [string]$MongoBinPath 
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.IsDropDatabase = [string]$IsDropDatabase
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.bindIp='127.0.0.1,'+[string]$MongoDatabaseIP
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.HostSetting.SecuritySetting.IsAuthenticated = [string]$IsAuthenticated
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.HostSetting.SecuritySetting.UserName = [string]$DBUserName
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.HostSetting.SecuritySetting.Password = [string]$DBPasswordEncode

$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.ReplicationSetting.Value = 'myWizardMongo1RS'
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.ReplicationSetting.KeyFileName = $MongoDBCertFolder+'/'+$MongoDBKeyFile
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.ReplicationSetting.KeyFile = $MongoDBKeyFile

$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.HostSetting.SSLSetting.IsSSL = $IsSSL
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.HostSetting.SSLSetting.ClientPEMFile = $MongoDBCertFolder+'/server.pem'
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.HostSetting.SSLSetting.PEMKeyFile = ''
$AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.HostSetting.SSLSetting.CAFile = ''

Write-Host "Replication Section"
$RepPartnercount = $ReplicationPartners.Value.Count
Write-Host "Count: $RepPartnercount"
$i=0
$RepPartnercount

foreach($partner in $ReplicationPartnersObj)
{
    Write-Host "DatabaseHost: " $partner.DatabaseHost

    $AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.ReplicationSetting.ReplicationHosts.ReplicationHost[$i].DatabaseHost=$partner.DatabaseHost.ToString()
    $AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.ReplicationSetting.ReplicationHosts.ReplicationHost[$i].DatabasePort=$partner.DatabasePort.ToString()
    $AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.ReplicationSetting.ReplicationHosts.ReplicationHost[$i].IsArbiter=$partner.IsArbiter.ToString()
    $AppDefination.AppServiceConfiguration.Environments.DatabaseProviders.DatabaseProvider.MongoDBDatabaseProvider.ReplicationSetting.ReplicationHosts.ReplicationHost[$i].bindIp='127.0.0.1,'+$partner.bindIp.ToString()

    $i++
}

Write-Host "Saving $DefinitionFile"
$AppDefination.save($DefinitionFile)

Write-Verbose "Updated the AppServiceDeploymentDef.xml file Successfully"

# Reading the DataLoader Config.

$DataLoaderConfigFile = $packagePath  + "/Release/appsettings.json"
$DataLoaderJson = Get-Content $DataLoaderConfigFile  -Raw | ConvertFrom-Json

$DataLoaderJson.AppSettings.certificatePath = $MongoDBCertFolder + "/client.pfx"
$DataLoaderJson.AppSettings.certificatePassKey = $MongoDBCertificatePassKey
$DataLoaderJson | ConvertTo-Json | set-content $DataLoaderConfigFile

Write-Verbose "Completed processing Appsettings.config file"
cd $packagePath/Release
/usr/bin/dotnet Accenture.Mywizard.MongoDataLoader.dll

Write-Verbose "Executing $DataLoaderPath"
$ExecSummaryPath =  $packagePath + "ExecutionSummary.txt"
Set-Content -Path $ExecSummaryPath -Value "Success"