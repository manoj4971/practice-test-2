#!/bin/bash
TITLE=" System Information"
RIGHT_NOW=$(date +"%x %r %Z")
TIME_STAMP="Updated on $RIGHT_NOW by $USER"
function Show_Uptime
{
  echo "<div class='panel panel-default'>"
  echo "<div class='panel-heading'>"
  echo "<h4 class='panel-title'>"
  echo "<a data-toggle='collapse' href='#systemupdate'><b>System Uptime</b></a>"
  echo "</h4>"
  echo "</div>"
  echo "<div id='systemupdate' class='panel-collapse collapse in'>"
  echo "<div class='panel-body'>"
  echo "<pre>"
  uptime
  echo "</pre>"
  echo "</div>"
  echo "</div>"
  echo "</div>"    
}
function Drive_Space
{
  echo "<div class='panel panel-default'>"
  echo "<div class='panel-heading'>"
  echo "<h4 class='panel-title'>"
  echo "<a data-toggle='collapse' href='#filesystemspace'><b>File System Space</b></a>"
  echo "</h4>"
  echo "</div>"
  echo "<div id='filesystemspace' class='panel-collapse collapse in'>"
  echo "<div class='panel-body'>"
  echo "<pre>"
  df -kh
  echo "</pre>"
  echo "</div>"
  echo "</div>"
  echo "</div>"
}
function Mem_Info
{

  echo "<div class='panel panel-default'>"
  echo "<div class='panel-heading'>"
  echo "<h4 class='panel-title'>"
  echo "<a data-toggle='collapse' href='#memory'><b>Memory Info</b></a>"
  echo "</h4>"
  echo "</div>"
  echo "<div id='memory' class='panel-collapse collapse in'>"
  echo "<div class='panel-body'>"
  echo "<div class='col-md-8'>"  
  echo "<br/>"
  echo "<br/>"
  echo "<pre id=memoryinfo>"
    free -m -t -h -w
  echo "</pre>"
  echo "</div>"
  echo "<div class='col-md-4'>"
  echo "<div id='piechart'></div>"
  echo "</div>"
  echo "</div>"
  echo "</div>"
  echo "</div>"    
}
function CPU_Info
{
  echo "<div class='panel panel-default'>"
  echo "<div class='panel-heading'>"
  echo "<h4 class='panel-title'>"
  echo "<a data-toggle='collapse' href='#cpuinfo'><b>CPU Info</b></a>"
  echo "</h4>"
  echo "</div>"
  echo "<div id='cpuinfo' class='panel-collapse collapse in'>"
  echo "<div class='panel-body'>"
  echo "<pre>"
  lscpu | grep -e "^CPU(s):" -e "Model name:" -e "CPU MHz:" -e "CPU max MHz:" -e "Core(s) per socket:"
  echo "</pre>"
  echo "</div>"
  echo "</div>"
  echo "</div>"    
}
function Inotify_MaxUserInstances
{
  echo "<div class='panel panel-default'>"
  echo "<div class='panel-heading'>"
  echo "<h4 class='panel-title'>"
  echo "<a data-toggle='collapse' href='#inotify'><b>inotify.max_user_instances</b></a>"
  echo "</h4>"
  echo "</div>"
  echo "<div id='inotify' class='panel-collapse collapse in'>"
  echo "<div class='panel-body'>"
  echo "<pre>"
  cat /proc/sys/fs/inotify/max_user_instances 
  echo "</pre>"
  echo "</div>"
  echo "</div>"
  echo "</div>"      
}
function Software_Installed
{
  echo "<div class='panel panel-default'>"
  echo "<div class='panel-heading'>"
  echo "<h4 class='panel-title'>"
  echo "<a data-toggle='collapse' href='#softwareinstalled'><b>Software Installed</b></a>"
  echo "</h4>"
  echo "</div>"
  echo "<div id='softwareinstalled' class='panel-collapse collapse in'>"
  echo "<div class='panel-body'>"
  echo "<pre>"
  rpm -qa | grep -e "dotnet-runtime" -e "nginx-1" -e "python3" -e "tomcat" -e "java" -e "jdk" -e "jre" -e "anaconda" -e "mongo" -e "nodejs" -e "erlang" -e "rabbitmq" -e "epel-release" -e "libgdiplus" -e "puppeteer"
  echo
  echo "Python version and path"
  python3.7 --version
  whereis python3.7
  echo
  echo "Catalina Home"
  printenv | grep CATALINA_HOME
  echo
  echo "</pre>"
  echo "</div>"
  echo "</div>"
  echo "</div>"      
}
function Ports_Listening
{
  echo "<div class='panel panel-default'>"
  echo "<div class='panel-heading'>"
  echo "<h4 class='panel-title'>"
  echo "<a data-toggle='collapse' href='#applicationportslistening'><b>Application Ports Listening</b></a>"
  echo "</h4>"
  echo "</div>"
  echo "<div id='applicationportslistening' class='panel-collapse collapse'>"
  echo "<div class='panel-body'>"
  echo "<pre>"
  netstat -tunlp | grep  -e 5986 -e 5985 -e "80"
  echo "</pre>"
  echo "</div>"
  echo "</div>"
  echo "</div>"     
}
function Folder_Permissions
{
  echo "<div class='panel panel-default'>"
  echo "<div class='panel-heading'>"
  echo "<h4 class='panel-title'>"
  echo "<a data-toggle='collapse' href='#folderpermission'><b>Folder Permissions</b></a>"
  echo "</h4>"
  echo "</div>"
  echo "<div id='folderpermission' class='panel-collapse collapse in'>"
  echo "<div class='panel-body'>"
  echo "<pre>"
  if grep -qs '/mnt/myWizard-Phoenix ' /proc/mounts; then		
	echo "Monut Path is present"
	else
	echo "Monut Path is not present"
	fi
	s=$(df -h |grep /mnt/myWizard-Phoenix)
	echo $s
	echo "Mount Path Permission is listed below"
	getfacl /mnt/myWizard-Phoenix    
	echo
	echo "Application Installation Folder Path Permission is listed below"
	getfacl /var/www    
	getfacl /etc/tomcat9
  echo "</pre>"
  echo "</div>"
  echo "</div>"
  echo "</div>" 
}

function Systemctl_Status
{
  echo "<div class='panel panel-default'>"
  echo "<div class='panel-heading'>"
  echo "<h4 class='panel-title'>"
  echo "<a data-toggle='collapse' href='#servicestatus'><b>Service Status</b></a>"
  echo "</h4>"
  echo "</div>"
  echo "<div id='servicestatus' class='panel-collapse collapse in'>"
  echo "<div class='panel-body'>"
  echo "<pre>"
  systemctl | grep 'nginx\|myWizard\|tomcat\|mongod\|omid' 
  echo "</pre>"
  echo "</div>"
  echo "</div>"
  echo "</div>"    
}

function DB_Details
{
  if pgrep mongod > /dev/null; then    
  echo "<div class='panel panel-default'>"
  echo "<div class='panel-heading'>"
  echo "<h4 class='panel-title'>"
  echo "<a data-toggle='collapse' href='#databasedetails'><b>Database Details</b></a>"
  echo "</h4>"
  echo "</div>"
  echo "<div id='databasedetails' class='panel-collapse collapse'>"
  echo "<div class='panel-body'>"
  echo "<pre>"  
  dbs=`echo "show dbs" | mongo -host $HOSTNAME --ssl --sslCAFile /mongo/certificates/CA.crt --sslPEMKeyFile /mongo/certificates/server.pem -u admin -p myWizard@123 -quiet`
  for db in $dbs; 
  do 
  if [[ $db == *"DB"* || $db == *"mywizard-phoenix" ]]; then
  #if [[ $db == *"TestOptimizerDB"* ]]; then
    echo "<h3>Details of database $db</h3>";
    searchstring="Please use tlsCAFile instead." 
  
    collectioncount=`(echo use "$db"; echo "var collections = db.getSiblingDB('$db').stats().collections"; echo "var index = db.getSiblingDB('$db').stats().indexes"; echo "var views = db.getSiblingDB('$db').stats().views"; echo "print('Collection count: ' + collections);"; echo "print()"; echo "print('Views count: ' + views);"; echo "print('Index count: ' + index);" ) | mongo -host $HOSTNAME --ssl --sslCAFile /mongo/certificates/CA.crt --sslPEMKeyFile /mongo/certificates/server.pem -u admin -p myWizard@123 -quiet`
    temp=${collectioncount#*$searchstring}
    temp=${temp#*$db}
    echo $temp
  
    users=`echo "db.getSiblingDB('$db').getUsers()" | mongo -host $HOSTNAME --ssl --sslCAFile /mongo/certificates/CA.crt --sslPEMKeyFile /mongo/certificates/server.pem -u admin -p myWizard@123 -quiet`
    temp=${users#*$searchstring}
    user=$(echo "$temp" | grep -o -P '(?<="_id" : ").*?(?=",)')
    echo "Usersinfo :" $user
  
  if [[ $db == *"mywizard-phoenix"* ]]; then
    tempcollections=`(echo use "$db"; echo "var collections = db.getCollectionNames()"; echo "print('Collections inside the db:');"; echo "for(var i = 0; i < collections.length; i++){ var name = collections[i]; print(name);}") | mongo -host $HOSTNAME --ssl --sslCAFile /mongo/certificates/CA.crt --sslPEMKeyFile /mongo/certificates/server.pem -u admin -p myWizard@123 -quiet`
    collection=${tempcollections#*$db}
    echo -e "\t$collection";
  else
    tempcollections=`(echo use "$db"; echo "var collections = db.getCollectionNames()"; echo "print('Collections inside the db:');"; echo "for(var i = 0; i < collections.length; i++){ var name = collections[i]; print(name + ' - ' + db[name].count() + ' records');}") | mongo -host $HOSTNAME --ssl --sslCAFile /mongo/certificates/CA.crt --sslPEMKeyFile /mongo/certificates/server.pem -u admin -p myWizard@123 -quiet`
    collection=${tempcollections#*$db}
    echo -e "\t$collection";
  fi  
    echo
    echo
  fi
  done      
  echo "</pre>"
  echo "</div>"
  echo "</div>"
  echo "</div>" 
  fi
}
function GM_Folders
{
  if [[ -d /var/www/GatewayManager ]]
  then
    echo "<div class='panel panel-default'>"
    echo "<div class='panel-heading'>"
    echo "<h4 class='panel-title'>"
    echo "<a data-toggle='collapse' href='#gatwayfolders'><b>Gateway Manager Folders</b></a>"
    echo "</h4>"
    echo "</div>"
    echo "<div id='gatwayfolders' class='panel-collapse collapse in'>"
    echo "<div class='panel-body'>"
    echo "<pre>"
    if [[ -d /var/www/GatewayManager ]]
    then    
        for i in $(ls -d /var/www/GatewayManager/ProcessPipelines/*/); do echo ${i%%/}; done
        for i in $(ls -d /var/www/GatewayManager/bin/*/); do echo ${i%%/}; done
    fi
    echo "</pre>"
    echo "</div>"
    echo "</div>"
    echo "</div>"
  fi
}
function Mount_Folders
{
  if [[ -d /mnt/myWizard-Phoenix ]]
  then
    echo "<div class='panel panel-default'>"
    echo "<div class='panel-heading'>"
    echo "<h4 class='panel-title'>"
    echo "<a data-toggle='collapse' href='#foldersin'><b>Folders in /mnt/myWizard-Phoenix</b></a>"
    echo "</h4>"
    echo "</div>"
    echo "<div id='foldersin' class='panel-collapse collapse in'>"
    echo "<div class='panel-body'>"
    echo "<pre>"
    if [[ -d /mnt/myWizard-Phoenix ]]
    then
        for i in $(ls -d /mnt/myWizard-Phoenix/*/); do echo ${i%%/}; done
    fi
    echo "</pre>"
    echo "</div>"
    echo "</div>"
    echo "</div>"
  fi  
}

function Application_Version
{
rm -rf report.txt
for file in $(find /var/www/ -name 'PackageInfo.txt')
do
appname=$(sed -nr '/App name : / s/.*App name : ([^"]+).*/\1/p' $file)
assemblyversion=$(sed -nr '/Release version : / s/.*Release version : ([^"]+).*/\1/p' $file)
labelversion=$(sed -nr '/Label version : / s/.*Label version : ([^"]+).*/\1/p' $file)
echo -e "$appname $assemblyversion $labelversion" >> report.txt
done
if [ -s report.txt ] 
then

sed -i '1s/^/AppName AssemblyVersion LabelVersion\n/'  report.txt

    echo "<div class='panel panel-default'>"
    echo "<div class='panel-heading'>"
    echo "<h4 class='panel-title'>"
    echo "<a data-toggle='collapse' href='#appversions'><b>Application Version Details</b></a>"
    echo "</h4>"
    echo "</div>"
    echo "<div id='appversions' class='panel-collapse collapse in'>"
    echo "<div class='panel-body'>"
    echo "<pre>"
    awk '{printf "%-80s%-30s%-20s\n",$1,$2,$3}'  report.txt
    echo "</pre>"
    echo "</div>"
    echo "</div>"
    echo "</div>"
fi

}
function write_page
{
cat <<- _EOF_
    <html>
    <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>  
    <script type="text/javascript"> 
    // Load google charts
    google.charts.load('current', {'packages':['corechart']});
    google.charts.setOnLoadCallback(drawChart);    
    // //Draw the chart and set the chart values
    function drawChart() {    
      var activities = [
        ['System', 'Total Space Used']
      ];
    // //set the data
    var lines = document.getElementById("memoryinfo").innerText.split("\n");          

              lines = jQuery.grep(lines, function(value) {
                return value != "";
              });  
              var data = [];       
              var arrayx=[];
              var arrayvalue=[];
              var getname="";
              var getvalue="";
              var rowcount=1;  
              $.each(lines, function(n, elem) {     
                if(rowcount>2){
                  return false; 
                }
                var columncount=0;

                 lines2 =elem.split(" "); 
                 lines2 = lines2.filter(function (el) {
                  return el != null  && el !="" && el !="●" && el !="Mem:";
                });
                $.each(lines2,function(n,words){            
                  if(rowcount==1){
                    arrayx[arrayx.length]=words;
                  }else{


                    var convertvalue=words.slice(0,-1);

                    var grade=words.slice(words.length-1);
                    switch (grade) {
                      case 'G':   
                      arrayvalue[arrayvalue.length]= CONVERTER.gbConverter(convertvalue);  
                      break;
                      case 'M': 
                      arrayvalue[arrayvalue.length]= CONVERTER.mbConverter(convertvalue);
                      break;
                      case 'K': 
                      arrayvalue[arrayvalue.length]= CONVERTER.kbConverter(convertvalue);
                      break;
                      case 'B': 
                      arrayvalue[arrayvalue.length]= CONVERTER.byteConverter(convertvalue);
                      break;
                      default:  
                    }
                  }
                  columncount++;         
                });     
                rowcount++; 
              })
               arrayx.shift();
               arrayvalue.shift();
               arrayx.pop();          
               arrayvalue.pop();
            
              for(i=0;i<arrayx.length;i++){                
                activities.push([arrayx[i],parseFloat(arrayvalue[i])]);            
              }
            
      var data = google.visualization.arrayToDataTable(activities);            
      // //Optional; add a title and set the width and height of the chart
      var options = {'title':'Memory Info', sliceVisibilityThreshold: 0,tooltip: { trigger: 'selection' }};        
           
            
      // //Display the chart inside the <div> element with id="piechart"
      var chart = new google.visualization.PieChart(document.getElementById('piechart'));
      // var chart = new google.visualization.ColumnChart(document.getElementById('tooltip_action'));
    
      chart.draw(data, options);
    }




    var CONVERTER={
      gbConverter:function(value){
       var byte = value * 1024 * 1024 * 1024
       var kb = value * 1024 * 1024 
       var mb = value * 1024
           return value;
      },
      mbConverter:function(value){
        var byte = value * 1024 * 1024
        var kb = value * 1024
        var gb = value / 1024
            return gb;
      },
      kbConverter:function(value){
        var byte = value * 1024
        var mb = value / 1024
        var gb = value / (1024*1024)
            return gb;
      },
      byteConverter:function(value){
      var kb = value / 1024
      var mb = value / (1024*1024)
      var gb = value / (1024*1024*1024)
          return gb;
    }
    }

        </script>
    <title>$TITLE</title>
    </head>
     <body>
        <div class="container">
          <h2><b>$TITLE</b></h1>
          <p>$TIME_STAMP</p>
          <div class="panel-group" id="accordion">
            $(Show_Uptime)
            $(Drive_Space)
            $(Mem_Info)            
            $(CPU_Info)
            $(Folder_Permissions)
            $(Mount_Folders)
            $(Inotify_MaxUserInstances)
            $(Systemctl_Status)
            $(Application_Version)
            $(Software_Installed)
            $(Ports_Listening)
            $(DB_Details)
            $(GM_Folders)
          </div>
        </div>
      </body>
    </html>
_EOF_

}
IP=$(hostname -I|cut -d" " -f 1)
mkdir -p /var/www/appConfigFiles/reports
filename=$1-Deployment-Report-$IP-`date "+%Y%m%d"`.html

write_page > /var/www/appConfigFiles/reports/$filename
sed -i '/failed/s/^/<span style='color:red'> /' /var/www/appConfigFiles/reports/$filename
sed -i '/failed/s/$/ <\/span>/' /var/www/appConfigFiles/reports/$filename
mkdir -p /mnt/win/myWizardSource/Logs/Reports
yes|cp /var/www/appConfigFiles/reports/$filename /mnt/win/myWizardSource/Logs/Reports
exit 0




