echo "Adding folder permission"

echo "Creating log directory /var/www/Logs"
mkdir -p /var/www/Logs
echo ""

echo "Changing permissions /var/www/Logs"
chmod -R 755 /var/www/Logs
echo ""

echo "Changing owner /var/www"
chown -R nginx:nginx /var/www
echo ""

echo "Changing owner /etc/nginx"
chown -R nginx:nginx /etc/nginx
echo ""

echo "Changing owner /etc/tomcat9"
chown -R tomcat:tomcat /etc/tomcat9
echo ""

echo "Changing permission for /etc/tomcat9/logs"
chmod -R 755 /etc/tomcat9/logs
echo ""

echo "Changing owner /mnt/myWizard-Phoenix/DataLoader_DownloadTemplate"
chown -R nginx:nginx /mnt/myWizard-Phoenix/DataLoader_DownloadTemplate
echo ""

echo "Changing owner /mnt/myWizard-Phoenix/Fortress_DownloadTemplate"
chown -R nginx:nginx /mnt/myWizard-Phoenix/Fortress_DownloadTemplate
echo ""

echo "Changing owner chown -R nginx:nginx /mnt/myWizard-Phoenix/GenericUpload"
chown -R nginx:nginx /mnt/myWizard-Phoenix/GenericUpload
echo ""

echo "Changing owner /mnt/myWizard-Phoenix/AppServiceHelpGuide"
chown -R nginx:nginx /mnt/myWizard-Phoenix/AppServiceHelpGuide
echo ""

echo "Changing owner /mnt/myWizard-Phoenix/GatewayManager/TokenizedProcessPipelines"
chown -R nginx:nginx  /mnt/myWizard-Phoenix/GatewayManager/TokenizedProcessPipelines
echo ""

echo "Creating irp/rra/rpa log directory"
mkdir -p /var/www/Logs/irp
mkdir -p /var/www/Logs/rra
mkdir -p /var/www/Logs/rpa
echo ""

echo "Changing permissions /var/www"
chmod -R 755 /var/www
echo ""

echo "Changing owner for irp/rra/rpa logs"
chown -R tomcat:tomcat /var/www/Logs/rra
chown -R tomcat:tomcat /var/www/Logs/irp
chown -R tomcat:tomcat /var/www/Logs/rpa
echo ""

echo "Changing permissions for TO mnt path"
chmod -R 755 /mnt/myWizard-Phoenix-TO   
echo ""

echo "Changing permissions for /mnt/myWizard-Phoenix/GatewayManager/TokenizedProcessPipelines"
chmod -R 755 /mnt/myWizard-Phoenix/GatewayManager/TokenizedProcessPipelines   
echo ""

echo "Changing permissions for postgresql certificates"
chmod 600 /var/www/appConfigFiles/certificates/postgresCA.pem
echo ""

echo "Changing directory to cd /etc/systemd/system"
cd /etc/systemd/system
echo ""

echo 'restarting nginx service'
systemctl restart nginx
echo ""

echo 'restarting tomcat service'
systemctl restart tomcat
echo ""

echo "Adding folder permission execution colpleted..."