print("099_Inc_1008258_ProductInstanceDeserializationFixes Start")

db.productinstances.find({
}).forEach(function (udf_productinstance) {
    if (udf_productinstance.ProductInstanceEntities != null) {
        udf_productinstance.ProductInstanceEntities.forEach(function (udf_productinstanceentity) {
            var workitemtype = udf_productinstanceentity.WorkItemTypeUId;
            if (workitemtype == undefined) {
                delete udf_productinstanceentity.WorkItemTypeUId;
                print(udf_productinstanceentity.WorkItemTypeUId, ',', udf_productinstanceentity.Description, ',',
                    udf_productinstanceentity.ProductInstanceUId)

            }
        })
    }
    db.productinstances.save(udf_productinstance);
});


db.productinstances.find({
}).forEach(function (udf_productinstance) {
    if (udf_productinstance.ProductInstanceEntities != null) {
        udf_productinstance.ProductInstanceEntities.forEach(function (udf_productinstanceentity) {
            if (udf_productinstanceentity.ProductInstanceEntityProperties != null) {
                udf_productinstanceentity.ProductInstanceEntityProperties.forEach(function (udf_productinstanceentityproperty) {
                    if (udf_productinstanceentityproperty.ProductPropertyNodePath == undefined) {
                        delete udf_productinstanceentityproperty.ProductPropertyNodePath;
                        print(udf_productinstanceentityproperty.PropertyDisplayName, ',', udf_productinstanceentityproperty.ProductInstanceUId)
                    }
                })
            }
        })
    }
    db.productinstances.save(udf_productinstance)
});



db.productinstances.find({
}).forEach(function (udf_productinstance) {
    if (udf_productinstance.ProductInstanceEntities != null) {
        udf_productinstance.ProductInstanceEntities.forEach(function (udf_productinstanceentity) {
            if (udf_productinstanceentity.ProductInstanceEntityProperties != null) {
                udf_productinstanceentity.ProductInstanceEntityProperties.forEach(function (udf_productinstanceentityproperty) {
                    if (udf_productinstanceentityproperty.ProductPropertyName == undefined) {
                        udf_productinstanceentityproperty.ProductPropertyName = "";
                        print(udf_productinstanceentityproperty.ProductPropertyName, ',', udf_productinstanceentityproperty.ProductInstanceUId)
                    }
                })
            }
        })
    }
    db.productinstances.save(udf_productinstance)
});



db.productinstances.find({
}).forEach(function (udf_productinstance) {
    if (udf_productinstance.ProductInstanceEntities != null) {
        udf_productinstance.ProductInstanceEntities.forEach(function (udf_productinstanceentity) {
            if (udf_productinstanceentity.ProductInstanceEntityProperties != null) {
                udf_productinstanceentity.ProductInstanceEntityProperties.forEach(function (udf_productinstanceentityproperty) {
                    if (udf_productinstanceentityproperty.OutboundProductPropertyNodePath == undefined) {
                        udf_productinstanceentityproperty.OutboundProductPropertyNodePath = "";
                        print(udf_productinstanceentityproperty.OutboundProductPropertyNodePath, ',', udf_productinstanceentityproperty.ProductInstanceUId)
                    }
                })
            }
        })
    }
    db.productinstances.save(udf_productinstance)
});

db.productinstances.find({
}).forEach(function (udf_productinstance) {
    if (udf_productinstance.ProductInstanceEntities != null) {
        udf_productinstance.ProductInstanceEntities.forEach(function (udf_productinstanceentity) {
            if (udf_productinstanceentity.ProductInstanceEntityProperties != null) {
                udf_productinstanceentity.ProductInstanceEntityProperties.forEach(function (udf_productinstanceentityproperty) {
                    if (udf_productinstanceentityproperty.OutboundProductPropertyName == undefined) {
                        udf_productinstanceentityproperty.OutboundProductPropertyName = "";
                        print(udf_productinstanceentityproperty.OutboundProductPropertyName, ',', udf_productinstanceentityproperty.ProductInstanceUId)
                    }
                })
            }
        })
    }
    db.productinstances.save(udf_productinstance)
});
print("099_Inc_1008258_ProductInstanceDeserializationFixes Ends")