﻿# /var/myscripts/New.ps1 -daysToKeepLogs 1 -daysToKeepArchives 7 -skipPrompt $false -logTranscript $true -appLogsPath /var/www/mywizard-logs -gmLogsPath /var/mywizard-services/mywizard-GM/ProcessPipelines -archiveBasePath /var/ArchiveLogs
param
(
    [int]$daysToKeepLogs = 1,
    [int]$daysToKeepArchives = 7,
    [bool]$skipPrompt = $true, #true should skip prompting to choose apps and consider all apps
    [bool]$logTranscript = $true, #false should skip logging verbose output
    [string]$appLogsPath = '/var/www/Logs',
    [string]$gmLogsPath = '/var/www/GatewayManager/ProcessPipeline',
    [string]$archiveBasePath = '/var/ArchiveLogs'
)

$global:logsPath = ""
$global:archivePath = ""

function Get-LogPaths {
    param(
        $LogType = ''
    )
    process {
        if ($logType -eq $appLogs) {
            $global:logsPath = $appLogsPath 
            $global:archivePath = $($archiveBasePath + '/' + (Split-Path $appLogsPath -Leaf))
        }
        elseif ($logType -eq $gmLogs) { 
            #creates dummy path
            if(-not $(Test-Path -Path $gmLogsPath)) {
                New-Item -Path $gmLogsPath -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
            }
            $global:logsPath = $gmLogsPath
            $global:archivePath = $($archiveBasePath + '/' + (Split-Path $gmLogsPath -Leaf))
        }

        New-Item -Path $global:archivePath -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null

        Write-Host $logsPath -BackgroundColor Red
        Write-Host $archivePath -BackgroundColor Red
        Write-Host $LogType -BackgroundColor Red
    }
}

function Start-Archival {

    begin {
        Clear-Host
        if ($logTranscript -eq $true) {
            New-Item -Path $($(Split-Path $PSCommandPath -Parent) + "/LogPurgingLogs") -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
            Start-Transcript -Path $($(Split-Path $PSCommandPath -Parent) + "/LogPurgingLogs/" + $(Get-Date -Format "ddMMyyyy_Hhmm") + ".txt") -Force
        }        
        $appLogs = "AppLogs"
        $gmLogs = "GMProcessLogs"
    }
    process {
        if ($skipPrompt -eq $false) {
            $global:i = 1
            #get other app log folders
            Get-LogPaths -logType $appLogs
            $pso = (Get-ChildItem -Path $logsPath -Directory) | Select-Object @{n = "Id"; e = { $global:i; $global:i++ } }, @{n = "Path"; e = { $_.FullName } }, @{n = "Name"; e = { $_.Name } }, @{n = "LogType"; e = { $appLogs } }
 
            #get gm app log folders
            Get-LogPaths -logType $gmLogs
            $pso += (Get-ChildItem -Path $logsPath -Directory) | Select-Object @{n = "Id"; e = { $global:i; $global:i++ } }, @{n = "Path"; e = { $_.FullName } }, @{n = "Name"; e = { $_.Name } }, @{n = "LogType"; e = { $gmLogs } }
 
            #print all apps & gm
            $pso | Select-Object -Property @{n = "Id"; e = { "[$($_.Id)]" } }, Name, LogType -Wait | Format-Table

            #user input block
            Write-Host
            Write-Host "Enter comma separeted Id's of Log folders"
            $inputs = Read-Host
            if ($inputs.Trim() -eq "") {
                Write-Host "Invalid input"
                break
            }
            else {
                $inputs = ([regex]("\s+")).Replace($inputs, "").Trim().Split(',')
            }

            #iterating through each app and processing the logs
            foreach ($appid in $inputs) {
                $app = $pso | Where-Object { $_.Id -eq "$appid" }
 
                Get-LogPaths -logType $app.LogType
                New-Item -ItemType Directory -Path $app.Path.Replace($logsPath, $archivePath) -Force -ErrorAction SilentlyContinue | Out-Null

                Write-Host
                Write-Host "[Event] Archiving logs for" $app.Name "older than" $daysToKeepLogs "days" -BackgroundColor DarkBlue
                #Start-Job -ScriptBlock ${function:Move-Logs} -ArgumentList @($app.Path,$app.LogType) -Name $app.Name
                Move-Logs -rootPath $app.Path -logType $app.LogType
                Write-Host "[Event] Logs archived for" $app.Name -BackgroundColor Green
                Write-Host

                Remove-EmptyDirectories -rootPath $app.Path -logType $app.LogType

                Write-Host "[Event] Deleting archives for" $app.Name "older than" $daysToKeepArchives "days" -BackgroundColor DarkBlue
                Remove-Logs -rootPath $app.Path.Replace($logsPath, $archivePath) 
                Write-Host "[Event] Archives deleted for" $app.Name -BackgroundColor Green
                Write-Host
            
                Remove-EmptyDirectories -rootPath $app.Path.Replace($logsPath, $archivePath) -logType $app.LogType
            }
        }
        else {
            Get-LogPaths -logType $appLogs
            Write-Host
            Write-Host "[Event] Archiving" $appLogs "which are older than" $daysToKeepLogs "days" -BackgroundColor DarkBlue
            Move-Logs -rootPath $logsPath -logType $appLogs
            Write-Host "[Event] Logs archived for" $appLogs -BackgroundColor Green
            Write-Host
            
            Remove-EmptyDirectories -rootPath $logsPath -logType $appLogs

            Write-Host "[Event] Deleting archives for" $appLogs "which are older than" $daysToKeepArchives "days" -BackgroundColor DarkBlue
            Remove-Logs -rootPath $archivePath 
            Write-Host "[Event] Archives deleted for" $appLogs -BackgroundColor Green
            Write-Host

            Get-LogPaths -logType $gmLogs
            Write-Host
            Write-Host "[Event] Archiving" $gmLogs "which are older than" $daysToKeepLogs "days" -BackgroundColor DarkBlue
            Move-Logs -rootPath $logsPath -logType $gmLogs
            Write-Host "[Event] Logs archived for" $gmLogs -BackgroundColor Green
            Write-Host
            
            Remove-EmptyDirectories -rootPath $logsPath -logType $gmLogs

            Write-Host "[Event] Deleting Archive for" $gmLogs "which are older than" $daysToKeepArchives "days" -BackgroundColor DarkBlue
            Remove-Logs -rootPath $archivePath 
            Write-Host "[Event] Archives deleted for" $gmLogs -BackgroundColor Green
            Write-Host

            #for deleting empty directories, we don't have separate calls for archive folders as be take GM and other logs archival backup in same folder
            Remove-EmptyDirectories -rootPath $archiveBasePath -logType $appLogs
        }

        

        # Write-Host "[Event] Setting permissions to" $archiveBasePath -BackgroundColor Blue
        # chmod -R 777 $archiveBasePath
    }
    end {
        if ($logTranscript -eq $true) {
            Stop-Transcript
        }
    }
}

function Move-Logs {
    param
    (
        $rootPath = '',
        $logType = ''
    )
    process {
        (Get-ChildItem -Path $rootPath -Recurse) | 
        Where-Object {
            # files
            If ($_.PSIsContainer -eq $false) { 
                if ($logType -eq $gmLogs) {
                    $_.LastWriteTime.Date -le $(Get-Date).AddDays(-$daysToKeepLogs).Date -and
                    (
                        $_.FullName -match "ProcessLogs" -or 
                        $_.FullName -match "Instances" -or
                        $_.FullName -match "Processing"
                    )
                }
                elseif ($logType -eq $appLogs) {
                    $_.LastWriteTime.Date -le $(Get-Date).AddDays(-$daysToKeepLogs).Date 
                }
            }
            #folders
            else {
                if ($logType -eq $gmLogs) {
                    (
                        $_.FullName -match "ProcessLogs" -or 
                        $_.FullName -match "Instances" -or
                        $_.FullName -match "Processing"
                    )
                }
                elseif ($logType -eq $appLogs) {
                    1 -eq 1 #if you get this workaround, you know TSQL
                }
            }
        } | 
        ForEach-Object {
            $source = $_.FullName
            $destination = $_.FullName.Replace($logsPath, $archivePath)
            If ($_.PSIsContainer -eq $true) { 
                New-Item -ItemType Directory -Path $destination -Force -ErrorAction SilentlyContinue | Out-Null
            }
            else {
                Write-Host "Move-Item -Destination $destination -Path $source -Force"
                Move-Item -Destination $destination -Path $source -Force
            }
        }
    }
}

function Remove-Logs {
    param(
        $rootPath = ''
    )
    process {
        (Get-ChildItem -Path $rootPath -Recurse -File) | 
        Where-Object {
            $_.LastWriteTime.Date -le $(Get-Date).AddDays(-$daysToKeepArchives).Date 
        } |
        ForEach-Object { 
            $source = $_.FullName
            Write-Host "Remove-Item -Path $source -Force"
            Remove-Item -Path $source -Force
        }
    }
}

function Remove-EmptyDirectories {
    param
    (
        $rootPath = '',
        $logType = ''
    )
    begin {
        Write-Host "[Event] Removing empty directories from" $rootPath -BackgroundColor DarkBlue
    }
    process {
        (Get-ChildItem -Path $rootPath -Recurse -Directory) | 
        Where-Object { 
            if ($logType -eq $gmLogs) {
                (
                    $_.FullName -match "ProcessLogs" -or 
                    $_.FullName -match "Instances" -or
                    $_.FullName -match "Processing"
                ) -and
                (Get-ChildItem -Path $_.FullName).Count -eq 0
            }
            elseif ($logType -eq $appLogs) {
                (Get-ChildItem -Path $_.FullName).Count -eq 0 
            }
        } | 
        ForEach-Object { 
            $source = $_.FullName
            Write-Host "Remove-Item -Path $source -Force"
            Remove-Item -Path $source -Force
        }
    }
    end {
        Write-Host "[Event] Empty directories removed from" $rootPath -BackgroundColor Green
        Write-Host
    }
}


Start-Archival