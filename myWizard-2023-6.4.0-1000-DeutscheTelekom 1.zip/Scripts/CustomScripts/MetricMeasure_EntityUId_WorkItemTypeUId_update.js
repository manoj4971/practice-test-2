print("EntityUIds and WorkItemTypeUIds Update Started!");
/* 1 */
//AATD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AATD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 2 */
//AC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 3 */
//ACRL Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ACRL"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 4 */
//ACRM Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ACRM"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 5 */
//ACS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ACS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 6 */
//ACT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ACT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 7 */
//AD001 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD001"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 8 */
//AD002 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD002"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 9 */
//AD003 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD003"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 10 */
//AD004 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD004"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 11 */
//AD005 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD005"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 12 */
//AD020 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD020"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 13 */
//AD022 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD022"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 14 */
//AD032 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD032"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0600-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 15 */
//AD033 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD033"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 16 */
//AD034 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD034"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 17 */
//AD035 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD035"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 18 */
//AD046 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD046"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 19 */
//AD047 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD047"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 20 */
//AD048 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD048"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 21 */
//AD049 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD049"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 22 */
//AD050 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD050"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 23 */
//AD051 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD051"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 24 */
//AD052 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD052"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 25 */
//AD053 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD053"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 26 */
//AD054 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD054"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 27 */
//AD055 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD055"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 28 */
//AD056 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD056"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 29 */
//AD058 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD058"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 30 */
//AD059 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD059"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 31 */
//AD062 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD062"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 32 */
//AD063 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD063"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 33 */
//AD064 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD064"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 34 */
//AD066 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD066"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 35 */
//AD067 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD067"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 36 */
//AD068 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD068"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 37 */
//AD069 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD069"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 38 */
//AD070 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD070"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 39 */
//AD071 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD071"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 40 */
//AD072 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD072"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 41 */
//AD079 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD079"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 42 */
//AD082 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD082"
},
{
	"$set" : {
	"EntityUIds" : [ ],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 43 */
//AD083 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD083"
},
{
	"$set" : {
	"EntityUIds" : [ ],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 44 */
//AD084 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD084"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 45 */
//AD085 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD085"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 46 */
//AD086 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD086"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 47 */
//AD087 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD087"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 48 */
//AD088 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD088"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 49 */
//AD089 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD089"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 50 */
//AD090 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD090"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 51 */
//AD091 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD091"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 52 */
//AD092 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD092"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 53 */
//AD093 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD093"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 54 */
//AD094 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD094"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 55 */
//AD095 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD095"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 56 */
//AD096 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD096"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 57 */
//AD097 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD097"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 58 */
//AD099 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD099"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 59 */
//AD100 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD100"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 60 */
//AD105 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD105"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 61 */
//AD106 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD106"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 62 */
//AD108 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD108"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 63 */
//AD114 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD114"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 64 */
//AD115 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD115"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 65 */
//AD119 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD119"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 66 */
//AD120 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD120"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 67 */
//AD121 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD121"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 68 */
//AD123 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD123"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 69 */
//AD129 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD129"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 70 */
//AD130 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD130"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 71 */
//AD131 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD131"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 72 */
//AD132 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD132"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 73 */
//AD133 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD133"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 74 */
//AD136 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD136"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 75 */
//AD137 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD137"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 76 */
//AD138 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD138"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 77 */
//AD139 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD139"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 78 */
//AD140 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD140"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 79 */
//AD141 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD141"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 80 */
//AD143 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD143"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 81 */
//AD149 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD149"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 82 */
//AD154 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD154"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 83 */
//AD155 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD155"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 84 */
//AD156 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD156"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 85 */
//AD157 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD157"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 86 */
//AD158 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD158"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 87 */
//AD159 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD159"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 88 */
//AD160 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD160"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 89 */
//AD161 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD161"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 90 */
//AD162 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD162"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 91 */
//AD163 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD163"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 92 */
//AD164 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD164"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 93 */
//AD165 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD165"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 94 */
//AD166 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD166"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 95 */
//AD167 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD167"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 96 */
//AD168 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD168"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 97 */
//AD169 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD169"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 98 */
//AD170 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD170"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 99 */
//AD171 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD171"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 100 */
//AD172 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD172"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 101 */
//AD173 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD173"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 102 */
//AD174 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD174"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 103 */
//AD175 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD175"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 104 */
//AD176 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD176"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 105 */
//AD177 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD177"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 106 */
//AD178 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD178"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 107 */
//AD179 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD179"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 108 */
//AD180 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD180"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 109 */
//AD181 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD181"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 110 */
//AD182 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD182"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 111 */
//AD183 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD183"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 112 */
//AD184 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD184"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 113 */
//AD185 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD185"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 114 */
//AD186 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD186"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 115 */
//AD187 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD187"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 116 */
//AD188 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD188"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 117 */
//AD189 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD189"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 118 */
//AD190 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD190"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 119 */
//AD191 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD191"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 120 */
//AD192 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD192"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 121 */
//AD193 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD193"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 122 */
//AD194 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD194"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 123 */
//AD195 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD195"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 124 */
//AD196 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD196"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 125 */
//AD197 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD197"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 126 */
//AD198 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD198"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 127 */
//AD199 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD199"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 128 */
//AD200 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD200"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 129 */
//AD201 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD201"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 130 */
//AD202 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD202"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 131 */
//AD203 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD203"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 132 */
//AD204 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD204"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 133 */
//AD205 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD205"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 134 */
//AD206 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD206"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 135 */
//AD207 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD207"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 136 */
//AD208 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD208"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 137 */
//AD209 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD209"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 138 */
//AD210 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD210"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 139 */
//AD211 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD211"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 140 */
//AD212 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD212"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 141 */
//AD213 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD213"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 142 */
//AD214 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD214"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 143 */
//AD215 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD215"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 144 */
//AD216 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD216"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 145 */
//AD217 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD217"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 146 */
//AD218 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD218"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 147 */
//AD219 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD219"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 148 */
//AD227 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD227"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 149 */
//AD245 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD245"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 150 */
//AD246 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD246"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 151 */
//AD247 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD247"
},
{
	"$set" : {
	"EntityUIds" : [
			UUID("00020090-0200-0000-0000-000000000000"),
			UUID("00020090-0100-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 152 */
//AD248 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD248"
},
{
	"$set" : {
	"EntityUIds" : [
			UUID("00020090-0200-0000-0000-000000000000"),
			UUID("00020090-0100-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 153 */
//AD249 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD249"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 154 */
//AD250 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD250"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000"),
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000")
	]
	}
})

/* 155 */
//AD251 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD251"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000")
	]
	}
})

/* 156 */
//AD252 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD252"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 157 */
//AD253 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD253"
},
{
	"$set" : {
	"EntityUIds" : [
			UUID("00020090-0200-0000-0000-000000000000"),
			UUID("00020090-0100-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 158 */
//AD254 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD254"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 159 */
//AD255 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD255"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 160 */
//AD256 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD256"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 161 */
//AD257 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD257"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 162 */
//AD258 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD258"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 163 */
//AD259 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD259"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 164 */
//AD260 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD260"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 165 */
//AD261 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD261"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 166 */
//AD262 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD262"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 167 */
//AD263 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD263"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00030010-0200-0000-0000-000000000000"),
		UUID("00020110-0110-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 168 */
//AD264 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD264"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020110-0400-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 169 */
//AD265 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD265"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 170 */
//AD272 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD272"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000"),
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000")
	]
	}
})

/* 171 */
//AD273 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD273"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 172 */
//AD274 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD274"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 173 */
//AD275 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD275"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 174 */
//AD276 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD276"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 175 */
//AD277 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD277"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 176 */
//AD278 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD278"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 177 */
//AD279 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD279"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00020100-0300-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 178 */
//AD280 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD280"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00020100-0300-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 179 */
//AD281 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD281"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 180 */
//AD282 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD282"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 181 */
//AD283 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AD283"
},
{
	"$set" : {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0060-000000000000")
		]
	}
})

/* 182 */
//ADA001 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADA001"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 183 */
//ADA004 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADA004"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 184 */
//ADA005 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.updateMany({
	"Code" : {$in:["ADA005","PISC"]}
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 185 */
//ADA006 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADA006"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 186 */
//ADA007 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADA007"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 187 */
//ADA008 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADA008"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 188 */
//ADA009 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADA009"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 189 */
//ADA010 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADA010"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 190 */
//ADA011 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADA011"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 191 */
//ADA012 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADA012"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 192 */
//ADBM001 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ Code: { $in: ['ADBM001'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000"),
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	}
)

/* 193 */
//ADBM002 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ Code: { $in: ['ADBM002'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00020040-0040-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000"),
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	}
)

/* 194 */
//ADCT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADCT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 195 */
//ADD0011 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADD0011"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 196 */
//ADD005 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADD005"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 197 */
//ADD006 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADD006"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 198 */
//ADD007 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADD007"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 199 */
//ADDM001 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADDM001"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 200 */
//ADDM002 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ Code: { $in: ['ADDM002'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00020070-0600-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000"),
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	}
)

/* 201 */
//ADR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020090-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 202 */
//ADRM001 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM001"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 203 */
//ADRM002 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM002"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 204 */
//ADRM003 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM003"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 205 */
//ADRM004 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM004"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 206 */
//ADRM005 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM005"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 207 */
//ADRM006 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM006"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 208 */
//ADRM007 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM007"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 209 */
//ADRM008 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM008"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 210 */
//ADRM009 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM009"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 211 */
//ADRM010 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM010"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 212 */
//ADRM011 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM011"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 213 */
//ADRM012 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM012"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 214 */
//ADRM013 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM013"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 215 */
//ADRM014 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM014"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 216 */
//ADRM015 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM015"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 217 */
//ADRM016 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADRM016"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 218 */
//ADSM003 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADSM003"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 219 */
//ADSM004 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADSM004"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 220 */
//ADSM006 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADSM006"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 221 */
//ADSM007 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADSM007"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 222 */
//ADSM008 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADSM008"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 223 */
//ADTCR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADTCR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 224 */
//ADTE001 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ADTE001"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 225 */
//AE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 226 */
//AERS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AERS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 227 */
//AEV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AEV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 228 */
//AGR003 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR003"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 229 */
//AGR019 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR019"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 230 */
//AGR022 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR022"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 231 */
//AGR024 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR024"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 232 */
//AGR028 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR028"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 233 */
//AGR035 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR035"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 234 */
//AGR036 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR036"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 235 */
//AGR037 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR037"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 236 */
//AGR038 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR038"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 237 */
//AGR039 Measure EntityUIds and WorkItemTypeUIds Update

db.clients.metrics.update({ Code: { $in: ['AGR039'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00020070-0600-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000"),
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	}
)

/* 238 */
//AGR040 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR040"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 239 */
//AGR045 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR045"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 240 */
//AGR046 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR046"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 241 */
//AGR058 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR058"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 242 */
//AGR059 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR059"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 243 */
//AGR060 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR060"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 244 */
//AGR061 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR061"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 245 */
//AGR076 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR076"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0030-000000000000"),
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 246 */
//AGR077 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR077"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0030-000000000000")
	]
	}
})

/* 247 */
//AGR078 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR078"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0030-000000000000")
	]
	}
})

/* 248 */
//AGR080 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR080"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0030-000000000000"),
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 249 */
//AGR099 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR099"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 250 */
//AGR100 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR100"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 251 */
//AGR101 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR101"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 252 */
//AGR102 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.updateMany({
	"Code" : {$in:["AGR102","AGR115","PIUS"]}
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
	})

db.clients.metrics.updateMany({ Code: { $in: ['DCUS', 'ADSM041'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00020040-0040-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [UUID("00020040-0200-0010-0060-000000000000")]
		}
	}
)

db.clients.metrics.updateMany({
	Code: {
		$in: ['AV']
	}
}, {
	$set: {
		"EntityUIds": [UUID("00020090-0200-0000-0000-000000000000"), UUID("00020040-0040-0000-0000-000000000000")],
		"WorkItemTypeUIds": [UUID("00020040-0200-0010-0040-000000000000")]
	}
})

/* 253 */
//AGR103 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR103"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 254 */
//AGR104 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR104"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 255 */
//AGR105 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR105"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 256 */
//AGR106 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR106"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 257 */
//AGR107 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR107"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 258 */
//AGR108 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR108"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 259 */
//AGR109 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR109"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 260 */
//AGR110 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR110"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 261 */
//AGR111 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR111"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 262 */
//AGR112 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR112"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 263 */
//AGR113 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR113"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 264 */
//AGR114 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR114"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 265 */
//AGR117 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR117"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 266 */
//AGR118 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR118"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 267 */
//AGR119 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGR119"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 268 */
//AGS001 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS001"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 269 */
//AGS003 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS003"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 270 */
//AGS004 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS004"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 271 */
//AGS005 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS005"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 272 */
//AGS006 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS006"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 273 */
//AGS008 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS008"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 274 */
//AGS027 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS027"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 275 */
//AGS028 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS028"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 276 */
//AGS029 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS029"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 277 */
//AGS038 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS038"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 278 */
//AGS039 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS039"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 279 */
//AGS040 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS040"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 280 */
//AGS041 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS041"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0110-000000000000")
	]
	}
})

/* 281 */
//AGS042 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS042"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0110-000000000000")
	]
	}
})

/* 282 */
//AGS043 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS043"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0100-000000000000")
	]
	}
})

/* 283 */
//AGS044 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS044"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0100-000000000000")
	]
	}
})

/* 284 */
//AGS051 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS051"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 285 */
//AGS052 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS052"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 286 */
//AGS053 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS053"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 287 */
//AGS054 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS054"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 288 */
//AGS055 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS055"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 289 */
//AGS056 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS056"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 290 */
//AGS057 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS057"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 291 */
//AGS058 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS058"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 292 */
//AGS059 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS059"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 293 */
//AGS060 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS060"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 294 */
//AGS061 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS061"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 295 */
//AGS062 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS062"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 296 */
//AGS063 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS063"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 297 */
//AGS064 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS064"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 298 */
//AGS065 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS065"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 299 */
//AGS066 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS066"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 300 */
//AGS067 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS067"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 301 */
//AGS068 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS068"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 302 */
//AGS069 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS069"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 303 */
//AGS070 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS070"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 304 */
//AGS071 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS071"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 305 */
//AGS072 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AGS072"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 306 */
//ALT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ALT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 307 */
//ANCDT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ANCDT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 308 */
//ANTCC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ANTCC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 309 */
//ANTCE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ANTCE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 310 */
//APBI Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "APBI"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 311 */
//APCS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "APCS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000")
	]
	}
})

/* 312 */
//APR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "APR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 313 */
//APSAR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "APSAR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 314 */
//APSI Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "APSI"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 315 */
//APV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "APV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 316 */
//ASPDR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ASPDR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 317 */
//ATUSC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ATUSC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 318 */
//AVAT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "AVAT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 319 */
//BC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000")
	]
	}
})

/* 320 */
//BMAD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BMAD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 321 */
//BMSBAD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BMSBAD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 322 */
//BVAAR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVAAR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 323 */
//BVAAS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVAAS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 324 */
//BVACR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVACR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 325 */
//BVACS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVACS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 326 */
//BVAD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVAD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 327 */
//BVADAR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVADAR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 328 */
//BVADCR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVADCR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 329 */
//BVADNR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVADNR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 330 */
//BVAG Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVAG"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 331 */
//BVAND Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVAND"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 332 */
//BVANR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVANR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 333 */
//BVANS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVANS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 334 */
//BVWND Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "BVWND"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 335 */
//CACD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CACD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 336 */
//CALTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CALTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 337 */
//CANTFW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CANTFW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 338 */
//CANTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CANTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 339 */
//CC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 340 */
//CCC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CCC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 341 */
//CDCD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CDCD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1100-0000-0000-000000000000")
	]
	}
})

/* 342 */
//CICD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CICD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0100-000000000000")
	]
	}
})

/* 343 */
//COR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "COR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 344 */
//CPI Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CPI"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 345 */
//CRATD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CRATD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 346 */
//CRCD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CRCD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0110-000000000000")
	]
	}
})

/* 347 */
//CV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 348 */
//CVP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "CVP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 349 */
//DA Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DA"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 350 */
//DAR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DAR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 351 */
//DASC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DASC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 352 */
//DCCDPD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DCCDPD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 353 */
//DCCDPDU Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DCCDPDU"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 354 */
//DCLF Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DCLF"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 355 */
//DCNTND Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DCNTND"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 356 */
//DCNTSD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DCNTSD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 357 */
//DCSC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DCSC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 358 */
//DCT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DCT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 359 */
//DDD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DDD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020100-0300-0000-0000-000000000000")
	]
	}
})

/* 360 */
//DDNSND Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DDNSND"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 361 */
//DDNTD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DDNTD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 362 */
//DDNTSD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DDNTSD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 363 */
//DDR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	Code: {
		$in: ['DDR']
	}
},
{
	"$set" : {
		"EntityUIds": [
			UUID("00020100-0300-0000-0000-000000000000"),
			UUID("00010060-0210-0000-0000-000000000000"),
			UUID("00020040-0040-0000-0000-000000000000"),
			UUID("00020040-0200-0000-0000-000000000000"),
			UUID("00020070-0600-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0060-000000000000"),
			UUID("00020040-0200-0010-0050-000000000000"),
			UUID("00020040-0200-0010-0040-000000000000")
		],
	}
})

/* 364 */
//DEV001 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV001"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 365 */
//DEV002 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV002"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 366 */
//DEV0043 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV0043"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 367 */
//DEV006 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV006"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 368 */
//DEV008 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV008"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 369 */
//DEV009 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV009"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 370 */
//DEV010 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV010"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 371 */
//DEV011 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV011"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 372 */
//DEV012 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV012"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 373 */
//DEV013 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV013"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 374 */
//DEV014 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV014"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 375 */
//DEV015 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV015"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 376 */
//DEV016 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV016"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 377 */
//DEV017 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV017"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 378 */
//DEV018 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV018"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 379 */
//DEV019 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV019"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 380 */
//DEV020 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV020"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 381 */
//DEV021 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV021"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 382 */
//DEV032 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV032"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 383 */
//DEV033 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV033"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 384 */
//DEV034 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV034"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 385 */
//DEV035 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV035"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 386 */
//DEV036 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV036"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 387 */
//DEV037 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV037"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 388 */
//DEV038 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV038"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0200-0000-0000-000000000000"),
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 389 */
//DEV039 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV039"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0200-0000-0000-000000000000"),
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 390 */
//DEV040 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV040"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0200-0000-0000-000000000000"),
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 391 */
//DEV041 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV041"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0200-0000-0000-000000000000"),
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 392 */
//DEV042 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV042"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 393 */
//DEV043 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV043"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 394 */
//DEV044 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV044"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 395 */
//DEV045 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV045"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 396 */
//DEV046 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV046"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 397 */
//DEV047 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV047"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 398 */
//DEV048 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV048"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 399 */
//DEV049 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV049"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 400 */
//DEV050 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV050"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 401 */
//DEV051 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV051"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 402 */
//DEV052 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV052"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 403 */
//DEV054 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV054"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 404 */
//DEV056 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV056"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 405 */
//DEV058 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV058"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 406 */
//DEV060 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV060"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 407 */
//DEV062 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV062"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 408 */
//DEV064 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV064"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 409 */
//DEV065 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV065"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 410 */
//DEV066 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV066"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 411 */
//DEV067 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV067"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 412 */
//DEV068 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV068"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 413 */
//DEV069 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV069"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 414 */
//DEV070 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV070"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 415 */
//DEV072 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV072"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 416 */
//DEV074 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV074"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 417 */
//DEV076 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV076"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 418 */
//DEV078 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV078"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 419 */
//DEV080 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV080"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 420 */
//DEV081 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV081"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 421 */
//DEV082 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV082"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 422 */
//DEV083 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV083"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 423 */
//DEV084 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV084"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 424 */
//DEV085 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV085"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 425 */
//DEV086 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV086"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 426 */
//DEV087 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV087"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 427 */
//DEV088 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV088"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 428 */
//DEV089 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV089"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 429 */
//DEV090 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV090"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 430 */
//DEV091 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV091"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 431 */
//DEV092 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV092"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 432 */
//DEV093 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV093"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 433 */
//DEV094 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV094"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 434 */
//DEV095 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV095"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1100-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 435 */
//DEV096 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DEV096"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1100-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
	}
})

/* 436 */
//DLTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DLTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 437 */
//DLWPW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DLWPW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 438 */
//DNSC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DNSC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 439 */
//DOTNSND Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DOTNSND"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 440 */
//DOTNTD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DOTNTD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 441 */
//DOTNTSD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DOTNTSD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 442 */
//DPQIAR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.updateMany({ Code: { $in: ['DPQIAR'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00020070-0600-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000"),
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	}
)

/* 443 */
//DPR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DPR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 444 */
//DPSPP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DPSPP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000"),
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 445 */
//DPSPR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DPSPR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 446 */
//DPSR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DPSR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000"),
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 447 */
//DPSS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DPSS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 448 */
//DR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DR"
},
{
	"$set" : {
		"EntityUIds": [
			UUID("00020100-0300-0000-0000-000000000000"),
			UUID("00020040-0200-0000-0000-000000000000"),
			UUID("00020070-0600-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000"),
			UUID("00020040-0200-0010-0050-000000000000"),
			UUID("00020040-0200-0010-0060-000000000000")
		]
	}
})

/* 449 */
//DRE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DRE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 450 */
//DRSPE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DRSPE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020100-0300-0000-0000-000000000000")
	]
	}
})

/* 451 */
//DTCLLWU Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "DTCLLWU"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 452 */
//EAD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "EAD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 453 */
//EDEV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "EDEV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 454 */
//EDV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "EDV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 455 */
//EEAP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "EEAP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 456 */
//EEAPR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "EEAPR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 457 */
//EPSP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "EPSP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 458 */
//EV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "EV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 459 */
//EVE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "EVE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 460 */
//FCP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "FCP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0030-000000000000"),
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 461 */
//FTRSPR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "FTRSPR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 462 */
//FTRSPS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "FTRSPS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 463 */
//GBP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "GBP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 464 */
//GEPA Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "GEPA"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 465 */
//GEPC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "GEPC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 466 */
//GPBP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "GPBP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 467 */
//GUBP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "GUBP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 468 */
//JC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "JC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000")
	]
	}
})

/* 469 */
//LOC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "LOC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 470 */
//LT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "LT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 471 */
//MCNSND Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "MCNSND"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 472 */
//MCNTD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "MCNTD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 473 */
//MCNTSD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "MCNTSD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 474 */
//MDNSND Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "MDNSND"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 475 */
//MDNTD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "MDNTD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 476 */
//MDNTSD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "MDNTSD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 477 */
//MOTNSND Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "MOTNSND"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 478 */
//MOTNTD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "MOTNTD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 479 */
//MOTNTSD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "MOTNTSD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 480 */
//MTTR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "MTTR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 481 */
//MVP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "MVP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 482 */
//NDDNTD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NDDNTD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 483 */
//NFR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NFR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 484 */
//NFUS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NFUS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 485 */
//NIMI Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NIMI"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 486 */
//NIMIPW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NIMIPW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 487 */
//NNFR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NNFR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 488 */
//NNFUS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NNFUS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 489 */
//NORR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NORR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 490 */
//NRNP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NRNP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 491 */
//NRPR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NRPR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 492 */
//NSALTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NSALTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 493 */
//NSANTFW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NSANTFW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 494 */
//NSANTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NSANTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 495 */
//NUNP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NUNP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 496 */
//NUR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NUR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 497 */
//NUSNR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NUSNR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 498 */
//NUSR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NUSR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 499 */
//NUUS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "NUUS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 500 */
//OACD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "OACD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 501 */
//OALTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "OALTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 502 */
//OANTFW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "OANTFW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 503 */
//OANTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "OANTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 504 */
//ODCD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ODCD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1100-0000-0000-000000000000")
	]
	}
})

/* 505 */
//ODD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ODD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 506 */
//OEV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "OEV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 507 */
//OICD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "OICD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0100-000000000000")
	]
	}
})

/* 508 */
//OPV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "OPV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000"),
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000")
	]
	}
})

/* 509 */
//ORCD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "ORCD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0110-000000000000")
	]
	}
})

/* 510 */
//PAOP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PAOP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00030010-0200-0000-0000-000000000000"),
		UUID("00020110-0110-0000-0000-000000000000"),
		UUID("00020110-0400-0000-0000-000000000000")
	]
	}
})

/* 511 */
//PCALTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PCALTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 512 */
//PCANTFW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PCANTFW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 513 */
//PCANTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PCANTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 514 */
//PCDSN Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PCDSN"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 515 */
//PCDT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PCDT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 516 */
//PCDTS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PCDTS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 517 */
//PCE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PCE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 518 */
//PDDSN Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PDDSN"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 519 */
//PDDT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PDDT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 520 */
//PDDTS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PDDTS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 521 */
//PDMSN Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PDMSN"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 522 */
//PDMT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PDMT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 523 */
//PDMTS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PDMTS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 524 */
//PEC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PEC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 525 */
//PECR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PECR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00020100-0300-0000-0000-000000000000")
	]
	}
})

/* 526 */
//PERACV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PERACV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 527 */
//PERASV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PERASV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 528 */
//PERSCR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PERSCR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 529 */
//PMCSN Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PMCSN"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 530 */
//PMCT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PMCT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 531 */
//PMCTS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PMCTS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 532 */
//PNSALTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PNSALTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 533 */
//PNSANTFW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PNSANTFW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 534 */
//PNSANTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PNSANTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 535 */
//PODALTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PODALTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 536 */
//PODANTFW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PODANTFW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 537 */
//PODANTW Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PODANTW"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-1000-0000-0000-000000000000")
	]
	}
})

/* 538 */
//POTDSN Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "POTDSN"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 539 */
//POTDT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "POTDT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 540 */
//POTDTS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "POTDTS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 541 */
//POTMSN Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "POTMSN"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 542 */
//POTMT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "POTMT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 543 */
//POTMTS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "POTMTS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000")
	]
	}
})

/* 544 */
//PPEC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PPEC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 545 */
//PPP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PPP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0030-000000000000")
	]
	}
})

/* 546 */
//PPR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PPR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 547 */
//PPS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PPS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 548 */
//PV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 549 */
//PVE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PVE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000")
	]
	}
})

/* 550 */
//PVS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "PVS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 551 */
//QLI Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "QLI"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 552 */
//RAC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RAC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 553 */
//RBDS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RBDS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 554 */
//RBP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RBP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 555 */
//RBPIAR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RBPIAR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 556 */
//RBUPS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RBUPS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 557 */
//RBVAll Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RBVAll"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 558 */
//RBVMustHave Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ Code: { $in: ['RBVMustHave'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00020040-0040-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000"),
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	}
)

/* 559 */
//RCAM Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RCAM"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 560 */
//RCAMCD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RCAMCD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 561 */
//RCT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RCT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 562 */
//RCTO Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RCTO"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 563 */
//RE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 564 */
//REPA Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "REPA"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 565 */
//REPC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "REPC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 566 */
//RNPP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RNPP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 567 */
//RNRP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RNRP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 568 */
//RP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 569 */
//RPBP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RPBP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 570 */
//RPRP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RPRP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 571 */
//RQV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RQV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0600-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 572 */
//RRP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RRP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 573 */
//RSP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RSP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 574 */
//RSRIP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RSRIP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000"),
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 575 */
//RSRIV Measure EntityUIds and WorkItemTypeUIds Update

db.clients.metrics.update({ Code: { $in: ['RSRIV'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00020070-0600-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000"),
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	}
)

/* 576 */
//RSV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RSV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 577 */
//RTFRAR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RTFRAR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 578 */
//RTFS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RTFS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 579 */
//RTSR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RTSR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 580 */
//RUBP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "RUBP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 581 */
//SARE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SARE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 582 */
//SBDE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SBDE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 583 */
//SBPIAS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SBPIAS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 584 */
//SDEV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SDEV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 585 */
//SDEVM Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SDEVM"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0900-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 586 */
//SEC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SEC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 587 */
//SPEPIAR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SPEPIAR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000"),
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 588 */
//SPI Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SPI"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 589 */
//SPVAll Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SPVAll"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 590 */
//SV Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SV"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 591 */
//SVAR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SVAR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 592 */
//SVARE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "SVARE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 593 */
//TADT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TADT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0600-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 594 */
//TAE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TAE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 595 */
//TAET Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.updateMany({
	"Code": { $in: ["TAET"] }
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00020090-0200-0000-0000-000000000000")
		], WorkItemTypeUIds: []
	}
})

/* 596 */
//TBP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TBP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 597 */
//TCPT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.updateMany({
	"Code": { $in: ["TCPT","TCET"] }
},
{
	"$set" : {
	"EntityUIds" : [
			UUID("00020090-0100-0000-0000-000000000000"),
			UUID("00020090-0200-0000-0000-000000000000")
	]
	}
})

/* 598 */
//TD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020080-0100-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 599 */
//TDT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TDT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 600 */
//TE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TE"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

/* 601 */
//TECP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TECP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0200-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 602 */
//TEPA Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TEPA"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 603 */
//TEPC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TEPC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0020-000000000000")
	]
	}
})

/* 604 */
//TES Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TES"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0200-0000-0000-000000000000"),
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 605 */
//TESP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TESP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0200-0000-0000-000000000000"),
		UUID("00040020-0300-0000-0000-000000000000"),
		UUID("00040020-0200-0000-0000-000000000000"),
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 606 */
//TFR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TFR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 607 */
//TFUS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TFUS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 608 */
//TNFR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TNFR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 609 */
//TNFUS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TNFUS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 610 */
//TNRNR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TNRNR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 611 */
//TOT Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TOT"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 612 */
//TPBP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TPBP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 613 */
//TSD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TSD"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00040020-0100-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	]
	}
})

/* 614 */
//TSP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TSP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 615 */
//TUBP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TUBP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 616 */
//TUCR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TUCR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020070-0700-0000-0000-000000000000")
	]
	}
})

/* 617 */
//TUCUS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "TUCUS"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 618 */
//USNPP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "USNPP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 619 */
//USNRP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "USNRP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 620 */
//USPR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "USPR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 621 */
//USPRP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "USPRP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 622 */
//USRP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "USRP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 623 */
//VAC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "VAC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	]
	}
})

/* 624 */
//VCLTY Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "VCLTY"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 625 */
//VEAP Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "VEAP"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 626 */
//VEAPR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "VEAPR"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000"),
		UUID("00020040-0040-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000")
	]
	}
})

/* 627 */
//WIC Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code" : "WIC"
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

//R6.2 related measures and metrics
/* 1 */
//AD149, AD139, AD106 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.updateMany({
	"Code" : {$in:["TAR","TSC"]}
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020090-0100-0000-0000-000000000000"),
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")]
	}
})


/* 2 */
//AD298, AD299 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.updateMany({
	"Code": { $in: ["AD298", "AD299", "DDUA"] }
},
	{
		"$set": {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0060-000000000000")]
		}
	})

	db.clients.metrics.updateMany({
		"Code": { $in: ["DCRC", "DCRH", "DCRM", "DCRL", "AD294", "AD295", "AD296", "AD297","AD300","DRP"]}
},
{
	"$set" : {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [UUID("00020040-0200-0010-0060-000000000000")
	]
	}
})

//R4.2 related measures and metrics
/* 1 */
//ADDM003 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ Code: { $in: ['ADDM003'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0060-000000000000"),
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	}
)

/* 2 */
//ADSM009 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "ADSM009"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000"),
			UUID("00020040-0040-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0050-000000000000"),
			UUID("00020040-0200-0010-0060-000000000000")
		]
	}
})

/* 3 */
//ADSM010 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "ADSM010"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000"),
			UUID("00020040-0040-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 4 */
//AGR012 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "AGR012"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000"),
			UUID("00020040-0200-0010-0060-000000000000")
		]
	}
})

/* 5 */
//AGS073 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "AGS073"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 6 */
//AGS074 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "AGS074"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 7 */
//AGS075 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "AGS075"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000"),
			UUID("00020040-0200-0010-0020-000000000000")
		]
	}
})

/* 8 */
//AGS076 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "AGS076"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000"),
			UUID("00020040-0200-0010-0020-000000000000")
		]
	}
})

/* 9 */
//APAS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "APAS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000"),
			UUID("00020040-0040-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000"),
			UUID("00020040-0200-0010-0050-000000000000"),
			UUID("00020040-0200-0010-0060-000000000000")
		]
	}
})

/* 10 */
//ATE Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "ATE"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000"),
			UUID("00020040-0200-0010-0060-000000000000")
		]
	}
})

/* 11 */
//GCS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "GCS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 12 */
//GECD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "GECD"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000"),
			UUID("00020040-0200-0010-0020-000000000000")
		]
	}
})

/* 13 */
//GPS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "GPS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 14 */
//GUPS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "GUPS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 15 */
//RCS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "RCS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 16 */
//RECD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "RECD"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000"),
			UUID("00020040-0200-0010-0020-000000000000")
		]
	}
})

/* 17 */
//RPS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "RPS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 18 */
//RUPS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "RUPS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 19 */
//TCGS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "TCGS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 20 */
//TCRS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "TCRS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 21 */
//TCS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "TCS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 22 */
//TCTS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "TCTS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 23 */
//TECD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "TECD"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000"),
			UUID("00020040-0200-0010-0020-000000000000")
		]
	}
})

/* 24 */
//TPS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "TPS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 25 */
//TUPS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "TUPS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 26 */
//UCS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "UCS"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000")
		]
	}
})

/* 27 */
//UECD Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "UECD"
}, {
	$set: {
		"EntityUIds": [
			UUID("00020040-0200-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0040-000000000000"),
			UUID("00020040-0200-0010-0020-000000000000")
		]
	}
})

//R4.4 Related Metrics and Measures
/* 1 */
//ACR Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ 
	"Code" : "ACR"
},
{
$set: {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000"),
		UUID("00010060-0210-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000"),
		UUID("00020040-0200-0010-0050-000000000000")
	]
}})

/* 2 */
//AD284 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ 
	"Code" : "AD284"
},
{
$set: {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
}})

/* 3 */
//AD285 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ 
	"Code" : "AD285"
},
{
$set: {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
}})

/* 4 */
//ADDM004 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ 
	"Code" : "ADDM004"
},
{
$set: {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0050-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
}})

/* 5 */
//AGS077 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ 
	"Code" : "AGS077"
},
{
$set: {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0060-000000000000")
	]
}})

/* 6 */
//AGS078 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ 
	"Code" : "AGS078"
},
{
$set: {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000")
	]
}})

/* 7 */
//DPQIAS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ 
	"Code" : "DPQIAS"
},
{
$set: {
	"EntityUIds" : [
		UUID("00020040-0200-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [
		UUID("00020040-0200-0010-0040-000000000000"),
		UUID("00020040-0200-0010-0060-000000000000"),
		UUID("00020040-0200-0010-0050-000000000000")
	]
}})

/* 8 */
//PPCS Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({ 
	"Code" : "PPCS"
},
{
$set: {
	"EntityUIds" : [
		UUID("00020100-0300-0000-0000-000000000000")
	],
	"WorkItemTypeUIds" : [ ]
}})

//TGR Metrics and Measures EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.updateMany({
	Code: {
		$in: ['AGS079', 'AGS080', 'AGS081', 'AGS082', 'AGS083', 'AGS084', 'AGS085', 'AGS086', 'AGS087',
			'AGS088', 'AGS089', 'OTECD', 'OGECD', 'ORECD', 'OUECD', 'OTPA', 'OTPC', 'OGPA', 'OGPC', 'ORPA', 'ORPC']
	}
},
	{
		$set: {
			"EntityUIds": [UUID("00020040-0200-0000-0000-000000000000")],
			"WorkItemTypeUIds": [UUID("00020040-0200-0010-0040-000000000000")]
		}
	})

//AD001,AD002,AD003 Measures EntityUId update
db.clients.metrics.updateMany({
	MetricUId: {
		$in: [UUID("10100000-0010-5620-0000-000000000000"),
		UUID("10100000-0010-5630-0000-000000000000"),
		UUID("10100000-0010-5640-0000-000000000000")]
	}
},
	{
		$addToSet: {
			EntityUIds: UUID("00020070-0600-0000-0000-000000000000")
		}
	},
)

//Metrics EntityUId update
db.clients.metrics.updateMany({
	Code: { $in: ['SPI', 'CPI', 'SV', 'CVP', 'AC', 'EV', 'PV'] }
},
	{
		$addToSet: {
			EntityUIds: UUID("00020070-0600-0000-0000-000000000000")
		}
	})

//AGS090,AGS091,AGS092,AGS105 EntityUIds and WorkItemTypeUIds update
db.clients.metrics.updateMany({ Code: { $in: ['AGS091', 'AGS092'] } },
	{
		$set: {
			"EntityUIds": [UUID("00020040-0200-0000-0000-000000000000")],
			"WorkItemTypeUIds": [UUID("00020040-0200-0010-0060-000000000000")]
		}
	}
)

db.clients.metrics.updateMany({ Code: { $in: [ 'AGS105', 'RDW'] } },
	{
		$set: {
			"EntityUIds": [UUID("00020040-0040-0000-0000-000000000000")],
			"WorkItemTypeUIds": []
		}
	}
)

db.clients.metrics.update({ Code: { $in: ['AP'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00010060-0210-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0040-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000")
			]
		}
	}
)

db.clients.metrics.updateMany({ Code: { $in: ['ODR', 'ADDR'] } },
	{
		$set: {
			"EntityUIds": [UUID("00020040-0200-0000-0000-000000000000")],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0040-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000")
			]
		}
	}
)

db.clients.metrics.updateMany({
	Code: {
		$in: ['TNRH', 'TNRL', 'TNRM']
	}
},
	{
		$set: {
			"EntityUIds": [
				UUID("00020070-0700-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": []
		}
	})

//NRY,AGS090 Updation

db.clients.metrics.updateMany({
	"Code": {
		$in: ["NRY", "AGS090"]
	}
},
{
		"$set": {
			"EntityUIds": [
				UUID("00040020-0500-0000-0000-000000000000"),
				UUID("00040020-0400-0000-0000-000000000000"),
				UUID("00040020-0300-0000-0000-000000000000"),
				UUID("00020040-0040-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": []
		}
	})



db.clients.metrics.updateMany({
	Code: {
		$in: ['VIT', 'VPT', 'ADSM011', 'ADSM012'] } },
	{
		$set: {
			"EntityUIds": [UUID("00020040-0200-0000-0000-000000000000"), UUID("00020040-0040-0000-0000-000000000000")],
			"WorkItemTypeUIds": [UUID("00020040-0200-0010-0040-000000000000"), UUID("00020040-0200-0010-0030-000000000000")]
		}
	}
)

db.clients.metrics.updateMany({ Code: { $in: ['PPPS','ADSM023','ADSM024'] } },
	{
		$set: {
			"EntityUIds": [UUID("00020040-0200-0000-0000-000000000000")],
			"WorkItemTypeUIds": [UUID("00020040-0200-0010-0030-000000000000")]
		}
	}
)

db.clients.metrics.updateMany({ Code: { $in: [ 'APCP', 'APCF', 'AUCT', 'PCEP', 'ADSM013', 'ADSM014', 'ADSM017', 'ADSM018', 'ADSM028', 'ADSM029', 'ADSM030','ADSM031'] } },
	{
		$set: {
			"EntityUIds": [UUID("00020040-0200-0000-0000-000000000000")],
			"WorkItemTypeUIds": [UUID("00020040-0200-0010-0040-000000000000"), UUID("00020040-0200-0010-0030-000000000000")]
		}
	}
)

db.clients.metrics.updateMany({
	Code: {
		$in: ['ANV']
	}
},
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00020070-0600-0000-0000-000000000000"),
				UUID("00020040-0040-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [UUID("00020040-0200-0010-0040-000000000000"), UUID("00020040-0200-0010-0060-000000000000"), UUID("00020040-0200-0010-0050-000000000000")]
		}
	}
)
db.clients.metrics.update({
	Code: {
		$in: ['ADSM032']
	}
},
	{
		$set: {
			"EntityUIds": [UUID("00020040-0200-0000-0000-000000000000"),
			UUID("00020040-0040-0000-0000-000000000000")],
			"WorkItemTypeUIds": [UUID("00020040-0200-0010-0040-000000000000")]
		}
	}
)
db.clients.metrics.update({
	Code: {
		$in: ['ADSM033']
	}
},
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00020040-0040-0000-0000-000000000000"),
				UUID("00020070-0600-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0060-000000000000"),
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	}
)

db.clients.metrics.update({
	Code: {
		$in: ['ATF']
	}
},
	{
		$set: {
			"EntityUIds": [UUID("00020040-0200-0000-0000-000000000000"),
			UUID("00020040-0040-0000-0000-000000000000"),
			UUID("00020090-0100-0000-0000-000000000000")],
			"WorkItemTypeUIds": [UUID("00020040-0200-0010-0060-000000000000")]
		}
	}
)
db.clients.metrics.update({
	Code: {
		$in: ['ADSM034']
	}
},
	{
		$set: {
			"EntityUIds": [UUID("00020040-0200-0000-0000-000000000000")],
			"WorkItemTypeUIds": [UUID("00020040-0200-0010-0060-000000000000")]
		}
	}
)
db.clients.metrics.update({
	Code: {
		$in: ['ADSM035']
	}
},
	{
		$set: {
			"EntityUIds": [UUID("00020090-0100-0000-0000-000000000000"), UUID("00020040-0040-0000-0000-000000000000")],
			"WorkItemTypeUIds": []
		}
	}
)
db.clients.metrics.updateMany({
	Code: {
		$in: ['ADD']
	}
},
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00010060-0210-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0060-000000000000"),
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0040-000000000000")]
		}
	}
)

db.clients.metrics.updateMany({
	Code: {
		$in: ['ADA022']
	}
},
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00010060-0210-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0040-000000000000")]
		}
	}
)

db.clients.metrics.updateMany({ Code: { $in: ['UTC', 'UTCC', 'DEV105', 'DEV106'] } },
	{
		$set: {
			"EntityUIds": [UUID("00040020-0300-0000-0000-000000000000")],
			"WorkItemTypeUIds": []
		}
	}
)
db.clients.metrics.updateMany({ Code: { $in: ['RTC', 'ADA024'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020070-0700-0000-0000-000000000000"),
				UUID("00020040-0040-0000-0000-000000000000"),
				UUID("00020090-0100-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": []
		}
	}
)


db.clients.metrics.updateMany({ Code: { $in: ['ADSM039', 'ADSM040', 'TAPA'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020090-0100-0000-0000-000000000000"),
				UUID("00020040-0040-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": []
		}
	}
)


//ComputationLevel Update for the Manual Metrics

db.clients.metrics.updateMany({ Code: { $in: ['SPEM', 'SPPE', 'RPA', 'ERDS', 'ERRA', 'PITE', 'SVAR'] } },
	{
		$set: {
			ComputationLevel: ["Sprint"]
		}
	}
)

db.clients.metrics.updateMany({ Code: { $in: ['ESOR', 'ERID', 'EROS', 'EOR', 'RTEE', 'EIIA', 'PERP', 'PIOP'] } },
	{
		$set: {
			ComputationLevel: ["Release"]
		}
	}
)

db.clients.metrics.updateMany({ Code: { $in: ['EIRG', 'APAS', 'DCUS', 'PISC', 'PIUS'] } },
	{
		$set: {
			ComputationLevel: ["Release", "Sprint"]
		}
	}
)

db.clients.metrics.updateMany({ Code: { $in: ['ACRL'] } },
	{
		$set: {
			ComputationLevel: ["DC", "Release"]
		}
	}
)


//AD099 and AD100 Update
db.clients.metrics.updateMany({
	Code: {
		$in: ["DCT", "AD099", "AD100"]
	}
},
	{
		$set: {
			"EntityUIds": [
				UUID("00020080-0100-0000-0000-000000000000"),
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0060-000000000000")
			]
		}
	})

db.clients.metrics.updateMany({
	Code: {
		$in: ["EDV", "AD131", "AD132", "AD133"]
	}
},
	{
		$set: {
			"EntityUIds": [
				UUID("00020100-0300-0000-0000-000000000000"),
				UUID("00020070-0600-0000-0000-000000000000"),
				UUID("00020070-0900-0000-0000-000000000000"),
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0050-000000000000")
			]
		}
	})


db.clients.metrics.updateMany({
	Code: {
		$in: ["ADRM005", "ADRM007", "RBPIAR"]
	}
},
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00020070-0600-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0040-000000000000"),
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000")
			]
		}
	})

db.clients.metrics.updateMany({
	Code: {
		$in: ["SPEPIAR", "ADRM008", "AGR038", "ADRM006", "ADRM005", "ADRM017"]
	}
},
	{
		$set: {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000"),
				UUID("00020070-0600-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0040-000000000000"),
				UUID("00020040-0200-0010-0050-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000")
			]
		}
	})

db.clients.metrics.updateMany({ Code: { $in: ['SPI', 'AD001', 'AD002'] } },
	{
		$set: {
			"EntityUIds": [
				UUID("00020100-0300-0000-0000-000000000000"),
				UUID("00020070-0600-0000-0000-000000000000"),
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [UUID("00020040-0200-0010-0050-000000000000")]
		}
	}
)

//AD121 Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.update({
	"Code": "AD121"
},
{
	"$set": {
		"EntityUIds": [
			UUID("00020100-0300-0000-0000-000000000000"),
			UUID("00010060-0210-0000-0000-000000000000"),
			UUID("00020040-0040-0000-0000-000000000000"),
			UUID("00020040-0200-0000-0000-000000000000"),
			UUID("00020070-0600-0000-0000-000000000000")
		],
		"WorkItemTypeUIds": [
			UUID("00020040-0200-0010-0050-000000000000"),
			UUID("00020040-0200-0010-0040-000000000000"),
			UUID("00020040-0200-0010-0060-000000000000")
		]
	}
})

print("EntityUIds and WorkItemTypeUIds Update Completed!");

print("AppServiceUIds_AddedFor_Metrics started!")

print("SI Landing Page Started!")


db.clients.metrics.updateMany({
	"Code": {
		$in: ["RTFRAR", "APBI", "APSI", "CV", "NIMI", "NIMIPW", "PCALTW", "PCANTFW", "PCANTW", "PCDSN", "PCDT", "PCDTS"
			, "PDDSN", "PDDT", "PDDTS", "PDMSN", "PDMT", "PDMTS", "PERACV", "PERASV", "PMCSN", "PMCT", "PMCTS", "PNSALTW", "PNSANTFW"
			, "PNSANTW", "PODALTW", "PODANTFW", "PODANTW", "POTDSN", "POTDT", "POTDTS", "POTMSN", "POTMT", "POTMTS", "RBPIAR", "RNPP"
			, "RNRP", "RPRP", "RRP", "SV", "TFR", "TFUS", "TNFR", "TNFUS", "TUCR", "TUCUS", "USNPP", "USNRP", "USPRP", "USRP"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00040700-0000-0000-0000-000000000000")
				]
			}
		}
	})

print("SI Landing Page Ended!")

print("Unified Backlog Started!")

db.clients.metrics.updateMany({
	"Code": {
		$in: ["GCS", "GECD", "GPS", "GUPS", "RCS", "RECD", "RPBP", "RPS", "RUBP", "RUPS", "TCGS"
			, "TCRS", "TCS", "TCTS", "TECD", "TPS", "TUPS", "UCS", "UECD"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00050450-0000-0000-0000-000000000000")
				]
			}
		}
	})

print("Unified Backlog Ended!")

print("PI Planner Started!")

db.clients.metrics.updateMany({
	"Code": { $in: ["VIT", "VPT"] }
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00050420-0000-0000-0000-000000000000")
				]
			}
		}
	})


print("PI Planner Ended!")

print("IngrAin(VDS - Predictive) Started!")

db.clients.metrics.updateMany({
	"Code": { $in: ["ANTCC", "DR", "EDV", "EV", "PV", "SPI"] }
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00040560-0000-0000-0000-000000000000")
				]
			}
		}
	})

print("IngrAin(VDS - Predictive) Ended!")

print("Sprint Planner Started!")

db.clients.metrics.updateMany({
	"Code": { $in: ["AERS", "SVAR"] }
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00020210-0000-0000-0000-000000000000")
				]
			}
		}
	})

print("Sprint Planner Ended!")

print("Daily Standup Started!")

db.clients.metrics.updateMany({
	"Code": { $in: ["AERS", "CV", "TE", "TSP"] }
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00040450-0000-0000-0000-000000000000")
				]
			}
		}
	})
print("Daily Standup Ended!")

print("Release Planner Started!")


db.clients.metrics.updateMany({
	"Code": { $in: ["DPR", "DPSS", "SVAR", "SVARE"] }
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00050420-0000-0000-0000-000000000000")
				]
			}
		}
	})


print("Release Planner Ended!")

print("Milestones and Deliverables Assistant Started!")


db.clients.metrics.updateMany({
	"Code": { $in: ["EVE", "OEV", "OPV", "PVE", "SDEV"] }
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00040620-0000-0000-0000-000000000000")
				]
			}
		}
	})

print("Milestones and Deliverables Assistant Ended!")

print("Roadmap Assistant Started!")


db.clients.metrics.updateMany({
	"Code": {
		$in: ["RTFRAR", "RTFS", "ACRL", "ACS", "ACT", "ALT", "APCP", "APCS", "APR", "APSAR", "AUCT", "CC", "CCC", "CPI", "CV", "DCT",
			"DPQIAR", "DRE", "DRSPE", "EDV", "LOC", "PCEP", "PEC", "PERSCR", "PPCS", "PPEC", "PPR", "PPS", "QLI", "RBPIAR", "RBVMustHave", "RSRIP",
			"RSRIV", "RSV", "SBPIAS", "SDEV", "SPEPIAR", "SPI", "SV", "SVAR", "TD", "TDT", "TES", "TESP", "TOT", "TSD", "TSP", "VAC", "VCLTY", "VIT", "VPT"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00040470-0000-0000-0000-000000000000")
				]
			}
		}
	})


print("Roadmap Assistant Ended!")

print("Virtual Agents Started!")


db.clients.metrics.updateMany({
	"Code": {
		$in: ["RTFRAR", "RTFS", "APBI", "APSI", "BMAD", "BMSBAD", "CPI", "CVP"
			, "DAR", "DASC", "DCT", "DDD", "DLTW", "DPQIAR", "DRE", "EDV", "EEAPR", "FTRSPR", "GCS"
			, "PPS", "PVS", "RBDS", "RBPIAR", "RBVMustHave", "RCT", "RP", "RSP", "RSRIP", "RSRIV"
			, "RSV", "RTSR", "SBDE", "SPEPIAR", "SPI", "SPVAll", "SV", "TD", "TE", "TECD", "USRP"
			, "VAC", "VCLTY", "VEAPR"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00010150-0000-0000-0000-000000000000")
				]
			}
		}
	})


print("Virtual Agents Ended!")

print("myWizard SI Analytics (PowerBI) Started!")


db.clients.metrics.updateMany({
	"Code": { $in: ["AERS", "CV", "RE", "RSP", "TE", "TSP"] }
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00061040-0000-0000-0000-000000000000")
				]
			}
		}
	})


print("myWizard SI Analytics (PowerBI) Ended!")

print("Virtual Data Scientist Started!")


db.clients.metrics.updateMany({
	"Code": {
		$in: ["CACD", "CDCD", "CICD", "CRCD", "OACD", "ODCD", "OICD", "ORCD", "AC", "AE", "AERS", "AWCP", "BWCP"
			, "CPI", "CV", "DAR", "DCCDPD", "DCCDPDU", "DCT", "DDD", "DLWPW", "DR", "DRE", "DTCLLWU", "EEAP", "EEAPR", "EV", "PV"
			, "RAC", "RCT", "RCTO", "RE", "RSP", "SARE", "SPI", "TE", "TESP", "TSP", "VAC"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00020120-0000-0000-0000-000000000000")
				]
			}
		}
	})


print("Virtual Data Scientist Ended!")

print("AppServiceUIds_AddedFor_Metrics ended!");


print("EntityUIds and WorkItemTypeUIds Update Script execution Started!");

db.clients.metrics.updateMany({
	"Code": { $in: ["AD301"] }
},
	{
		"$set": {
			"EntityUIds": [
				UUID("00020090-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": []
		}
	})

print("EntityUIds and WorkItemTypeUIds Update Script execution Completed!");


//MeasureAssociations update for all the active metrics
//Measure Association Add for  Metric 
var metricDetails = db.getCollection("clients.metrics").find({
	MetricTypeUId: UUID("00101060-0010-0000-0000-000000000000"),
	RowStatusUId: UUID("00100000-0000-0000-0000-000000000000"),
	Formula: { $ne: null },
	MeasureAssociations: {
		$in: ["", null, []]
	},
}, {
	'MetricUId': 1, Name: 1, "Code": 1,
	"Description": 1,
	"Formula": 1
});

//print(_currentDate)

print('MeasureAssociation Update Started');

metricDetails.forEach(function (_metric) {
	db.clients.metrics.updateMany({ Code: _metric.Code },
		{ $unset: { 'MeasureAssociations': '' } })
	var commaSeparatedFormula = _metric.Formula.replace(/\(/g, "").replace(/\)/g, "").replace(/\+/g, ",").replace(/\-/g, ",").replace(/\//g, ",").replace(/\*/g, ",").replace(/ /g, "");
	// print(commaSeparatedFormula);
	var splittedFormula = commaSeparatedFormula.split(',');
	splittedFormula = splittedFormula.filter(fetchUniqueData)
	//print('splittedFormula: '+ splittedFormula.toString());
	splittedFormula.forEach(function (_measureCode) {
		if (isNaN(_measureCode)) {
			// print('Measure code: '+ _measureCode);
			var measureData =
				db.getCollection("clients.metrics").find({
					Code: _measureCode
				});


			// print(measureData[0])
			if (measureData[0] != undefined) {
				print('Measure Association update for Metric ' + _metric.Code + ' -- Measure code: ' + _measureCode);

				db.clients.metrics.update(
					{
						Code: _metric.Code
					},
					{
						$addToSet: {
							MeasureAssociations: {

								"MeasureUId": measureData[0].MetricUId,
								"MeasureCode": measureData[0].Code,
								"MeasureName": measureData[0].Name,
								"MeasureDescription": measureData[0].Description

							}
						}
					}
				)

			}

		}
	});


});

print('MeasureAssociation Update completed');

function fetchUniqueData(value, index, self) {
	return self.indexOf(value) === index;
}

print("metricservicerunhistory insertion started!");

var _currentDate = new ISODate();
var _curTick = GetTicks(_currentDate);

function GetTicks(_currentDate) {
	var epochTicks = 621355968000000000;
	var ticksPerMillisecond = 10000;
	var convertedTicks = epochTicks + _currentDate * ticksPerMillisecond;
	return convertedTicks;
}


if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Event", "Process": "Measure", "ProcessState": "Start", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsEventService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsEventService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0010-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111001),
			"RunType": "Event",
			"Process": "Measure",
			"ProcessState": "Start",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Event", "Process": "Measure", "ProcessState": "Completed", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsEventService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsEventService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0020-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111002),
			"RunType": "Event",
			"Process": "Measure",
			"ProcessState": "Completed",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Event", "Process": "Metric", "ProcessState": "Start", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsEventService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsEventService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0030-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111003),
			"RunType": "Event",
			"Process": "Metric",
			"ProcessState": "Start",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Event", "Process": "Metric", "ProcessState": "Completed", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsEventService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsEventService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0040-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111004),
			"RunType": "Event",
			"Process": "Metric",
			"ProcessState": "Completed",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Scheduled", "Process": "Measure", "ProcessState": "Start", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsScheduledService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsScheduledService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0050-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111005),
			"RunType": "Scheduled",
			"Process": "Measure",
			"ProcessState": "Start",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Scheduled", "Process": "Measure", "ProcessState": "Completed", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsScheduledService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsScheduledService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0060-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111006),
			"RunType": "Scheduled",
			"Process": "Measure",
			"ProcessState": "Completed",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Scheduled", "Process": "Metric", "ProcessState": "Start", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsScheduledService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsScheduledService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0070-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111007),
			"RunType": "Scheduled",
			"Process": "Metric",
			"ProcessState": "Start",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Scheduled", "Process": "Metric", "ProcessState": "Completed", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsScheduledService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsScheduledService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0080-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111008),
			"RunType": "Scheduled",
			"Process": "Metric",
			"ProcessState": "Completed",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Event", "Process": "Archival", "ProcessState": "Start", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsEventService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsEventService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0090-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111009),
			"RunType": "Event",
			"Process": "Archival",
			"ProcessState": "Start",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Event", "Process": "Archival", "ProcessState": "Completed", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsEventService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsEventService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0100-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111010),
			"RunType": "Event",
			"Process": "Archival",
			"ProcessState": "Completed",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Scheduled", "Process": "Archival", "ProcessState": "Start", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsScheduledService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsScheduledService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0110-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111011),
			"RunType": "Scheduled",
			"Process": "Archival",
			"ProcessState": "Start",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

if (!(db.clients.metricservicerunhistory.findOne({ "RunType": "Scheduled", "Process": "Archival", "ProcessState": "Completed", }))) {
	db.getCollection("clients.metricservicerunhistory").insert(
		{
			"CreatedByUser": "SYSTEM",
			"CreatedByApp": "MetricsScheduledService",
			"CreatedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"ModifiedByUser": "SYSTEM",
			"ModifiedByApp": "MetricsScheduledService",
			"ModifiedOn": {
				"DateTime": _currentDate,
				"Ticks": _curTick
			},
			"MetricServiceRunUId": UUID("10100010-0010-0120-0000-000000000000"),
			"MetricServiceRunId": NumberLong(111012),
			"RunType": "Scheduled",
			"Process": "Archival",
			"ProcessState": "Completed",
			"ComputedCount": 0,
			"RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
		}
	)
}

print("metricservicerunhistory insertion completed!");


db.clients.metrics.updateMany({
	"Code": {
		$in: ["ERDS","PISC"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00040450-0000-0000-0000-000000000000")
				]
			}
		}
	})
	
db.clients.metrics.updateMany({
	"Code": {
		$in: ["EROS","EOR"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00040200-0000-0000-0000-000000000000")
				]
			}
		}
	})

db.clients.metrics.updateMany({
	"Code": {
		$in: ["ERRA","SVAR"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00020200-0000-0000-0000-000000000000")
				]
			}
		}
	})

db.clients.metrics.updateMany({
	"Code": {
		$in: ["SPEM","SPPE","RPA","SVAR","APAS"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00020210-0000-0000-0000-000000000000")
				]
			}
		}
	})

db.clients.metrics.updateMany({
	"Code": {
		$in: ["RTEE"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00040230-0000-0000-0000-000000000000")
				]
			}
		}
	})

db.clients.metrics.updateMany({
	"Code": {
		$in: ["EIIA","PITE"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00040090-0000-0000-0000-000000000000")
				]
			}
		}
	})

db.clients.metrics.updateMany({
	"Code": {
		$in: ["ERID","PERP","PISC"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00010150-0000-0000-0000-000000000000")
				]
			}
		}
	})

db.clients.metrics.updateMany({
	"Code": {
		$in: ["EIRG","ESOR","PERP","PIOP","PISC"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00020120-0000-0000-0000-000000000000")
				]
			}
		}
	})

db.clients.metrics.updateMany({
	"Code": {
		$in: ["SVAR", "APAS", "DCUS", "PIUS"]
	}
},
	{
		$addToSet: {
			"AppServiceUIds":
			{
				$each: [
					UUID("00040210-0000-0000-0000-000000000000")
				]
			}
		}
	})

//EH development Measure EntityUIds and WorkItemTypeUIds Update
db.clients.metrics.updateMany({
	"Code": { $in: ["PIS", "RPI", "SBDR"] }
},
	{
		"$set": {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	})


db.clients.metrics.updateMany({
	"Code": { $in: ["TCR","AGS106","AGS107"] }
},
	{
		"$set": {
			"EntityUIds": [
				UUID("00020090-0200-0000-0000-000000000000"),
				UUID("00020090-0100-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
			]
		}
	})

db.clients.metrics.update({
	"Code": { $in: ["BDR"] }
},
	{
		"$set": {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0040-000000000000"),
				UUID("00020040-0200-0010-0060-000000000000")
			]
		}
	})

db.clients.metrics.update({
	"Code": { $in: ["AGS111"] }
},
	{
		"$set": {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0060-000000000000")
			]
		}
	})

db.clients.metrics.updateMany({
	"Code": { $in: ["AGS108", "AGS109", "AGS110", "AGS112","AGS113"] }
},
	{
		"$set": {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	})

//EH Phase2 metrics and measures
db.clients.metrics.updateMany({
	"Code": { $in: ["DRD", "TER", "AGS114", "AGS115", "AGS116", "AGS117"] }
},
	{
		"$set": {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0060-000000000000")
			]
		}
	})

db.clients.metrics.updateMany({
	"Code": { $in: ["VRAS", "AGS118"] }
},
	{
		"$set": {
			"EntityUIds": [
				UUID("00020040-0200-0000-0000-000000000000")
			],
			"WorkItemTypeUIds": [
				UUID("00020040-0200-0010-0040-000000000000")
			]
		}
	})
