param (

    [Parameter(Mandatory = $true)]
    $reportType = "",

    [Parameter(Mandatory = $true)]
    $nodeName = "192.168.16.83"
)

$keys = @("ToolInstanceUId",
            "LibraryFilePath",
            "ServiceUrl",
            "CollectionName",
            "ProjectName",
            "ProjectKey",
            "ServiceResourceUrl",
            "SprintUrl",
            "AuthUrl",
            "SharedAccessKeyName",
            "SASUri",
            "ContainerName",
            "ProjectExtension",
            "BoardExtension",
            "Domain",
            "UserName",
            "Token",
            "StorageAccount",
            "StorageKey",
            "TargetURL",
            "NewFolderPath")


$pipelines = (Get-ChildItem -Path "/var/www/GatewayManager/ProcessPipelines" -Directory).FullName
$output = @()
Clear-Host

$output += '<style>
    table {
        border-collapse: collapse;
        width: 80%;
        margin: auto auto;
        font-family: Calibri;
    }
    tr{
        border: 1px solid silver;
    }
    tr:nth-child(2n+1){
        background-color: #f8f8f8;
    }
    td{
        padding: 0 0 0 10px;
        word-wrap: break-word;
        word-break: break-all;
    }
    .pipeline {
        background-color: #7b7b7b!important;
        color: #FFF;
        font-weight: bold;
        height: 25px;
    }
    .config{
        background-color: silver!important;
        height: 20px;
    }
</style>'

$output += "<table>"

foreach ($pipe in $pipelines) {
    $output += "    <tr class='pipeline'>"
    $output += "        <td style='width: 20%;'><b>Pipeline Name</b></td>"
    $output += $("        <td style='width: 80%;'>"+$(Split-Path -Path $pipe -Leaf)+"</td>")
    $output += "    </tr>"

    $configs = (Get-ChildItem -Path $pipe -File -Filter "*.config.xml").FullName

    foreach($file in $configs) {
        $output += "    <tr class='config'>"
        $output += "        <td style='width: 20%;'><b>Config File</b></td>"
        $output += $("        <td style='width: 80%;'>"+$file+"</td>")
        $output += "    </tr>"

        $content = Get-Content -Raw -Path $file
        
        foreach($key in $keys) {
            $value = $(([regex]($('(^|\b)' + $key + '+\s*=\s*"(.+?)"'))).Match($content).Value)



            if($value -ne "") {

                $value = '<b>' + $value
                $value = $value.Replace("=","</b>=")

                $output += "    <tr>"
                $output += $("        <td colspan='2'>"+$value+"</td>")
                $output += "    </tr>"
            }
        }
    }
    $output += "    <tr style='border: 0px solid transparent; background-color: #FFF;'>"
    $output += "        <td colspan='2'>&nbsp;</td>"
    $output += "    </tr>"
}

$output += "</table>"

$output
$output | Set-Content -Path $("/mnt/win/myWizardSource/Logs/"+$reportType+"_gm-config-extracts_"+$nodeName+".html")