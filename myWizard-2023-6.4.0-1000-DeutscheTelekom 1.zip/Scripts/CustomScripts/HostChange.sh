for file in $(find /var/www/ -name 'appsettings.json')
do
sed -i 's|\"hostingUrl\":\"http://localhost|\"hostingUrl\":\"http://0.0.0.0|g' $file
sed -i 's|\"hostingUrl\": \"http://localhost|\"hostingUrl\": \"http://0.0.0.0|g' $file
done
