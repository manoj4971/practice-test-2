db.productinstances.find({
    "RowStatusUId": UUID("00100000-0000-0000-0000-000000000000")
}).forEach(function (productinstance) {
    productinstance.ProductInstanceEntities = []
    db.products.find({
        "ProductVersions.ProductVersionUId": productinstance.ProductVersionUId

    }).forEach(function (product) {
        product.ProductVersions.forEach(function (ProductVersion) {
            if (ProductVersion.ProductVersionUId.hex().toString() == productinstance.ProductVersionUId.hex().toString()) {
                if (ProductVersion.ProductVersionEntities != null) {
                    ProductVersion.ProductVersionEntities.forEach(function (ProductVersionEntitie) {
                        var IsDeliverableEntity = "N"
                        var IsIterationEntity = "N"
                        var IsMilestoneEntity = "N"
                        var IsBPHNodeEntity = "N"
                        var IsArtifactEntity = "N"
                        if (ProductVersionEntitie.EntityUId.hex().toString() == UUID("00020070-0600-0000-0000-000000000000").hex().toString()) {
                            IsDeliverableEntity = "Y"

                        }
                        if (ProductVersionEntitie.EntityUId.hex().toString() == UUID("00020040-0040-0000-0000-000000000000").hex().toString()) {
                            IsIterationEntity = "Y"

                        }
                        if (ProductVersionEntitie.EntityUId.hex().toString() == UUID("00020070-0900-0000-0000-000000000000").hex().toString()) {
                            IsMilestoneEntity = "Y"

                        }
                        if (ProductVersionEntitie.EntityUId.hex().toString() == UUID("00020100-0500-0000-0000-000000000000").hex().toString()) {
                            IsBPHNodeEntity = "Y"

                        }
                        if (ProductVersionEntitie.EntityUId.hex().toString() == UUID("00020100-0400-0000-0000-000000000000").hex().toString()) {
                            IsArtifactEntity = "Y"
                        }
                        var productInstanceEntityProperties = []
                        if (ProductVersionEntitie.ProductVersionEntityProperties != null) {
                            ProductVersionEntitie.ProductVersionEntityProperties.forEach(function (ProductVersionEntityProperty) {
                                var productInstanceEntityPropertyValues = []
                                if (ProductVersionEntityProperty.ProductVersionEntityPropertyValues != null) {
                                    ProductVersionEntityProperty.ProductVersionEntityPropertyValues.forEach(function (ProductVersionEntityPropertyValue) {
                                        var ProductInstancePropertyValueUID = "";
                                        if (ProductVersionEntityPropertyValue.ProductPropertyValueUId != null) {
                                            hex = ProductVersionEntityPropertyValue.ProductPropertyValueUId.hex().toString()
                                            var ProductInstancehex = productinstance.ProductInstanceUId.hex().toString()

                                            ProductInstancePropertyValueUID = ProductInstancehex.substr(0, 8) + '-' + ProductInstancehex.substr(8, 4) + '-' + ProductInstancehex.substr(12, 4) + '-' + ProductInstancehex.substr(16, 4) + '-' + hex.substr(20, 12);

                                            if (IsDeliverableEntity == "Y") {
                                                var deliverablehex = ProductVersionEntityPropertyValue.ProductPropertyValueUId.hex().toString()
                                                ProductInstancePropertyValueUID = deliverablehex.substr(0, 8) + '-' + deliverablehex.substr(8, 4) + '-' + deliverablehex.substr(12, 4) + '-' + deliverablehex.substr(16, 4) + '-' + hex.substr(20, 12);

                                            }
                                            if (IsIterationEntity == "Y") {
                                                var hex = ProductVersionEntityPropertyValue.ProductPropertyValueUId.hex().toString()
                                                ProductInstancePropertyValueUID = hex.substr(0, 8) + '-' + hex.substr(8, 4) + '-' + hex.substr(12, 4) + '-' + hex.substr(16, 4) + '-' + hex.substr(20, 12);

                                            }
                                            if (IsMilestoneEntity == "Y") {
                                                var hex = ProductVersionEntityPropertyValue.ProductPropertyValueUId.hex().toString()
                                                ProductInstancePropertyValueUID = hex.substr(0, 8) + '-' + hex.substr(8, 4) + '-' + hex.substr(12, 4) + '-' + hex.substr(16, 4) + '-' + hex.substr(20, 12);
                                            }
                                            if (IsBPHNodeEntity == "Y") {
                                                var hex = ProductVersionEntityPropertyValue.ProductPropertyValueUId.hex().toString()
                                                ProductInstancePropertyValueUID = hex.substr(0, 8) + '-' + hex.substr(8, 4) + '-' + hex.substr(12, 4) + '-' + hex.substr(16, 4) + '-' + hex.substr(20, 12);
                                            }
                                            if (IsArtifactEntity == "Y") {
                                                var hex = ProductVersionEntityPropertyValue.ProductPropertyValueUId.hex().toString()
                                                ProductInstancePropertyValueUID = hex.substr(0, 8) + '-' + hex.substr(8, 4) + '-' + hex.substr(12, 4) + '-' + hex.substr(16, 4) + '-' + hex.substr(20, 12);
                                            }

                                            productInstanceEntityPropertyValues.push({
                                                "CreatedByUser": "systemadmin@mwphoenix.onmicrosoft.com",
                                                "CreatedByApp": "myWizard-Phoenix",
                                                "CreatedOn": {
                                                    "DateTime": ISODate("2020-03-23T13:51:51.818+05:30"),
                                                    "Ticks": NumberLong("637205485118180000")
                                                },
                                                "ModifiedByUser": "systemadminui@mwphoenix.onmicrosoft.com",
                                                "ModifiedByApp": "myWizard-Phoenix",
                                                "ModifiedOn": {
                                                    "DateTime": ISODate("2020-03-24T17:22:12.337+05:30"),
                                                    "Ticks": NumberLong("637206475323370000")
                                                },

                                                "ProductInstanceEntityPropertyValueUId": ProductVersionEntityPropertyValue.ProductVersionEntityPropertyValueUId,
                                                "ProductInstanceEntityPropertyValueId": ProductVersionEntityPropertyValue.ProductVersionEntityPropertyValueId,
                                                "ProductInstanceEntityPropertyUId": ProductVersionEntityProperty.ProductVersionEntityPropertyUId,
                                                "ProductInstanceUId": productinstance.ProductInstanceUId,
                                                "EntityPropertyUId": ProductVersionEntityPropertyValue.EntityPropertyUId,
                                                "EntityPropertyValue": ProductVersionEntityPropertyValue.PropertyValue,
                                                "ProductPropertyValue": ProductVersionEntityPropertyValue.ProductPropertyValue,
                                                "ProductPropertyValueUId": UUID(ProductInstancePropertyValueUID),
                                                "ProductPropertyValueDisplayName": ProductVersionEntityPropertyValue.ProductPropertyValueDisplayName,
                                                "DisplayOrder": ProductVersionEntityPropertyValue.DisplayOrder,
                                                "IsProductPropertyDefaultValue": ProductVersionEntityPropertyValue.IsProductPropertyDefaultValue,
                                                "IsClientDeliveryConstructValue": false,
                                                "RowStatusUId": UUID("00100000-0000-0000-0000-000000000000"),
                                                "CorrelationUId": ProductVersionEntityPropertyValue.CorrelationUId,
                                                "RowVersion": null,
                                            });

                                        }

                                    });
                                }

                                productInstanceEntityProperties.push({
                                    "CreatedByUser": "systemadmin@mwphoenix.onmicrosoft.com",
                                    "CreatedByApp": "myWizard-Phoenix",
                                    "CreatedOn": {
                                        "DateTime": ISODate("2020-03-23T13:51:51.818+05:30"),
                                        "Ticks": NumberLong("637205485118180000")
                                    },
                                    "ModifiedByUser": "systemadminui@mwphoenix.onmicrosoft.com",
                                    "ModifiedByApp": "myWizard-Phoenix",
                                    "ModifiedOn": {
                                        "DateTime": ISODate("2020-03-24T17:22:12.337+05:30"),
                                        "Ticks": NumberLong("637206475323370000")
                                    },
                                    "ProductInstanceEntityPropertyUId": ProductVersionEntityProperty.ProductVersionEntityPropertyUId,
                                    "ProductInstanceEntityPropertyId": ProductVersionEntityProperty.ProductVersionEntityPropertyId,
                                    "ProductInstanceEntityUId": ProductVersionEntitie.ProductVersionEntityUId,
                                    "ProductInstanceUId": productinstance.ProductInstanceUId,
                                    "EntityPropertyUId": ProductVersionEntityProperty.EntityPropertyUId,
                                    "PropertyDisplayName": ProductVersionEntityProperty.PropertyDisplayName,
                                    "ProductPropertyNodePath": ProductVersionEntityProperty.ProductPropertyNodePath,
                                    "ProductPropertyName": ProductVersionEntityProperty.ProductPropertyName,
                                    "DataTypeUId": ProductVersionEntityProperty.DataTypeUId,
                                    "DataflowDirectionUId": ProductVersionEntityProperty.DataflowDirectionUId,
                                    "AllowDeliveryConstructEntityRule": ProductVersionEntityProperty.AllowDeliveryConstructEntityRule,
                                    "IsValueInAttribute": ProductVersionEntityProperty.IsValueInAttribute,
                                    "DataQuery": "",
                                    "IsVisible": ProductVersionEntityProperty.IsVisible,
                                    "DisplayOrder": ProductVersionEntityProperty.DisplayOrder,
                                    "RowStatusUId": UUID("00100000-0000-0000-0000-000000000000"),
                                    "CorrelationUId": ProductVersionEntityProperty.CorrelationUId,
                                    "RowVersion": null,
                                    "ProductInstanceEntityPropertyValues": productInstanceEntityPropertyValues
                                });
                            })
                            productinstance.ProductInstanceEntities.push({
                                "CreatedByUser": "systemadmin@mwphoenix.onmicrosoft.com",
                                "CreatedByApp": "myWizard-Phoenix",
                                "CreatedOn": {
                                    "DateTime": ISODate("2020-03-23T13:51:51.818+05:30"),
                                    "Ticks": NumberLong("637205485118180000")
                                },
                                "ModifiedByUser": "systemadminui@mwphoenix.onmicrosoft.com",
                                "ModifiedByApp": "myWizard-Phoenix",
                                "ModifiedOn": {
                                    "DateTime": ISODate("2020-03-24T17:22:12.337+05:30"),
                                    "Ticks": NumberLong("637206475323370000")
                                },
                                "ProductInstanceEntityUId": ProductVersionEntitie.ProductVersionEntityUId,
                                "ProductInstanceEntityId": ProductVersionEntitie.ProductVersionEntityId,
                                "ProductInstanceUId": productinstance.ProductInstanceUId,
                                "EntityUId": ProductVersionEntitie.EntityUId,
                                "WorkItemTypeUId": ProductVersionEntitie.WorkItemTypeUId,
                                "DataflowDirectionUId": ProductVersionEntitie.DataflowDirectionUId,
                                "Description": ProductVersionEntitie.Description,
                                "RowStatusUId": UUID("00100000-0000-0000-0000-000000000000"),
                                "CorrelationUId": UUID("f503bedc-db82-4a73-8dd7-71b686e3b3c7"),
                                "RowVersion": null,
                                "ProductInstanceEntityProperties": productInstanceEntityProperties

                            })
                        }

                    })
                }
            }
        })
    })
    print(productinstance.ProductInstanceUId.hex().toString() + " copied from version " + productinstance.ProductVersionUId.hex().toString())

    db.productinstances.save(productinstance)
});
