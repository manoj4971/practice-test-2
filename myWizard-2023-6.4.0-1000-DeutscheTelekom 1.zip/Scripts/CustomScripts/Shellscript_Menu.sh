#!/usr/bin/bash
while :  
do
  clear
      echo "Server name: $(hostname)"
      echo "------------------------"
      echo "  M A I N - M E N U "
      echo "1. Display date and time"
      echo "2. Display users"
      echo "3. Check Port is Listening or not"
	  echo "4. Display All services status"
	  echo "5. Display Nginx status"
	  echo "6. Display Memory Details"
	  echo "7. Display CPU details"
	  echo "8. Disk Space available in server"
	  echo "9. Top Memory utilized process details"
	  echo "10.Top CPU utilized process details"
	  echo "11.Check omid status"
	  echo "12.Check /mnt/myWizard-Phoenix status"
	  echo "13. exit"


      read -p "Enter your choice [ 1-13 ]" choice

      case $choice in
        1) echo "Today is $(date)"
            read -p "Press [Enter] key to continue..." key
            ;;
        2)
            w
            read -p "Press [Enter] key to continue..." key
            ;;
        3)
            echo " enter the port: "
			read port
			if netstat -tulnp | grep -i LISTEN  >/dev/null ; then
			  echo "running"
			else
			  echo "not running"
			 fi
            read -p "Press [Enter] key to continue..." key
            ;;
		4)
            systemctl list-units --type=service --all
            read -p "Press [Enter] key to continue..." key
            ;;
		5)
            systemctl status nginx
            read -p "Press [Enter] key to continue..." key
            ;;
		6)
            free -g
            read -p "Press [Enter] key to continue..." key
            ;;
		7)
            lscpu | egrep 'CPU\(s\)'
            read -p "Press [Enter] key to continue..." key
            ;;
		8)
            df -h
            read -p "Press [Enter] key to continue..." key
            ;;
		9)
            ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem | head
            read -p "Press [Enter] key to continue..." key
            ;;
		10)
            ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head
            read -p "Press [Enter] key to continue..." key
            ;;
        11)
            systemctl status omid
            read -p "Press [Enter] key to continue..." key
            ;;
        12)
            df -h /mnt/myWizard-Phoenix
            read -p "Press [Enter] key to continue..." key
            ;;			
        13)
            echo "Bye!"
            exit
            ;;
        *)
            echo "Error: Invalid option ..."
            read -p "Press [Enter] key to continue..." key
            ;;
      esac
done








