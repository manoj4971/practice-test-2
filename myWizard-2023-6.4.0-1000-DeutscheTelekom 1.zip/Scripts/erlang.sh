#!/bin/bash
#######Install erlang
echo"*********Installing erlang*********"
pwsh /mnt/win/OneClickTools/wget-files.ps1 -url "https://packages.erlang-solutions.com/erlang/rpm/centos/7/x86_64/esl-erlang_23.2.3-1~centos~7_amd64.rpm"
sudo yum -y install libwx*
sudo yum -y install unixODBC-devel
sudo rpm -Uvh esl-erlang_23.2.3-1~centos~7_amd64.rpm
erl -version

