#!/bin/bash

######Install epel
cd /offline/web
yum -y localinstall --nogpgcheck epel-release-7-13.noarch