#!/usr/bin/bash
#set -x
###################################################################
#Script Name	: backup_cleanup.sh                                                                                             
#Description	:                                                                                 
#Args           :                                                                                           
#Author       	: Rajendra Prasad                                             
#Email         	: rajendra.p.mandla@accenture.com                                         
###################################################################

DATE=$(date +%d_%m_%Y_%H_%M_%S)

SCRIPT_LOGS=${0}_$DATE.log
DIR_MYWIZARD1=/mnt/myWizard-Phoenix/DeliveryPlanOutbound
DIR_MYWIZARD2=/mnt/myWizard-Phoenix/GatewayManager/ProcessPipelines/
DIR_MYWIZARD3=/mnt/myWizard-Phoenix/DeliveryPlanInbound/New  
LOG_FILE=/var/www/Logs
DIR_WWW=/var/www/GatewayManager/ProcessPipelines
DIR_ARCHIVE=/var/ArchiveLogs

if [[ ! -d ${DIR_ARCHIVE} ]]
then
mkdir -p ${DIR_ARCHIVE}
fi

MYWIZARD_1() {
if [[ -d ${DIR_MYWIZARD1} ]]
then
 echo "Going inside ${DIR_MYWIZARD1} and finding the logs to copy"
 #find ${DIR_MYWIZARD1} -mtime +2 -type f -exec ls -l {} \;
 #list out the file and Dir
 #find ${DIR_MYWIZARD1} -mtime +2 -exec ls -l {} \;
 echo "Completed listing of logs in ${DIR_MYWIZARD1}"
 echo "Proceeding with copy"
 find ${DIR_MYWIZARD1} -type f -mtime +2 -exec cp -vr --parents \{\}  ${DIR_ARCHIVE} \;
 echo "Copying completed"
 echo "Proceeding with delete"
 find ${DIR_MYWIZARD1} -type f -mtime +2 -delete
 #find ${DIR_MYWIZARD1} -type d -mtime +2 -exec rm -rf {} \;
 #find ${DIR_MYWIZARD1} -mtime +2 -exec rm -rf {} \;
 echo "Deletion completed" 
 fi
 } 


MYWIZARD_2 () {
if [[ -d ${DIR_MYWIZARD2} ]]
then
 echo "Going inside ${DIR_MYWIZARD2} and finding the logs to copy"
 #find ${DIR_MYWIZARD2} -type d -name Instances -mtime +2 -type f -exec ls -l {} \;
 echo "Completed listing of logs in ${DIR_MYWIZARD2}"
 echo "Proceeding with copy"
 find ${DIR_MYWIZARD2} -type d -name Instances -mtime +2 -exec cp -vr --parents \{\}  ${DIR_ARCHIVE} \;
 echo "Copying completed"
 echo "Proceeding with delete"
 #find ${DIR_MYWIZARD2} -type d -name Instances -mtime +2 -exec rm -rf {} \;
 find ${DIR_MYWIZARD2}/*/Instances  -mtime +2 -type f -delete
 find ${DIR_MYWIZARD2}/*/Instances/Messages/Failed -type d -mtime +2 -exec rm -rf {} \;
 find ${DIR_MYWIZARD2}/*/Instances/Messages/Processed -type d -mtime +2 -exec rm -rf {} \;
 find ${DIR_MYWIZARD2}/*/Instances/Messages/Processing -type d -mtime +2 -exec rm -rf {} \;
 echo "Deletion completed" 
 fi
 } 

MYWIZARD_3 () {
if [[ -d ${DIR_MYWIZARD3} ]]
then
 echo "Going inside ${DIR_MYWIZARD3} and finding the logs to copy"
 #find ${DIR_MYWIZARD3} -mtime +2 -type f -exec ls -l {} \;
 #list out the file and Dir
 #find ${DIR_MYWIZARD3} -mtime +2 -exec ls -l {} \;
 echo "Completed listing of logs in ${DIR_MYWIZARD3}"
 echo "Proceeding with copy"
 find ${DIR_MYWIZARD3} -type f -mtime +2 -exec cp -vr --parents \{\}  ${DIR_ARCHIVE} \;
 echo "Copying completed"
 echo "Proceeding with delete"
 find ${DIR_MYWIZARD3} -type f -mtime +2 -delete
 #find ${DIR_MYWIZARD3} -type d -mtime +2 -exec rm -rf {} \;
 #find ${DIR_MYWIZARD3} -mtime +2 -exec rm -rf {} \;
 echo "Deletion completed" 
 fi
 } 
 
LOG_FILES () {
if [[ -d ${LOG_FILE} ]] 
then
 echo "Going inside ${LOG_FILE} and finding the logs to copy"
 #find ${LOG_FILE} -mtime +2 -type f -exec ls -l {} \;
 echo "Completed listing of logs in ${LOG_FILE}"
 echo "Proceeding with copy"
 find ${LOG_FILE} -type f -mtime +2 -exec cp -vr --parents \{\}  ${DIR_ARCHIVE} \;
 echo "Copying completed"
 echo "Proceeding with delete"
 find ${LOG_FILE}  -mtime +2 -type f -delete
 find /var/www/Logs/myWizard.WebAPI/*  -type d -mtime +2 -exec rm -rf {} \;
 echo "Deletion completed" 
 fi
 } 


WWW_FUN (){
if [[ -d ${DIR_WWW} ]] 
then
 echo "Going inside ${DIR_WWW} and finding the logs to copy"
 #find ${DIR_WWW} -mtime +2 -type f -exec ls -l {} \;
 echo "Completed listing of logs in ${DIR_WWW}"
 echo "Proceeding with copy"
 find ${DIR_WWW} -type d -name Instances -mtime +2 -exec cp -vr --parents \{\}  ${DIR_ARCHIVE} \;
 echo "Copying completed"
 echo "Proceeding with delete"
 find ${DIR_WWW}/*/Instances  -mtime +2 -type f -delete
 find ${DIR_WWW}/*/Instances/Messages/Failed -type d -mtime +2 -exec rm -rf {} \;
 find ${DIR_WWW}/*/Instances/Messages/Processed -type d -mtime +2 -exec rm -rf {} \;
 find ${DIR_WWW}/*/Instances/Messages/Processing -type d -mtime +2 -exec rm -rf {} \;
 echo "Deletion completed" 
 fi
 } 


ARCHIVE_DEL_LOGS(){
if [[ -d ${DIR_ARCHIVE} ]] 
then
 echo "Going inside ${LOG_FILE} and finding the logs to delete"
#find ${DIR_ARCHIVE} -mtime +7 -type f -exec ls -l {} \;
echo "Completed listing of logs in ${LOG_FILE}"
echo "Proceeding with delete"
find ${DIR_ARCHIVE} -mtime +7 -type f -delete
find /var/ArchiveLogs/mnt/myWizard-Phoenix/GatewayManager/ProcessPipelines/*/Instances/Messages/Failed -type d -mtime +7 -exec rm -rf {} \;
find /var/ArchiveLogs/mnt/myWizard-Phoenix/GatewayManager/ProcessPipelines/*/Instances/Messages/Processed -type d -mtime +7 -exec rm -rf {} \;
find /var/ArchiveLogs/mnt/myWizard-Phoenix/GatewayManager/ProcessPipelines/*/Instances/Messages/Processing -type d -mtime +7 -exec rm -rf {} \;
find /var/ArchiveLogs/mnt/myWizard-Phoenix/GatewayManager/ProcessPipelines/*/Instances/Notifications/Processed -type d -mtime +7 -exec rm -rf {} \;
find /var/ArchiveLogs/mnt/myWizard-Phoenix/GatewayManager/ProcessPipelines/*/Instances/Notifications/failed -type d -mtime +7 -exec rm -rf {} \;
find /var/ArchiveLogs/var/www/GatewayManager/ProcessPipelines/*/Instances/Messages/Failed -type d -mtime +7 -exec rm -rf {} \;
find /var/ArchiveLogs/var/www/GatewayManager/ProcessPipelines/*/Instances/Messages/Processed -type d -mtime +7 -exec rm -rf {} \;
find /var/ArchiveLogs/var/www/GatewayManager/ProcessPipelines/*/Instances/Messages/Processing -type d -mtime +7 -exec rm -rf {} \;
echo "Deletion completed"
fi
 } 

###########Main Function Execute################
MYWIZARD_1 >>${SCRIPT_LOGS}
MYWIZARD_2 >>${SCRIPT_LOGS}
MYWIZARD_3 >>${SCRIPT_LOGS}
LOG_FILES >>${SCRIPT_LOGS}
WWW_FUN >>${SCRIPT_LOGS}
ARCHIVE_DEL_LOGS >>${SCRIPT_LOGS}
