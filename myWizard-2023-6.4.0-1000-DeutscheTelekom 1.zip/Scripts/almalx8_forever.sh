#!/bin/bash

#########Install forever

#Run this command in the root folder path (with command sudo su) before running schedule service
sudo npm install forever -g 

#Npm command to install forever Package