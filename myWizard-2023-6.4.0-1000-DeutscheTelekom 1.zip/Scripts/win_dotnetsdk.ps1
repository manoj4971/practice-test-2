﻿param(
    $ipAddress = "" ,
    $AdminUser = "",
    $AdminPassword = ""
)

begin{
    Clear-Host 
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $exe = "dotnet-sdk-3.1.416-win-x64.exe"
    $path = $(Split-Path $PSCommandPath -Parent) + "\Softwares"
    New-Item -Path "$path" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
    $targetPath = "C:\Accenture\Softwares"
    $args = "/quiet"
    winrm set winrm/config/client '@{TrustedHosts="' $ipAddress '"}' | Out-Null
    [securestring]$password = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
    $credentials = New-Object System.Management.Automation.PSCredential ($AdminUser, $password)
    $session = New-PSSession –ComputerName $ipAddress -Credential $credentials
    Write-Host "Installing $exe"
}

process{
       
    Invoke-Command -Session $session -ScriptBlock {
        New-Item $using:targetPath -Type Directory -Force -ErrorAction SilentlyContinue | Out-Null
        New-SmbShare -Name "Softwares" -Path $using:targetPath -FullAccess "Everyone" -ErrorAction SilentlyContinue -Verbose | Out-Null
        Set-SmbPathAcl -ShareName "Softwares" -ErrorAction SilentlyContinue -Verbose
    }

    if(-not (Test-Path "$path\$exe")){
        Invoke-WebRequest -Uri "https://mywizard-packagemanager.accenture.com/ocicdn/softwares/$exe" -OutFile "$path\$exe" 
    }
    Copy-Item -Path "$path\$exe" -Destination "\\$ipaddress\Softwares\$exe"  -Force
    

    Invoke-Command -Session $session -ScriptBlock {
        Start-Process "$using:targetPath\$using:exe" -ArgumentList $using:args -Wait -NoNewWindow -Verbose
        Remove-Item -Path $using:targetPath -Recurse -Force -ErrorAction SilentlyContinue |Out-Null
        Remove-SmbShare -Name "Softwares" -Force
    }
}
end{
    Write-Host "Installation completed"
}
