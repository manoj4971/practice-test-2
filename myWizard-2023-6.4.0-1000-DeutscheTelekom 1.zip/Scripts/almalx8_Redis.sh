###Installing Redis ####
echo "Redis Installation"
cd /tmp
dnf install https://dl.fedoraproject.org/pub/epel/epel-release-latest-8.noarch.rpm -y
dnf install https://dl.fedoraproject.org/pub/epel/epel-next-release-latest-8.noarch.rpm -y
dnf install redis -y
Run below commands:
IP=$(hostname -I|cut -d" " -f 1)
sed -i 's|# maxmemory <bytes>|maxmemory 10g|g'  /etc/redis.conf
sed -i 's|# maxmemory-policy noeviction|maxmemory-policy allkeys-lfu|g' /etc/redis.conf
sed -i 's|# maxmemory-samples 5|maxmemory-samples 5|g' /etc/redis.conf
sed -i 's|lazyfree-lazy-eviction no|lazyfree-lazy-eviction yes|g' /etc/redis.conf
sed -i 's|lazyfree-lazy-expire no|lazyfree-lazy-expire yes|g' /etc/redis.conf
sed -i 's|lazyfree-lazy-server-del no|lazyfree-lazy-server-del yes|g' /etc/redis.conf
sed -i 's|replica-lazy-flush no|replica-lazy-flush yes|g' /etc/redis.conf
sed -i 's|# lazyfree-lazy-user-del no|lazyfree-lazy-user-del yes|g' /etc/redis.conf
sed -i 's|# lazyfree-lazy-user-flush no|lazyfree-lazy-user-flush yes|g' /etc/redis.conf
sed -i 's|# io-threads 4|io-threads 6|g' /etc/redis.conf
sed -i 's|# io-threads-do-reads noo|io-threads-do-reads yes|g' /etc/redis.conf
sed -i "s|bind 127.0.0.1 ::1|bind 127.0.0.1 $IP ::1|g" /etc/redis.conf
sed -i "s|bind 127.0.0.1 -::1|bind 0.0.0.0|g" /etc/redis.conf
sed -i "s|bind 127.0.0.1|bind 0.0.0.0|g" /etc/redis.conf
sed -i 's|# requirepass foobared|requirepass password|g' /etc/redis.conf
systemctl restart redis
systemctl status redis