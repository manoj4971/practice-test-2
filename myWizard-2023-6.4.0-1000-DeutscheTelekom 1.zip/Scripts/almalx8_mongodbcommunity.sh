#!/bin/sh

if ! pgrep -x mongod
then
echo "Mongodb Insatllation"
echo "Mongodb Repo"
rm /etc/yum.repos.d/mongodb-org-6.0.repo
cat >> /etc/yum.repos.d/mongodb-org-6.0.repo << EOL
[mongodb-org-6.0]
name=MongoDB Repository
baseurl=https://repo.mongodb.org/yum/redhat/\$releasever/mongodb-org/6.0/x86_64/
#baseurl=https://repo.mongodb.com/yum/redhat/\$releasever/mongodb-enterprise/6.0/$basearch/
gpgcheck=1
enabled=1
gpgkey=https://www.mongodb.org/static/pgp/server-6.0.asc

EOL

echo "Installing Mongodb Community"
yum install -y mongodb-org
#echo "Installing Mongodb Enterprise"
#yum install -y mongodb-enterprise
echo "checking mongo version"
mongod --version

sleep 2

echo "Creating Directories"
mkdir -p /mongo/data /mongo/log /mongo/certificates

chown -R mongod:mongod /mongo
chown -R mongod:mongod /mongo/data
chown -R mongod:mongod /mongo/log
chown -R mongod:mongod /mongo/certificates

echo "SELINUX Configuration"
semanage fcontext -a -t mongod_var_lib_t '/mongo/data.*'
chcon -Rv -u system_u -t mongod_var_lib_t '/mongo/data'
restorecon -R -v '/mongo/data'

semanage fcontext -a -t mongod_log_t '/mongo/log.*'
chcon -Rv -u system_u -t mongod_log_t '/mongo/log'
restorecon -R -v '/mongo/log'

semanage fcontext -a -t mongod_var_lib_t '/mongo/certificates.*'
chcon -Rv -u system_u -t mongod_var_lib_t '/mongo/certificates'
restorecon -R -v '/mongo/certificates'

#IP=$(/sbin/ip -o -4 addr list eth0 | awk '{print $4}' | cut -d/ -f1)
IP=$(hostname -I|cut -d" " -f 1)
fqn=$(nslookup $(hostname -i)) ; fqn=${fqn##*name = } ; fqn=${fqn%.*}

rm /etc/mongod.conf
cat >> /etc/mongod.conf << EOL
systemLog:
  destination: file
  logAppend: false
  path: /mongo/log/mongod.log

storage:
  dbPath: /mongo/data
  journal:
    enabled: true

processManagement:
  fork: true
  pidFilePath: /var/run/mongodb/mongod.pid
  timeZoneInfo: /usr/share/zoneinfo

net:
  port: 27017
  bindIp: 127.0.0.1
  wireObjectCheck: true
 #tls:
   # mode: requireTLS
   # certificateKeyFile: /mongo/certificates/server.pem
   # CAFile: /mongo/certificates/CA.crt
   # disabledProtocols: TLS1_0,TLS1_1

security:
# authorization: enabled
  javascriptEnabled: false
# keyFile: /mongo/certificates/keyfile.key

setParameter:
  enableLocalhostAuthBypass: false

EOL

sed -i 's/127.0.0.1/'"$IP"'/g' /etc/mongod.conf

rm -r /mongo/certificates/server_ext.ext
touch /mongo/certificates/server_ext.ext
cat >> /mongo/certificates/server_ext.ext << EOL
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
subjectAltName = @dns_names 

[dns_names]
IP = 0.0.0.0
DNS.0 = *.*
DNS.1 = *.ec2.internal
DNS.2 = $HOSTNAME
DNS.3 = localhost

EOL

echo "Start of MongoDB"
systemctl start mongod

echo "Status of MongoDB"
systemctl status mongod
return

sleep 2

mongosh "$HOSTNAME":27017/admin --eval "db.createUser({user: \"admin\",pwd: \"Alma@2023\",roles:[{ role: \"dbOwner\", db: \"admin\" },{ role:\"readWrite\", db:\"admin\" },{role: \"root\", db:\"admin\" },{role: \"__system\", db:\"admin\"}]})"

sleep 2

systemctl stop mongod

openssl rand -base64 741 > /mongo/certificates/keyfile.key

chown mongod:mongod /mongo/certificates/keyfile.key
chmod 400 /mongo/certificates/keyfile.key

openssl genrsa -out /mongo/certificates/CA.key 4096

openssl req -new -x509 -days 1825 -key /mongo/certificates/CA.key -out /mongo/certificates/CA.crt -subj "/C=IN/ST=DELHI/L=NEWDELHI/O=ACCENTURE /OU=myWizardRoot/CN=ADMIN"

openssl genrsa -out /mongo/certificates/server.key 4096

openssl req -new -key /mongo/certificates/server.key -out /mongo/certificates/server.csr -subj "/C=IN/ST=DELHI/L=NEWDELHI/O=ACCENTURE/OU=myWizardServer/CN=$HOSTNAME"

openssl x509 -req -days 1825 -in /mongo/certificates/server.csr -CA /mongo/certificates/CA.crt -CAkey /mongo/certificates/CA.key -set_serial 01 -out /mongo/certificates/server.crt -extfile /mongo/certificates/server_ext.ext

cat /mongo/certificates/server.crt /mongo/certificates/server.key > /mongo/certificates/server.pem

echo "Generating client certificates"

openssl genrsa -out /mongo/certificates/client.key 4096
openssl req -new -key /mongo/certificates/client.key -out /mongo/certificates/client.csr -subj "/C=IN/ST=DELHI/L=NEWDELHI/O=ACCENTURE/OU=myWizardClient/CN=*.ec2.internal"
openssl x509 -req -days 1825 -in /mongo/certificates/client.csr -CA /mongo/certificates/CA.crt -CAkey /mongo/certificates/CA.key -set_serial 01 -out /mongo/certificates/client.crt -extfile /mongo/certificates/server_ext.ext
cat /mongo/certificates/client.crt /mongo/certificates/client.key > /mongo/certificates/client.pem
echo "******************************CREATING CLIENT.PFX: USE THE PASSWORD THAT YOU WILL BE USING IN DATASHEET**************************"
openssl pkcs12 -in /mongo/certificates/client.pem -inkey /mongo/certificates/client.key -export -out /mongo/certificates/client.pfx -passout pass:Alma@2023
echo "******************************CLIENT.PFX GENERATED**************************"
echo "******************************CREATING CLIENTJAVA.PFX: USE THE PASSWORD chageit **************************"
openssl pkcs12 -in /mongo/certificates/client.pem -inkey /mongo/certificates/client.key -export -out /mongo/certificates/clientjava.pfx -passout pass:changeit
echo "******************************CLIENTjava.PFX GENERATED**************************"


sed -i 's/#/ /g' /etc/mongod.conf

systemctl start mongod
fi

yes | cp /mongo/certificates/CA.crt /etc/pki/ca-trust/source/anchors/
update-ca-trust extract