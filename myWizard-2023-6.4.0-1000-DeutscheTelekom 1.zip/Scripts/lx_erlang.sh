#!/bin/bash
#######Install erlang
echo"*********Installing erlang*********"
sudo yum -y install libwx*
sudo yum -y install unixODBC-devel
yum install erlang -y
#sudo rpm -Uvh esl-erlang*.rpm
erl -version

