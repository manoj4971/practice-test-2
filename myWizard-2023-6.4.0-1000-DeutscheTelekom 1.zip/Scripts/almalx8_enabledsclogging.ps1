$nxPath = Split-Path $PSCommandPath -Parent


New-Item -ItemType Directory -Force -Path "$nxPath/backup/30"
Copy-Item "/opt/microsoft/dsc/Scripts/3.x/Scripts/nxScript.py" -Destination "$nxPath/backup/30/" -Force

New-Item -ItemType Directory -Force -Path "$nxPath/backup/26_27"
Copy-Item "/opt/microsoft/dsc/Scripts/2.6x-2.7x/Scripts/nxScript.py" -Destination "$nxPath/backup/26_27/" -Force

New-Item -ItemType Directory -Force -Path "$nxPath/backup/24_25"
Copy-Item "/opt/microsoft/dsc/Scripts/2.4x-2.5x/Scripts/nxScript.py" -Destination "$nxPath/backup/24_25/" -Force



Copy-Item "$nxPath/30/nxScript.py" -Destination /opt/microsoft/dsc/Scripts/3.x/Scripts/ -Force
Copy-Item "$nxPath/30/nxScript.py" -Destination /opt/omi/lib/Scripts/3.x/Scripts/ -Force
Copy-Item "$nxPath/30/nxScript.py" -Destination /opt/microsoft/dsc/modules/nx/DSCResources/MSFT_nxScriptResource/x64/Scripts/3.x/Scripts/ -Force

Copy-Item "$nxPath/26_27/nxScript.py" -Destination /opt/microsoft/dsc/Scripts/2.6x-2.7x/Scripts/ -Force
Copy-Item "$nxPath/26_27/nxScript.py" -Destination /opt/omi/lib/Scripts/2.6x-2.7x/Scripts/ -Force
Copy-Item "$nxPath/26_27/nxScript.py" -Destination /opt/microsoft/dsc/modules/nx/DSCResources/MSFT_nxScriptResource/x64/Scripts/2.6x-2.7x/Scripts/ -Force

Copy-Item "$nxPath/24_25/nxScript.py" -Destination /opt/microsoft/dsc/Scripts/2.4x-2.5x/Scripts/ -Force
Copy-Item "$nxPath/24_25/nxScript.py" -Destination /opt/omi/lib/Scripts/2.4x-2.5x/Scripts/ -Force
Copy-Item "$nxPath/24_25/nxScript.py" -Destination /opt/microsoft/dsc/modules/nx/DSCResources/MSFT_nxScriptResource/x64/Scripts/2.4x-2.5x/Scripts/ -Force