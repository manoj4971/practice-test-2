#!/bin/bash


#######Install JRE11.0.5
echo "*********Installing JRE11*********"
cd /mnt/win/OneClickTools/Softwares/rpms
rpm -ivh java-11-openjdk-headless-11.0.10.0.9-0.el7_9.x86_64.rpm
rpm -ivh java-11-openjdk-11.0.10.0.9-0.el7_9.x86_64.rpm
sudo yum -y install java-11-openjdk-devel
java --version