﻿param (
    $url = ""
)
$thisPath = $(Split-Path -Path $PSCommandPath -Parent)
$fileName = $(Split-Path -Path $url -Leaf)
(New-Object System.Net.WebClient).DownloadFile($url,$($thisPath + "/" + $fileName))