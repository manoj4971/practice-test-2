#!/bin/bash
IP=$(hostname -I|cut -d" " -f 1)


pwsh ./Values-FromGMConfigs.ps1 -nodeName $IP