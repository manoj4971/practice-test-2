#!/bin/bash

echo "*********Installing dotnet core runtime 3.1*********"
cd /tmp
sudo rpm -Uvh https://packages.microsoft.com/config/centos/7/packages-microsoft-prod.rpm
yum makecache
sudo yum install dotnet-sdk-6.0 -y