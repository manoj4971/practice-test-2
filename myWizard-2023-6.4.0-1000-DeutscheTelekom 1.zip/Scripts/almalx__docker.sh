﻿#!/bin/bash

echo "*********Installing docker*********"
cd /tmp
sudo rpm -Uvh https://packages.microsoft.com/config/centos/7/packages-microsoft-prod.rpm
sudo yum install -y docker --exclude=moby-\*