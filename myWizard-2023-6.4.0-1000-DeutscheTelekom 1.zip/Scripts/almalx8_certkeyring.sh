#!/bin/sh

cd keyring-cert
yes | cp CA.crt client.pfx client.pem clientjava.pfx /var/www/appConfigFiles/certificates
yes | cp *.xml /var/www/appConfigFiles/keyring
yes | cp /var/www/appConfigFiles/certificates/CA.crt /etc/pki/ca-trust/source/anchors/
update-ca-trust extract

echo ""
echo "contents of appConfigFiles/certificates"
ls /var/www/appConfigFiles/certificates

echo ""
echo "contents of appConfigFiles/keyring"
ls /var/www/appConfigFiles/keyring

echo ""
echo "contents of ca-trust/source/anchors"
ls /etc/pki/ca-trust/source/anchors