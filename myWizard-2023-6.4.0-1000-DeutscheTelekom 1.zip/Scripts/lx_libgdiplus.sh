#!/bin/bash

######Install libgdiplus
cd /mnt/win/OneClickTools/Softwares/rpms
yum localinstall --nogpgcheck libgdiplus-2.10-10.el7.x86_64.rpm -y
