﻿#!/bin/bash
IP=$(hostname -I|cut -d" " -f 1)


pwsh ./Incremental-LogPresenter.ps1 -nodeName $IP