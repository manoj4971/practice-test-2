﻿<#
.SYNOPSIS
 Collection of helper functions for OneClick Deployment

.DESCRIPTION
 Collection of helper functions for OneClick Deployment
#>

function ParseDscJson_v1_1 {
    [CmdletBinding(SupportsShouldProcess = $true)]
    param(
        [Parameter(Mandatory = $true)]
        [psobject] $jsonParams
    )

    begin {
        $configData = $null
    }

    process {
        $htParams = $jsonParams | ConvertPSObjectToHashtable

        $EnvironmentSettings = $htParams.Environment
        $Resources = $htParams.Resources
        $Servers = $htParams.Servers | Where-Object -Property IsRequired -EQ $true
        $ServerTemplates = $htParams.ServerTemplates 

        $DockerSettings = $htParams.DockerSettings

        # initial configData
        $configData = @{
            AllNodes = [System.Collections.ArrayList]@()
        }
        
        # environment settings
        $configData.DscEnvironmentSettings = $EnvironmentSettings


        # update paths
        $CustomerName = $htParams.Client.Name
        $Version = $htParams.Version.Name
        $Environment = $EnvironmentSettings.Name
        $SMBSharePath = $EnvironmentSettings.SMBSharePath
        $LocalPath = (Resolve-Path .\).Path
        $SoftwaresFolder = $EnvironmentSettings.SoftwareFolder
        $ApplicationsFolder = $EnvironmentSettings.ApplicationsFolder
		$LinuxMountPath = $EnvironmentSettings.LinuxMountPath
		$LinuxInstallerFolder = $EnvironmentSettings.LinuxTargetFolder
        $ClientUId = $htParams.Client.ClientUId
        $ClientCode = $htParams.Client.Code
        $DBPwd = $EnvironmentSettings.DBAdminPassword
		
        #$DockerPackagesPath = $EnvironmentSettings.DockerPackagesPath

        #$EnvironmentBasePath = $LocalPath

        $setUpFolderNamSplits = $LocalPath -split "\\"
        $setUpFolderName = $setUpFolderNamSplits[$setUpFolderNamSplits.Length - 1]

        $configData.DscEnvironmentSettings.LocalRootPath = "$LocalPath"
        $configData.DscEnvironmentSettings.EnvironmentBasePath = $LocalPath
        $configData.DscEnvironmentSettings.SourceAppServicesPath = "$SMBSharePath\myWizard\$setUpFolderName\$ApplicationsFolder"
        $configData.DscEnvironmentSettings.SourceAppServicesPathLinux = "$LinuxMountPath/$ApplicationsFolder"
        $configData.DscEnvironmentSettings.LocalAppServicesPath = "$LocalPath\$ApplicationsFolder"
        $configData.DscEnvironmentSettings.SourcePackagesPath = "$SMBSharePath\myWizard\$setUpFolderName\Packages"
        $configData.DscEnvironmentSettings.LocalPackagesPath = "$LocalPath\Packages"
        $configData.DscEnvironmentSettings.MofOutputPath = "$LocalPath\MOF"
        $configData.DscEnvironmentSettings.SourceInstallerPath = "$SMBSharePath\myWizard\$setUpFolderName\$SoftwaresFolder"
		$configData.DscEnvironmentSettings.SourceInstallerPathLinux = "$LinuxMountPath/$SoftwaresFolder"
        $configData.DscEnvironmentSettings.LocalInstallerPath = "$LocalPath\$SoftwaresFolder"
        $configData.DscEnvironmentSettings.ModulesSourcePath = "$SMBSharePath\myWizard\$setUpFolderName\Scripts\Modules" #PS Module File Path Changes
        $configData.DscEnvironmentSettings.ModulesLocalPath = "$LocalPath\Scripts\Modules" #PS Module File Path Changes
        $configData.DscEnvironmentSettings.PreReqMofOutputPath = "$LocalPath\MOF\PreRequisites"
        $configData.DscEnvironmentSettings.Client = $CustomerName
        $configData.DscEnvironmentSettings.Version = $Version
        $configData.DscEnvironmentSettings.LocalPath = $LocalPath
        $configData.DscEnvironmentSettings.SourceCustomizationsPath = "$SMBSharePath\myWizard\$($LocalPath.Split('\')[3])"
        $configData.DscEnvironmentSettings.DBPwd = $DBPwd

        Write-Host "Processing Docker Settings..."
        
        $DockerConfigurations = @{}
        $DockerConfigurations.DockerFileSettings = $null
        $DockerConfigurations.ContainerRegistry = $null
        $DockerConfigurations.DefaultContainer = $null

            
        $DockerFileSettings = @{}
        $DockerFileSettings.BaseImage = $DockerSettings.DockerFileSettings.BaseImage
        $DockerFileSettings.ImageName = $DockerSettings.DockerFileSettings.ImageName
        $DockerFileSettings.Version = $DockerSettings.DockerFileSettings.Version
        $DockerFileSettings.ImageParentDirectory = $DockerSettings.DockerFileSettings.ImageParentDirectory


        $ContainerRegistry = @{}
        $ContainerRegistry.RegistryLoginServer = $DockerSettings.ContainerRegistry.RegistryLoginServer
        $ContainerRegistry.RegistryUserName = $DockerSettings.ContainerRegistry.RegistryUserName
        $ContainerRegistry.RegistryPassword = $DockerSettings.ContainerRegistry.RegistryPassword
        
        $DefaultContainer = @{}
        $DefaultContainer.ContainerName = $DockerSettings.DefaultContainer.ContainerName
        $DefaultContainer.Hostname = $DockerSettings.DefaultContainer.Hostname
        $DefaultContainer.SubnetRange = $DockerSettings.DefaultContainer.SubnetRange
        $DefaultContainer.ContainerIp = $DockerSettings.DefaultContainer.ContainerIp

        $DockerConfigurations.DockerFileSettings = $DockerFileSettings
        $DockerConfigurations.ContainerRegistry = $ContainerRegistry
        $DockerConfigurations.DefaultContainer = $DefaultContainer

        $configData.DockerSettings = $DockerConfigurations


        # builds the wildcard configuration that applies to all nodes
        $wildCardNode = @{
            NodeName                    = '*'
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser        = $true
        }

        $AllNodes = [System.Collections.ArrayList]@()
        [void]$AllNodes.Add($wildCardNode)

        Write-Host "Processing ServerTemplates..."
        foreach ($template in $ServerTemplates) {
            $templateResources = @{}

            $templateResources.Certificates = $null
            $templateResources.HostFileSettings = $null
            $templateResources.WebSites = $null
            $templateResources.PythonApps = $null
            $templateResources.Packages = $null
            $templateResources.WindowsServices = $null
            $templateResources.AppServiceTasks = $null
            $templateResources.ScheduledTasks = $null
            $templateResources.MongoDbServers = $null
            $templateResources.MongoDbInstances = $null
            $templateResources.InstallerPackages = $null
            $templateResources.CustomScripts = $null
            $templateResources.Hadoops = $null
           

            $templateResources.LinuxDirectories = $null
            $templateResources.LinuxFolders = $null
            $templateResources.LinuxJava = $null
            $templateResources.LinuxAmbariServer = $null
            $templateResources.LinuxAmbariAgent = $null
            $templateResources.LinuxHadoop = $null
            $templateResources.LinuxElasticSearch = $null
            $templateResources.LinuxMonit = $null
            $templateResources.LinuxConfigureHDFS = $null
            $templateResources.LinuxConfigureHive = $null
            $templateResources.Python = $null
            $templateResources.Apache = $null
            $templateResources.Tomcat = $null
            $templateResources.RabbitMQ = $null
            $templateResources.MongoDbRestore = $null

            $templateId = $template.ServerTemplateUId
            $templateName = $template.Name



            Write-Host "`nTemplateName: $templateName"

            # Linux HDFS
            Write-Host "Processing HDFS Configuration for Linux ..."
            if ($template.Contains("LinuxConfigureHDFS")) {
                $LinuxConfigureHDFS = [System.Collections.ArrayList]@()
                foreach ($hdfcConfigure in $template.LinuxConfigureHDFS) {
                    $linuxHDFSResourceItem = $Resources.LinuxConfigureHDFS | Where-Object { $_.LinuxConfigureHDFSId -eq $hdfcConfigure.LinuxConfigureHDFS } 

                    if ($linuxHDFSResourceItem -eq $null) {
                        Write-Warning "LinuxConfigureHDFSUId: $($hdfcConfigure.LinuxConfigureHDFS) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---linuxHDFSResourceItem: $linuxHDFSResourceItem"
                        [void]$LinuxConfigureHDFS.Add($linuxHDFSResourceItem)
                    }
                }
                $templateResources.LinuxConfigureHDFS = $LinuxConfigureHDFS
            }

            # Linux Hive
            Write-Host "Processing Hive Configuration for Linux ..."
            if ($template.Contains("LinuxConfigureHive")) {
                $LinuxConfigureHive = [System.Collections.ArrayList]@()
                foreach ($hdfcConfigure in $template.LinuxConfigureHive) {
                    $linuxHiveResourceItem = $Resources.LinuxConfigureHive | Where-Object { $_.LinuxConfigureHiveId -eq $hdfcConfigure.LinuxConfigureHive } 

                    if ($linuxHiveResourceItem -eq $null) {
                        Write-Warning "LinuxConfigureHiveUId: $($hdfcConfigure.LinuxConfigureHive) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---linuxHiveResourceItem: $linuxHiveResourceItem"
                        [void]$LinuxConfigureHive.Add($linuxHiveResourceItem)
                    }
                }
                $templateResources.LinuxConfigureHive = $LinuxConfigureHive
            }

            # Linux Monit
            Write-Host "Processing Monit for Linux ..."
            if ($template.Contains("LinuxMonit")) {
                $LinuxMonit = [System.Collections.ArrayList]@()
                foreach ($monit in $template.LinuxMonit) {
                    $linuxMonitResourceItem = $Resources.LinuxMonit | Where-Object { $_.LinuxMonitUId -eq $monit.LinuxMonitUId } 

                    if ($linuxMonitResourceItem -eq $null) {
                        Write-Warning "LinuxMonitUId: $($monit.LinuxMonitUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---linuxMonitResourceItem: $linuxMonitResourceItem"
                        [void]$LinuxMonit.Add($linuxMonitResourceItem)
                    }
                }
                $templateResources.LinuxMonit = $LinuxMonit
            }

            # Linux ElasticSearch
            Write-Host "Processing ElasticSearch for Linux ..."
            if ($template.Contains("LinuxElasticSearch")) {
                $LinuxElasticSearch = [System.Collections.ArrayList]@()
                foreach ($elasticSearch in $template.LinuxElasticSearch) {
                    $linuxElasticSearchResourceItem = $Resources.LinuxElasticSearch | Where-Object { $_.LinuxElasticSearchUId -eq $elasticSearch.LinuxElasticSearchUId } 

                    if ($linuxElasticSearchResourceItem -eq $null) {
                        Write-Warning "LinuxElasticSearchUId: $($elasticSearch.LinuxElasticSearchUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---linuxElasticSearchResourceItem: $linuxElasticSearchResourceItem"
                        [void]$LinuxElasticSearch.Add($linuxElasticSearchResourceItem)
                    }
                }
                $templateResources.LinuxElasticSearch = $LinuxElasticSearch
            }

            # Linux Hadoop
            Write-Host "Processing Hadoop for Linux ..."
            if ($template.Contains("LinuxHadoop")) {
                $LinuxHadoop = [System.Collections.ArrayList]@()
                foreach ($linHadoop in $template.LinuxHadoop) {
                    $linuxHadoopResourceItem = $Resources.LinuxHadoop | Where-Object { $_.LinuxHadoopUId -eq $linHadoop.LinuxHadoopUId } 

                    if ($linuxHadoopResourceItem -eq $null) {
                        Write-Warning "LinuxHadoopUId: $($linHadoop.LinuxHadoopUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---linuxHadoopResourceItem: $linuxHadoopResourceItem"
                        [void]$LinuxHadoop.Add($linuxHadoopResourceItem)
                    }
                }
                $templateResources.LinuxHadoop = $LinuxHadoop
            }

            # Linux AmbariServer
            Write-Host "Processing AmbariServer for Linux ..."
            if ($template.Contains("LinuxAmbariServer")) {
                $LinuxAmbariServer = [System.Collections.ArrayList]@()
                foreach ($ambariServer in $template.LinuxAmbariServer) {
                    $linuxAmbariServerResourceItem = $Resources.LinuxAmbariServer | Where-Object { $_.LinuxAmbariServerUId -eq $ambariServer.LinuxAmbariServerUId } 

                    if ($linuxAmbariServerResourceItem -eq $null) {
                        Write-Warning "LinuxAmbariServerUId: $($ambariServer.LinuxAmbariServerUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---linuxAmbariServerResourceItem: $linuxAmbariServerResourceItem"

                        [void]$LinuxAmbariServer.Add($linuxAmbariServerResourceItem)
                    }
                }
                $templateResources.LinuxAmbariServer = $LinuxAmbariServer
            }

            # Linux AmbariAgent
            Write-Host "Processing AmbariAgent for Linux ..."
            if ($template.Contains("LinuxAmbariAgent")) {
                $LinuxAmbariAgent = [System.Collections.ArrayList]@()
                foreach ($ambariAgent in $template.LinuxAmbariAgent) {
                    $linuxAmbariAgentResourceItem = $Resources.LinuxAmbariAgent | Where-Object { $_.LinuxAmbariAgentUId -eq $ambariAgent.LinuxAmbariAgentUId } 

                    if ($linuxAmbariAgentResourceItem -eq $null) {
                        Write-Warning "LinuxAmbariAgentUId: $($ambariAgent.LinuxAmbariAgentUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---linuxAmbariAgentResourceItem: $linuxAmbariAgentResourceItem"

                        [void]$LinuxAmbariAgent.Add($linuxAmbariAgentResourceItem)
                    }
                }
                $templateResources.LinuxAmbariAgent = $LinuxAmbariAgent
            }

            # Linux Java
            Write-Host "Processing Java for Linux ..."
            if ($template.Contains("LinuxJava")) {
                $LinuxJava = [System.Collections.ArrayList]@()
                foreach ($java in $template.LinuxJava) {
                    $linuxJavaResourceItem = $Resources.LinuxJava | Where-Object { $_.LinuxJavaUId -eq $java.LinuxJavaUId } 

                    if ($linuxJavaResourceItem -eq $null) {
                        Write-Warning "LinuxJavaUId: $($java.LinuxJavaUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---linuxJavaResourceItem: $linuxJavaResourceItem"
                        [void]$LinuxJava.Add($linuxJavaResourceItem)
                    }
                }
                $templateResources.LinuxJava = $LinuxJava
            }

            # Linux Folders
            Write-Host "Processing LinuxCopyFolder ..."
            if ($template.Contains("LinuxCopyFolders")) {
                $LinuxCopyFolder = [System.Collections.ArrayList]@()
                foreach ($linuxfolder in $template.LinuxCopyFolders) {
                    $linuxfolderResourceItem = $Resources.LinuxCopyFolders | Where-Object { $_.LinuxCopyFolderUId -eq $linuxfolder.LinuxCopyFolderUId } 

                    if ($linuxfolderResourceItem -eq $null) {
                        Write-Warning "LinuxFolderUId: $($linuxfolder.LinuxFolderUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---linuxfolderResourceItem: $linuxfolderResourceItem"
                        [void]$LinuxCopyFolder.Add($linuxfolderResourceItem)
                    }
                }
                $templateResources.LinuxCopyFolders = $LinuxCopyFolder
            }

            # Linux Directories
            Write-Host "Processing LinuxDirectories ..."
            if ($template.Contains("LinuxDirectories")) {
                $LinuxDirectories = [System.Collections.ArrayList]@()
                foreach ($linuxdir in $template.LinuxDirectories) {
                    $linuxdirResourceItem = $Resources.LinuxDirectories | Where-Object { $_.LinuxDirectoryUId -eq $linuxdir.LinuxDirectoryUId } 

                    if ($linuxdirResourceItem -eq $null) {
                        Write-Warning "LinuxDirectoryUId: $($linuxdir.LinuxDirectoryUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---linuxdirResourceItem: $linuxdirResourceItem"
                        [void]$LinuxDirectories.Add($linuxdirResourceItem)
                    }
                }
                $templateResources.LinuxDirectories = $LinuxDirectories
            }

          

            # CustomScripts
            Write-Host "Processing CustomScripts..."
            if ($template.Contains("CustomScripts")) {
                $CustomScripts = [System.Collections.ArrayList]@()
                foreach ($script in $template.CustomScripts) {
                    $scriptResourceItem = $Resources.CustomScripts | Where-Object { $_.CustomScriptUId -eq $script.CustomScriptUId } 

                    if ($scriptResourceItem -eq $null) {
                        Write-Warning "CustomScriptUId: $($script.CustomScriptUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---scriptResourceItem: $scriptResourceItem"
                        [void]$CustomScripts.Add($scriptResourceItem)
                    }
                }
                $templateResources.CustomScripts = $CustomScripts
            }


            # InstallerPackages
            Write-Host "Processing InstallerPackages..."
            if ($template.Contains("InstallerPackages")) {
                $InstallerPackages = [System.Collections.ArrayList]@()
                foreach ($item in $template.InstallerPackages) {
                    $installerResourceItem = $Resources.InstallerPackages | Where-Object { $_.InstallerPackageUId -eq $item.InstallerPackageUId } 

                    if ($installerResourceItem -eq $null) {
                        Write-Warning "InstallerPackageUId: $($item.InstallerPackageUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---installerResourceItem: $installerResourceItem"
                        [void]$InstallerPackages.Add($installerResourceItem)
                    }
                }
                $templateResources.InstallerPackages = $InstallerPackages
            }

            # HostFileSettings
            Write-Host "Processing HostFileSettings..."       
            if ($template.Contains("HostFileSettings")) {
                $HostFileSettings = [System.Collections.ArrayList]@()
                foreach ($item in $template.HostFileSettings) {
                    $hostFileResourceItem = $Resources.HostFileSettings | Where-Object { $_.HostFileSettingUId -eq $item.HostFileSettingUId } 

                    if ($hostFileResourceItem -eq $null) {
                        Write-Warning "HostFileSettingUId: $($item.HostFileSettingUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---hostFileResourceItem: $hostFileResourceItem"
                        [void]$HostFileSettings.Add($hostFileResourceItem)
                    }
                }
                $templateResources.HostFileSettings = $HostFileSettings
            }

            # Certificates
            Write-Host "Processing Certificates..."
            if ($template.Contains("Certificates")) {
                $Certificates = [System.Collections.ArrayList]@()
                foreach ($item in $template.Certificates) {
                    $certResourceItem = $Resources.Certificates | Where-Object { $_.CertificateUId -eq $item.CertificateUId } 

                    if ($certResourceItem -eq $null) {
                        Write-Warning "CertificateUId: $($item.CertificateUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---Certificate: $certResourceItem"
                        [void]$Certificates.Add($certResourceItem)
                    }
                }
                $templateResources.Certificates = $Certificates
            }

            # Websites
            Write-Host "Processing Websites..."
            if ($template.Contains("WebSites")) {
                $WebSites = [System.Collections.ArrayList]@()
                foreach ($item in $template.WebSites) {
                    $websiteResourceItem = $Resources.WebSites | Where-Object { $_.WebSiteUId -eq $item.WebSiteUId } 

                    if ($websiteResourceItem -eq $null) {
                        $WebSiteUId = $item.WebSiteUId
                        Write-Warning "WebSiteUId: $WebSiteUId is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---WebSite: $websiteResourceItem"

                        # Post Deployment Tasks
                        if ($websiteResourceItem.ContainsKey("PostDeploymentTasks")) {
                            $postDeploymentTasks = [System.Collections.ArrayList]@()
                            foreach ($postDeploymentTask in $websiteResourceItem.PostDeploymentTasks) {
                                $postDeploymentTaskResourceItem = $postDeploymentTask

                
                                Write-Verbose "---postDeploymentTaskResourceItem: $postDeploymentTaskResourceItem"
                                  
                                [void]$postDeploymentTasks.Add($postDeploymentTaskResourceItem)
                                
                            }
                            $websiteResourceItem.PostDeploymentTasks = $postDeploymentTasks
                        }

                        [void]$WebSites.Add($websiteResourceItem)
                    }
                }
                $templateResources.WebSites = $WebSites
            }

           # PythonApps
            Write-Host "Processing PythonApps..."
            if ($template.Contains("PythonApps")) {
                $PythonApps = [System.Collections.ArrayList]@()
                foreach ($item in $template.PythonApps) {
                    $pythonappResourceItem = $Resources.PythonApps | Where-Object { $_.PythonAppUId -eq $item.PythonAppUId } 

                    if ($pythonappResourceItem -eq $null) {
                        $PythonAppUId = $item.PythonAppUId
                        Write-Warning "PythonAppUId: $PythonAppUId is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---PythonApp: $pythonappResourceItem"
                        [void]$PythonApps.Add($pythonappResourceItem)
                    }
                }
                $templateResources.PythonApps = $PythonApps
            }


            # AppServiceTasks
            Write-Host "Processing AppServiceTasks..."
            if ($template.Contains("AppServiceTasks")) {
                $AppServiceTasks = [System.Collections.ArrayList]@()
                foreach ($task in $template.AppServiceTasks) {
                    # basic service info
                    Write-Verbose "TaskName: $task" 
                    $taskResourceItem = $Resources.AppServiceTasks | Where-Object { $_.AppServiceTaskUId -eq $task.AppServiceTaskUId } 
                    
                    if ($taskResourceItem -eq $null) {
                        Write-Warning "TaskUId: $($task.AppServiceTaskUId) is not defined in the Resources section."
                    }
                    else {
                    
                       [void]$AppServiceTasks.Add($taskResourceItem)
                    }
                    }
                    $templateResources.AppServiceTasks = $AppServiceTasks
                }
                


             # Python
            Write-Host "Processing Python..."
            if ($template.Contains("Python")) {
                $Python = [System.Collections.ArrayList]@()
                foreach ($item in $template.Python) {
                    $pythonResourceItem = $Resources.Python | Where-Object { $_.PythonUId -eq $item.PythonUId } 

                    if ($pythonResourceItem -eq $null) {
                        $pythonUId = $item.PythonUId
                        Write-Warning "WebSiteUId: $pythonUId is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---WebSite: $pythonResourceItem"

                        [void]$Python.Add($pythonResourceItem)
                    }
                }
                $templateResources.Python = $Python
            }

            # Apache
            Write-Host "Processing Apache..."
            if ($template.Contains("Apache")) {
                $Apache = [System.Collections.ArrayList]@()
                foreach ($item in $template.Apache) {
                    $apacheResourceItem = $Resources.Apache | Where-Object { $_.ApacheUId -eq $item.ApacheUId } 

                    if ($apacheResourceItem -eq $null) {
                        $apacheUId = $item.ApacheUId
                        Write-Warning "ApacheUId: $ApacheUId is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---Apache: $apacheResourceItem"

                        [void]$Apache.Add($apacheResourceItem)
                    }
                }
                $templateResources.Apache = $Apache
            }

            # Tomcat
            Write-Host "Processing Tomcat..."
            if ($template.Contains("Tomcat")) {
                $Tomcat = [System.Collections.ArrayList]@()
                foreach ($item in $template.Tomcat) {
                    $tomcatResourceItem = $Resources.Tomcat | Where-Object { $_.TomcatUId -eq $item.TomcatUId } 

                    if ($tomcatResourceItem -eq $null) {
                        $tomcatUId = $item.TomcatUId
                        Write-Warning "TomcatUId: $TomcatUId is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---Tomcat: $tomcatResourceItem"

                        [void]$Tomcat.Add($tomcatResourceItem)
                    }

                    ## ConfigurationProperties
                    #if ($tomcatResourceItem.ContainsKey("ConfigurationProperties")) {
                    #    $ConfigurationProperties = [System.Collections.ArrayList]@()
                    #    foreach ($setting in $tomcatResourceItem.ConfigurationProperties) {
                    #        [void]$ConfigurationProperties.Add($setting)  
                    #    }
                    #    [void]$Tomcat.Add($ConfigurationProperties)
                    #}
                    #
                    ## PropertyFiles
                    #if ($tomcatResourceItem.ContainsKey("PropertyFiles")) {
                    #    $PropertyFiles = [System.Collections.ArrayList]@()
                    #    foreach ($setting in $tomcatResourceItem.PropertyFiles) {
                    #        [void]$PropertyFiles.Add($setting)
                    #          
                    #    }
                    #    [void]$Tomcat.Add($PropertyFiles)
                    #}
                }
                $templateResources.Tomcat = $Tomcat
            }


            # RabbitMQ
            Write-Host "Processing RabbitMQ..."
            if ($template.Contains("RabbitMQ")) {
                $RabbitMQ = [System.Collections.ArrayList]@()
                foreach ($item in $template.RabbitMQ) {
                    $rabbitMQResourceItem = $Resources.RabbitMQ | Where-Object { $_.RabbitMQUId -eq $item.RabbitMQUId } 

                    if ($rabbitMQResourceItem -eq $null) {
                        $rabbitMQUId = $item.RabbitMQUId
                        Write-Warning "RabbitMQUId: $RabbitMQUId is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---RabbitMQ: $rabbitMQResourceItem"

                        [void]$RabbitMQ.Add($rabbitMQResourceItem)
                    }

                  
                }
                $templateResources.RabbitMQ = $RabbitMQ
            }

            # MongoDbRestore
            Write-Host "Processing MongoDbRestore..."
            if ($template.Contains("MongoDbRestore")) {
                $MongoDbRestore = [System.Collections.ArrayList]@()
                foreach ($item in $template.MongoDbRestore) {
                    $mongoDbRestoreResourceItem = $Resources.MongoDbRestore | Where-Object { $_.MongoDbRestoreUId -eq $item.MongoDbRestoreUId } 

                    if ($mongoDbRestoreResourceItem -eq $null) {
                        $mongoDbRestoreUId = $item.MongoDbRestoreUId
                        Write-Warning "MongoDbRestoreUId: $MongoDbRestoreUId is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---MongoDbRestore: $mongoDbRestoreResourceItem"

                        [void]$MongoDbRestore.Add($mongoDbRestoreResourceItem)
                    }

                  
                }
                $templateResources.MongoDbRestore = $MongoDbRestore
            }

            # Packages
            Write-Host "Processing Packages..."
            if ($template.Contains("Packages")) {
                $Packages = [System.Collections.ArrayList]@()
                foreach ($item in $template.Packages) {
                    $packageResourceItem = $Resources.Packages | Where-Object { $_.PackageUId -eq $item.PackageUId } 

                    if ($packageResourceItem -eq $null) {
                        Write-Warning "PackageUId: $($item.PackageUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "Package: $packageResourceItem"
                        [void]$Packages.Add($packageResourceItem)
                    }
                }
                $templateResources.Packages = $Packages
            }

            # WindowsServices
            Write-Host "Processing WindowsServices..."
            if ($template.Contains("WindowsServices")) {
                $WindowsServices = [System.Collections.ArrayList]@()
                foreach ($service in $template.WindowsServices) {
                    # basic service info
                    Write-Verbose "ServiceName: $service" 
                    $serviceResourceItem = $Resources.WindowsServices | Where-Object { $_.WindowsServiceUId -eq $service.WindowsServiceUId } 

                    if ($serviceResourceItem -eq $null) {
                        Write-Warning "ServiceUId: $($service.WindowsServiceUId) is not defined in the Resources section."
                    }
                    else {
                        [void]$WindowsServices.Add($serviceResourceItem)
                    }
                }
                $templateResources.WindowsServices = $WindowsServices
            }

            # ScheduledTasks
            Write-Host "Processing ScheduledTasks..."
            if ($template.Contains("ScheduledTasks")) {
                $ScheduledTasks = [System.Collections.ArrayList]@()
                foreach ($item in $template.ScheduledTasks) {
                    $resourceItem = $Resources.ScheduledTasks | Where-Object { $_.ScheduledTaskUId -eq $item.ScheduledTaskUId } 

                    if ($resourceItem -eq $null) {
                        Write-Warning "ScheduledTaskUId: $($item.ScheduledTaskUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---ScheduledTaskItem: $resourceItem"
                        [void]$ScheduledTasks.Add($resourceItem)
                    }
                }
                $templateResources.ScheduledTasks = $ScheduledTasks
            }

            # MongoDbServers
            Write-Host "Processing MongoDbServers..."
            if ($template.Contains("MongoDbServers")) {
                $MongoDbServers = [System.Collections.ArrayList]@()
                foreach ($dbServer in $template.MongoDbServers) {
                    $mongoDbServerItem = $Resources.MongoDbServers | Where-Object { $_.MongoDbServerUid -eq $dbServer.MongoDbServerUid } 

                    if ($mongoDbServerItem -eq $null) {
                        Write-Warning "MongoDbServer: $($dbServer.MongoDbServerUid) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---mongoDbInstanceItem: $mongoDbServerItem"
                        [void]$MongoDbServers.Add($mongoDbServerItem)
                    }
                } 
                $templateResources.MongoDbServers = $MongoDbServers     
            }

            # MongoDbInstances
            Write-Host "Processing MongoDbInstances..."
            if ($template.Contains("MongoDbInstances")) {
                $MongoDbInstances = [System.Collections.ArrayList]@()
                foreach ($dbInstance in $template.MongoDbInstances) {
                    $mongoDbInstanceItem = $Resources.MongoDbInstances | Where-Object { $_.MongoDbInstanceUId -eq $dbInstance.MongoDbInstanceUId } 
                    Write-Verbose "---mongoDbInstanceItem: $mongoDbInstanceItem"

                    # check if db server has already been defined
                    $serverDefined = $null
                    
                    if ($templateResources.MongoDbServers.Count -gt 0) {
                        $serverDefined = $templateResources.MongoDbServers | Where-Object { $_.MongoDbServerUId -eq $dbInstance.MongoDbServerUId }
                    }
                    if ($serverDefined) {
                        [void]$MongoDbInstances.Add($mongoDbInstanceItem)
                    }
                    else {
                        $mongoDbServerUId = $dbInstance.MongoDbServerUid
                        Write-Warning "Cannot find mongoDb server matching the $mongoDbServerUId in this template."
                    }
                }
                $templateResources.MongoDbInstances = $MongoDbInstances
            }

            # Files
            Write-Host "Processing Files..."
            if ($template.Contains("Files")) {
                $Files = [System.Collections.ArrayList]@()
                foreach ($file in $template.Files) {
                    $fileResourceItem = $Resources.Files | Where-Object { $_.FileUId -eq $file.FileUId } 

                    if ($fileResourceItem -eq $null) {
                        Write-Warning "FileUId: $($file.FileUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---fileResourceItem: $fileResourceItem"
                        [void]$Files.Add($fileResourceItem)
                    }
                }
                $templateResources.Files = $Files
            }

            # Folders
            Write-Host "Processing Folders..."
            if ($template.Contains("Folders")) {
                $Folders = [System.Collections.ArrayList]@()
                foreach ($folder in $template.Folders) {
                    $folderResourceItem = $Resources.Folders | Where-Object { $_.FolderUId -eq $folder.FolderUId } 

                    if ($folderResourceItem -eq $null) {
                        Write-Warning "FolderUId: $($folder.FolderUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---folderResourceItem: $folderResourceItem"
                        [void]$Folders.Add($folderResourceItem)
                    }
                }
                $templateResources.Folders = $Folders
            }

            # Hadoop
            Write-Host "Processing Hadoop..."
            if ($template.Contains("Hadoop")) {
                $Hadoops = [System.Collections.ArrayList]@()
                foreach ($hadoop in $template.Hadoop) {
                    $hadoopResourceItem = $Resources.Hadoop | Where-Object { $_.HadoopUId -eq $hadoop.HadoopUId } 

                    if ($hadoopResourceItem -eq $null) {
                        Write-Warning "HadoopUId: $($hadoop.HadoopUId) is not defined in the Resources section."
                    }
                    else {
                        Write-Verbose "---hadoopResourceItem: $hadoopResourceItem"
                        [void]$Hadoops.Add($hadoopResourceItem)
                    }
                }
                $templateResources.Hadoops = $Hadoops
            }

            # add the nodes using this template
            $targetServers = $Servers | Where-Object { $_.ServerTemplateUId -eq $templateId }
            Write-Host "TargetServerCount: " $targetServers.Count
            foreach ($server in $targetServers) {
                Write-Host "Server: " $server.Name
                $node = @{}
                $node.NodeName = $server.Name

                $node.Certificates = $templateResources.Certificates
                $node.HostFileSettings = $templateResources.HostFileSettings
                $node.WebSites = $templateResources.WebSites
                $node.PythonApps = $templateResources.PythonApps
                $node.Packages = $templateResources.Packages
                $node.AppServiceTasks = $templateResources.AppServiceTasks
                $node.WindowsServices = $templateResources.WindowsServices
                $node.ScheduledTasks = $templateResources.ScheduledTasks
                $node.MongoDbServers = $templateResources.MongoDbServers
                $node.MongoDbInstances = $templateResources.MongoDbInstances
                $node.InstallerPackages = $templateResources.InstallerPackages
                $node.Folders = $templateResources.Folders
                $node.Files = $templateResources.Files
                $node.CustomScripts = $templateResources.CustomScripts
                $node.Hadoops = $templateResources.Hadoops
               

                $node.LinuxDirectories = $templateResources.LinuxDirectories
                $node.LinuxCopyFolders = $templateResources.LinuxCopyFolders
                $node.LinuxJava = $templateResources.LinuxJava
                $node.LinuxAmbariServer = $templateResources.LinuxAmbariServer
                $node.LinuxAmbariAgent = $templateResources.LinuxAmbariAgent
                $node.LinuxHadoop = $templateResources.LinuxHadoop
                $node.LinuxElasticSearch = $templateResources.LinuxElasticSearch
                $node.LinuxMonit = $templateResources.LinuxMonit
                $node.LinuxConfigureHDFS = $templateResources.LinuxConfigureHDFS
                $node.LinuxConfigureHive = $templateResources.LinuxConfigureHive

                $node.Python = $templateResources.Python
                $node.Apache = $templateResources.Apache
                $node.Tomcat = $templateResources.Tomcat
                $node.RabbitMQ = $templateResources.RabbitMQ
                $node.MongoDbRestore = $templateResources.MongoDbRestore 

                $node = Update-ServerTokens -server $server -node $node

                [void]$AllNodes.Add($node)
            }
        }
        
        # add nodes
        $configData.AllNodes = $AllNodes | ToArray

        # return config
        return $configData
    }

    end {
        $configData = $null
    }
}

function Update-ServerTokens {
    param (
        [object]$server,
        [object]$node
    )

    process {
        # tokens
        if ($server.Contains("Properties")) {
            $properties = $server.Properties
       

            $nodeString = $node | ConvertTo-Json -Depth 100        

            foreach ($propKey in $properties.Keys) {
                $value = $properties[$propKey]
                $nodeString = $nodeString.Replace("{$propKey}", $value)
            }

            $node = $nodeString | ConvertFrom-Json
            $nodeHt = $node | ConvertPSObjectToHashtable

            return $nodeHt
        }
        return $node
    }
}

# converts an object to a hashtable
function ConvertPSObjectToHashtable {
    param (
        [Parameter(ValueFromPipeline)]
        $InputObject
    )

    process {
        if ($null -eq $InputObject) { return $null }

        if ($InputObject -is [System.Collections.IEnumerable] -and $InputObject -isnot [string]) {
            $collection = @(
                foreach ($object in $InputObject) { ConvertPSObjectToHashtable $object }
            )

            Write-Output -NoEnumerate $collection
        }
        elseif ($InputObject -is [psobject]) {
            $hash = @{}

            foreach ($property in $InputObject.PSObject.Properties) {
                $hash[$property.Name] = ConvertPSObjectToHashtable $property.Value
            }

            $hash
        }
        else {
            $InputObject
        }
    }
}

# converts an object to an array
function ToArray {
    begin {
        $output = @(); 
    }
    process {
        $output += $_; 
    }
    end {
        return $output; 
    }
}

Export-ModuleMember -Function *