﻿param(
    [Parameter(Mandatory = $true)]
    [string] $ConfigFile = "",
	
    [Parameter(Mandatory = $true)]
    [string] $MacroJsonFile = "",

    #[Parameter(Mandatory = $true)]
    #[string] $IsMergeRequired,
    
    [string] $deployScript,

    [string] $helperFunctionsScript = './Scripts/Common/myWizard-HelperFunctions.psm1',

    [string] $buildPsDsc,

    [string] $DeploymentMethodology,
    [string] $DeploymentMode,
    [string] $ShouldDownloadPackages,


    [Parameter(Mandatory = $true)]
    [string] $AESKey = "",

    [Parameter(Mandatory = $true)]
    [string] $VectorKey = ""
)

$encryptedBdef = Get-Content -Raw -Path $ConfigFile
$encryptedMacro = Get-Content -Raw -Path $MacroJsonFile

$bdefcontent = .\Scripts\Common\Cryptography.ps1 -Action Decrypt -KeyValue $AESKey -VectorValue $VectorKey -text $encryptedBdef 
$macroValues = .\Scripts\Common\Cryptography.ps1 -Action Decrypt -KeyValue $AESKey -VectorValue $VectorKey -text $encryptedMacro

#$bdefcontent = $bdefcontent.Replace("{PrimaryDBServerServerHostName}",$macroValues.PSObject.Properties.Item("{Primary_Database_1ServerHostName}").Value)
#$bdefcontent = $bdefcontent.Replace("{IsHadoopServerDeploymentEnabled}",$macroValues.PSObject.Properties.Item("{IsPrimary_Hadoop_1ServerDeploymentEnabled}").Value)
#$bdefcontent = $bdefcontent.Replace("{PrimaryDBServerServerIPAddress}",$macroValues.PSObject.Properties.Item("{Primary_Database_1ServerIPAddress}").Value)
#$bdefcontent = $bdefcontent.Replace("{SecondaryDBServerServerIPAddress}",$macroValues.PSObject.Properties.Item("{Secondary_Database_2ServerIPAddress}").Value)
#$bdefcontent = $bdefcontent.Replace("{SecondaryDBServerServerHostName}",$macroValues.PSObject.Properties.Item("{Secondary_Database_2ServerHostName}").Value)
#$bdefcontent = $bdefcontent.Replace("{ArbiterDBServerServerIPAddress}",$macroValues.PSObject.Properties.Item("{Arbiter_Database_3ServerIPAddress}").Value)
#$bdefcontent = $bdefcontent.Replace("{ArbiterDBServerServerHostName}",$macroValues.PSObject.Properties.Item("{Arbiter_Database_3ServerHostName}").Value)

#$bdefcontent = $bdefcontent.Replace("{ServerAdminAccountUserId}",$targetServerUnP.UserName)
#$bdefcontent = $bdefcontent.Replace("{ServerAdminAccountPassword}",$targetServerUnP.GetNetworkCredential().Password)
#$bdefcontent = $bdefcontent.Replace("{MountUserName}",$mountUnP.UserName)
#$bdefcontent = $bdefcontent.Replace("{MountPassword}",$mountUnP.GetNetworkCredential().Password)

$bdefcontent = $bdefcontent | ConvertFrom-Json
if($bdefcontent.TargetOS -ne "Windows"){
    $mountUnP = Get-Credential -Message "Provide Mount Credentials" -UserName $env:USERNAME
    $bdefcontent.Environment.MountUserName = $mountUnP.UserName
    $bdefcontent.Environment.MountPassword = $mountUnP.GetNetworkCredential().Password
}
if($bdefcontent.TargetOS -eq "Windows"){
$targetServerUnP = Get-Credential -Message "Provide Target Server Credentials" -UserName $($env:USERDOMAIN + "\" + $env:USERNAME)
}
if($bdefcontent.TargetOS -eq "Linux"){
$targetServerUnP = Get-Credential -Message "Provide Target Server Credentials" -UserName "root"
}
$bdefcontent.Servers | ForEach-Object {$_.AdminUser = $targetServerUnP.UserName}
$bdefcontent.Servers | ForEach-Object {$_.AdminPassword = $targetServerUnP.GetNetworkCredential().Password }

[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
$dbPassword = ''
while('' -eq $dbPassword) {
$dbCred = Get-Credential -Message "Provide Database Credentials" -UserName "Admin"
$dbPassword = $dbCred.GetNetworkCredential().Password
}
$bdefcontent.Environment.AdminUserName = $targetServerUnP.UserName
$bdefcontent.Environment.AdminPassword = $targetServerUnP.GetNetworkCredential().Password
$macroValues = $macroValues.Replace("[DBPassword]", [System.Web.HttpUtility]::UrlEncode($dbPassword))
$macroValues = $macroValues.Replace("[DBPasswordDecoded]", $dbPassword)
$encryptedMacro = .\Scripts\Common\Cryptography.ps1 -Action Encrypt -KeyValue $AESKey -VectorValue $VectorKey -text $macroValues 
$encryptedMacro | Set-Content -Path $MacroJsonFile

$jsonParams = $bdefcontent
$bdefcontent = $bdefcontent | ConvertTo-Json -Depth 100
$bdefcontent = $bdefcontent.Replace("[DBPasswordDecoded]", $dbPassword)
$bdefcontent = [regex]::Replace($bdefcontent,"\s+"," ")

.\Scripts\Common\Cryptography.ps1 -Action Encrypt -KeyValue $AESKey -VectorValue $VectorKey -text $bdefcontent | Set-Content -Path $ConfigFile


Write-Host "Verifying packages for deployment" -BackgroundColor Yellow -ForegroundColor Black
Write-Host
$Global:count = 0
function Check-PathsExists {
    param (
        $resourceName,
        $packageFile
    )
    begin {
        #if($resourceName -ieq "DataLoaderConfigurations"){
        #    $bdef.Resources.$resourceName | Add-Member -Name PackageFolderName -Value "myWizard"  -MemberType NoteProperty
        #    $bdef.Resources.$resourceName | Add-Member -Name PackageFile -Value "myWizard.DB.zip" -MemberType NoteProperty
        #}
        $resources = $jsonParams.ServerTemplates | 
        Where-Object { $_.ServerTemplateUId -in $($jsonParams.Servers | 
                Where-Object { $_.IsRequired -eq $true } | 
                Select-Object -ExpandProperty ServerTemplateUId) } | 
        Select-Object -Property $resourceName

        if($resources.$resourceName.Count -gt 0) {
            $uidField = $($resources.$resourceName | Get-Member | Where-Object { $_.Name -match "uid" }).Name
        }
    }
    process {
        #$count = 0
        #Write-Host ".\AppServices\"+ $jsonParams.Resources.$resourceName.PackageFolderName +"\"+ $jsonParams.Resources.$resourceName.InstalledVersion+"\"+ $jsonParams.Resources.$resourceName.$packageFile
        if($resources.$resourceName.Count -gt 0) {
            $jsonParams.Resources.$resourceName | 
            Where-Object { $_.$uidField -in $($resources.$resourceName | Select-Object -ExpandProperty $uidField) -and $_.IsDeploymentEnabled -eq $true} | 
            ForEach-Object {
                if (-not (Test-Path -Path $(".\AppServices\" + $_.PackageFolderName + "\" + $_.InstalledVersion + "\" + $_.$packageFile))) {
                    $Global:count++
                    Write-Host $(".\AppServices\" + $_.PackageFolderName + "\" + $_.InstalledVersion + "\" + $_.$packageFile) -BackgroundColor Red -ForegroundColor White
                }
            }
        } 
    }
}
Check-PathsExists -resourceName "WebSites" -packageFile "PackageFile"
Check-PathsExists -resourceName "WindowsServices" -packageFile "PackageFile"
Check-PathsExists -resourceName "Tomcat" -packageFile "PackageFile"
Check-PathsExists -resourceName "PythonApps" -packageFile "PackageFile"
Check-PathsExists -resourceName "Packages" -packageFile "PackageFile"
Check-PathsExists -resourceName "MongoDbRestore" -packageFile "BackupName"
#Check-PathsExists -resourceName "DataLoaderConfigurations" -packageFile "PackageFile"
 
if($Global:count -ne 0){
    Write-Host
    Write-Host "Above mentioned packages are missing which you have selected for current deployment" -BackgroundColor Yellow -ForegroundColor Black
    $input = Read-Host -Prompt "Do you still wish to continue with deplooyment (y/n) - Default is yes"
    if($input -ieq "n"){
        break
    }
}



if($jsonParams.TargetOS -eq 'Windows') {
    $invokeWindowsDSC = $("./Scripts/PowerShellDSC/Install-myWizard-Windows.ps1 -ConfigFile " + $ConfigFile + " -MacroJsonFile " + $MacroJsonFile + " -AESKey " + $AESKey + " -VectorKey " + $VectorKey)
    Invoke-Expression $invokeWindowsDSC
    Write-Host "`n--- SCRIPT EXECUTIONS COMPLETE ---`n" -ForegroundColor Green
    Read-Host
    break;
} 


$DscEnvironmentSettings = $jsonParams.Environment
$CustomerName    = $jsonParams.Client.Name
$Version         = $jsonParams.Version.Name
$Environment     = $DscEnvironmentSettings.Name
$requireConsent  = $jsonParams.IsConsentRequired
$localPath       = (Resolve-Path .\).Path
$DeploymentModel = $jsonParams.DeploymentModel.Name
$IsFullDeployment = $jsonParams.IsFullDeployment
$ShouldDownloadPackages = $jsonParams.PackageDataSource.Folder
$DeploymentEnvironment = $jsonParams.Environment.DeploymentEnvironment
$ReleaseVersion = $jsonParams.ReleaseVersion
$ClientCode = $jsonParams.Client.Code

$buildPsDsc = './Scripts/PowerShellDSC/Build-MyWizardPowerShellDSCLinux.ps1'

$deployScript = './Scripts/PowerShellDSC/Deploy-MyWizardLinux.ps1'

$EnvironmentBasePath = "$localPath\Clients\$CustomerName\$Environment\$Version"

$StopWatch = New-Object System.Diagnostics.Stopwatch

Write-Host "`n--- WELCOME TO MYWIZARD ONE CLICK DEPLOYMENT ---`n" -ForegroundColor Green

#Checking if required scripts are present in the same directory"
Write-Host  "Checking if required scripts are present..." -ForegroundColor Gray

$isScriptMissing = $false


if(Test-Path ./Logs) {
    Remove-Item -Force -Recurse -Path ./Logs -ErrorAction SilentlyContinue | Out-Null
}
if(Test-Path ./MOF) {
    Remove-Item -Force -Recurse -Path ./MOF -ErrorAction SilentlyContinue | Out-Null
}


<#
if(!(Test-Path $buildScript)) {
    Write-Error "$buildScript is missing"
    $isScriptMissing = $true
}
#>


if(!(Test-Path $deployScript)) {
    Write-Error "$deployScript is missing"
    $isScriptMissing = $true
}
if(!(Test-Path $helperFunctionsScript)) {
    Write-Error "$helperFunctionsScript is missing"
    $isScriptMissing = $true
}
else{
    $invokeImportModule = "Import-Module $helperFunctionsScript"
    Invoke-Expression $invokeImportModule
}

if(!(Test-Path $buildPsDsc)) {
    Write-Error "$buildPsDsc is missing"
    $isScriptMissing = $true
}

if($isScriptMissing -eq $true) {
    Write-Error "Please copy required scripts and re-run to proceed with execution"
}
else {
    Write-Host "`nSTEP 1: BUILD MYWIZARD" -ForegroundColor Yellow
    Write-Host "This step generates the files required to deploy applications (*.mof, prerequisites and deployment definition files)" -ForegroundColor Yellow

    Write-Host "`nSTEP 2: DEPLOY MYWIZARD" -ForegroundColor Yellow
    Write-Host "This step deploys the mof file to target servers`n" -ForegroundColor Yellow

    if($requireConsent -eq $true) {
        $consent = Read-Host "Do we have your consent to execute this script? Press [Y] Yes to continue or [N] No to terminate."
        while($consent -ne 'y') {
            if($consent -eq 'n') { exit }
            $consent = Read-Host "Invalid response. Please select [Y] Yes or [N] No"
            }
        }

    #Configuration
    if($requireConsent -ne $true -or $consent -eq 'y') {
        #BUILD
        $invokeBuildScript = "$buildPsDsc -ConfigFile `"$ConfigFile`" -MacroJsonFile `"$MacroJsonFile`" -AESKey `"$AESKey`" -VectorKey `"$VectorKey`""
        $StopWatch.Reset()
        $StopWatch.Start()
        Invoke-Expression $invokeBuildScript
        $StopWatch.Stop()
        $totalSeconds = $StopWatch.Elapsed.TotalSeconds
        Write-Host "Build completed in $totalSeconds seconds"

        #DEPLOY
        $DeploymentParamsFile = "$localPath\$($DscEnvironmentSettings.DeploymentParamsFile)"
        $invokeDeployScript = "$deployScript -ConfigFile `"$DeploymentParamsFile`" -ShowStepInfo $false"
        $StopWatch.Reset()
        $StopWatch.Start()
        Invoke-Expression $invokeDeployScript
        $StopWatch.Stop()
        $totalSeconds = $StopWatch.Elapsed.TotalSeconds
        Write-Host "Deployment completed in $totalSeconds seconds"
                        
    }

    Write-Host "`n--- SCRIPT EXECUTIONS COMPLETE ---`n" -ForegroundColor Green
}


function MoveLogs {
    Copy-Item -Path ".\Scripts\CustomScripts\HTML\*" -Destination ".\Logs\" -Force
    New-Item -Path ".\Logs\Reports\" -ItemType "Directory" -Force -ErrorAction SilentlyContinue| Out-Null
    Get-Childitem -Path ".\Logs\" | Where-object {$_.Name -ne "ReportIndex.html"} | Move-Item -Destination ".\Logs\Reports\"  -Force -ErrorAction SilentlyContinue| Out-Null

    $arr = Get-ChildItem ".\Logs\Reports\"| Select Name | Sort-Object Name -Descending
    $fs = "  <li class=`"nav-item`">
                       <a class=`"nav-link`" href=`"#`" >filename</a>
                    </li>"
    $fs1 = "`n"
    foreach ($item in $arr)
    {
      #if (($item.Name -ne "menu.html") -AND  ($item.Name -ne "Header.html"))
      #{
        $fs1=$fs1 + $fs -replace "filename", $item.Name
        $fs1 = $fs1 +  "`n"
      #}
    }

    $fs1 = " <ul id=`"menu`" class=`"nav flex-column`" style=`"font-family: inherit;`">   " + $fs1
    #Write-Host $fs1
    (Get-Content ".\Logs\ReportIndex.html") -replace '<ul id="menu" class="nav flex-column" style="font-family: inherit;"> ', $fs1 | Set-Content ".\Logs\ReportIndex.html"
}

function Send-Email {
    begin {
        [securestring]$password = ConvertTo-SecureString 'BDPcatF9k7BrUac8OfW0vzq2YYPfEs1AnbujyqA20VOP' -AsPlainText -Force
        $cred = New-Object System.Management.Automation.PSCredential ('AKIASLNFXDCIMFECR5PM', $password)
        $from = "OneClick Installer <oneclick@mywizard360.com>"
        $smtp = "email-smtp.us-east-1.amazonaws.com"
        $port = 587
        $ClientName = $ReleaseVersion + "_" + $DeploymentEnvironment
    }
    process {
    try {
        if($ClientCode -match 'EU')
        {
          [string[]]$to = @(
                           "vikram.b.krishnan@accenture.com",
                           "praveenkumar.rj@accenture.com"
                        ) 
        }
        else{
        [string[]]$to = @(
                           "p.kumar.estamsetti@accenture.com",
                           "anurag.a.mohapatra@accenture.com",
                           "anshuman.saini@accenture.com",
                           "gowthami.chirugudi@accenture.com",
                           "shekhar.c.singh@accenture.com",
                           "jahnavi.a.r@accenture.com",
                           "vikram.s.gopal@accenture.com",
                           "aishwarya.j.hegde@accenture.com",
                           "m.c.kumar.srivastava@accenture.com",
                           "rajendra.p.mandla@accenture.com",
                           "jami.meghana@accenture.com",
                           "a.narasimharaju@accenture.com",
                           "akanksha.k.pandey@accenture.com",
                           "shaon.roy@accenture.com",
                           "k.keerthi.krishna@accenture.com",
                           "niharika.q.singh@accenture.com",
                           "nerala.vani@accenture.com"
                        )
        }
        $installerVersion = "v4.6"
        $subject = $("OCI - Deployment completion alert " + $ClientName)
        $body = $("<!DOCTYPE html> <html lang='en'> <head> <meta charset='UTF-8'> <meta name='viewport' content='width=device-width, initial-scale=1.0'> <title>Document</title> <style> html,head,body,div,span { margin: 0; padding: 0; font-family: 'Calibri (Body)'; font-size: 12pt; } .logitems { padding: 0 0 0 20px; } .adminConsole { color: gray; font-size: 10pt; } </style> </head> <body>Hi Team,<br><br> Attaching the zip with the following : <br> <span class='logitems'> - Deploy logs</span><br> <span class='logitems'> - Build logs</span><br> <span class='logitems'> - Dsc logs</span><br> <span class='logitems'> - Omiserver logs</span><br> <span class='logitems'> - Post deployment reports</span><br><br> Deployment completed from <b>" + $localPath + "</b> folder.<br><br><br> Thanks,<br> myWizard - OneClickInstaller,<br>" + $env:USERNAME + "<br><br> <span class='adminConsole'>NOTE: This deployment is completed using OneClickTools - " + $installerVersion + "</span> </body> </html>")
        Get-ChildItem -Path ".\Logs\*" | Compress-Archive -DestinationPath $(".\Logs\" + $ClientName + ".zip") -Force -CompressionLevel Optimal

        #$InstallerTmp = @()
        #$InstallerTmp+= $(Get-ChildItem -Path ".\*.bdef.tmp.json").FullName
        #$InstallerTmp+= $(Get-ChildItem -Path ".\*.macro.tmp").FullName
        #$InstallerTmp+= $(Get-ChildItem -Path ".\MOF\*").FullName
        #New-Item -Path ".\Backup" -ItemType "Directory" -Force | Out-Null
        #$InstallerTmp | Compress-Archive -DestinationPath $(".\Backup\InstallerBackup" + $(Get-Date -Format "MMddyyyy_HHmm") + ".zip") -Force -CompressionLevel Optimal


        [string[]]$attachments = @($(".\Logs\" + $ClientName + ".zip"))

        if ($null -ne $attachments) {
            Send-MailMessage -From $from -To $to -Subject $subject -Body $body -BodyAsHtml -UseSsl -Credential $cred -SmtpServer $smtp -Port $port -Attachments $attachments
        }
        else {
            Send-MailMessage -From $from -To $to -Subject $subject -Body $body -BodyAsHtml -UseSsl -Credential $cred -SmtpServer $smtp -Port $port
        }
        } 
        catch { }
       # Remove-item -Path ".\MOF" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
        #Remove-item -Path ".\DeployDef.prod.json" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
    }
}




MoveLogs
Send-Email
if (Test-Path -Path ".\Logs\ReportIndex.html")
{
Start-Process -filepath  ".\Logs\ReportIndex.html" -ErrorAction SilentlyContinue | Out-Null
}
Write-Host ************************************************************************************************************************************** -BackgroundColor Green -ForegroundColor Black
Write-Host "NOTE : If you have completed the deployment then don't forget to clean the installer files by running" -ForegroundColor Red
Write-Host "OneClickTools > QuickTools > 'Clean installer directory'" -ForegroundColor Red
Write-Host ************************************************************************************************************************************** -BackgroundColor Green -ForegroundColor Black
Read-Host