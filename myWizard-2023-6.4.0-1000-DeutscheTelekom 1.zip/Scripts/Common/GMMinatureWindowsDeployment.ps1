﻿$LogFilePath = ".\Logs\myWizardGMWindowsDeployment_" + (Get-Date -Format "yyyyMMdd_hhmmss") + ".log"

Clear-Host
# start transcript
Start-Transcript -Path $LogFilePath


$Node = Read-Host "Enter the intermediate server IP"
$Credential = Get-Credential

#$Node = "192.168.16.102"
#[securestring]$password = ConvertTo-SecureString 'Oneclick!!!919' -AsPlainText -Force
#$Credential = New-Object System.Management.Automation.PSCredential ('mywizard360\p.kumar.estamsetti', $password)

Write-Host
Write-Host "Please select the version for deployment" -BackgroundColor Green
"[1] Linux R2.0(MT)"
"[2] Linux R2.1"
$Version = Read-Host -Prompt "Enter Id to select"
Write-Host 

Write-Host "Deployment for - " -BackgroundColor Green
"[1] MSPS"
"[2] HPALM"
"[3] Both"
$InstallationType = Read-Host -Prompt "Enter Id to select"
Write-Host
$MinatureAPI = Read-Host "Enter Minature API hostname (without https://)"
$MinatureAPIPort = Read-Host "Enter Minature API Port"
$HostEntry = Read-Host "Enter MSPS instance IP and Hostname ( e.g  - 10.0.0.1 localhost.com)"
$MinatureAPISubApp = ''

if ($Version -eq '1') {
    $MinatureAPIHost = $MinatureAPI.Split('/')[0]
    $MinatureAPISubApp = $MinatureAPI.Split('/')[1]
}
else {
    $MinatureAPIHost = $MinatureAPI
}

Write-Host
Write-Host 'Executing Winrm command' -BackgroundColor Green
winrm set winrm/config/client '@{TrustedHosts="' $Node '"}' | Out-Null

$session = New-PSSession -ComputerName $Node -Credential $Credential

$Macrojsonpath = '.\myWizard-Installer.macro.tmp'
$PackagePath = 'myWizard.GatewayManager.WebAPI.zip' , 'myWizard.GatewayManager.TGMSPSOutboundService.zip' , 'myWizard.GatewayManager.TGHPALMInboundService.zip', 'myWizard.GatewayManager.TGHPALMIterationInboundService.zip', 'myWizard.Gatewaymanager.TGHPALMOutboundService.zip'
$SharePath = "\\" + $Node + "\Accenture"
$TargetPath = "D:\Accenture\myWizard\Apps\"
$ReplaceMacroPathsMSPS = ($MinatureAPI + "\Web.config") , ($MinatureAPI + "\FormsAuthProviderConfiguration.xml") , ($MinatureAPI + "\AzureADAuthProviderConfiguration.xml") , ("GatewayManager\ProcessPipelines\TG-MSPS-Outbound\TG-MSPS-Outbound.config.xml")  
$ReplaceMacroPathsHPALM = ("GatewayManager\ProcessPipelines\TG-HPALM-Inbound\TG-HPALM-Inbound.config.xml") , ("GatewayManager\bin\TG-HPALM-Inbound\Accenture.MyWizard.GatewayManager.WinServices.exe.config"), ("GatewayManager\bin\TG-HPALM-Inbound\AppServiceDefinition.xml"), ("GatewayManager\ProcessPipelines\TG-HPALM-ITR-Inbound\TG-HPALM-ITR-Inbound.config.xml") , ("GatewayManager\bin\TG-HPALM-ITR-Inbound\Accenture.MyWizard.GatewayManager.WinServices.exe.config"), ("GatewayManager\bin\TG-HPALM-ITR-Inbound\AppServiceDefinition.xml"), ("GatewayManager\ProcessPipelines\TG-HPALM-Outbound\TG-HPALM-Outbound.config.xml")

Write-Host
Write-Host 'Creating SMB Share Path on target server' -BackgroundColor Green
Write-Host
Invoke-Command -Session $session -ScriptBlock {
   New-Item "C:\Accenture" -Type Directory -Force -ErrorAction SilentlyContinue | Out-Null
   New-SmbShare -Name "Accenture" -Path "C:\Accenture" -FullAccess "Everyone" -ErrorAction SilentlyContinue -Verbose | Out-Null
   Set-SmbPathAcl -ShareName "Accenture" -ErrorAction SilentlyContinue -Verbose
}

Write-Host 'Copying binaries on target server' -BackgroundColor Green
Write-Host
foreach ($i in $PackagePath) {
    $PackageFolderPath = Get-ChildItem ".\" $i -Recurse | Select-Object FullName
    Copy-Item -Path $PackageFolderPath.FullName  -Destination $SharePath -Force -Recurse | Out-Null
}
Copy-Item -Path $Macrojsonpath -Destination $SharePath -Force -Recurse

Invoke-Command -Session $session -ScriptBlock {
    New-Item $using:TargetPath -Type Directory -Force -ErrorAction SilentlyContinue | Out-Null

    function IISInstallation {
    param()
    process {
        Write-Host
        Write-Host "Checking IIS installation:" -BackgroundColor Green 
        if ((Get-WindowsOptionalFeature -Online -FeatureName "IIS-WebServerRole").State -ne 'Enabled') {
        Write-Host 'Enabling IIS-WebServerRole' -BackgroundColor Green 
        Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole | Out-Null
        } 
        else {
        Write-Host 'IIS-WebServerRole already enabled...' -BackgroundColor Red 
        }

        $FeatureList = 'Web-Net-Ext45' , 'Web-Asp-Net45' , 'Web-ISAPI-Ext' , 'Web-ISAPI-Filter'

        foreach ($Item in $FeatureList) {
        if ((Get-WindowsFeature -Name $Item).InstallState -ne 'Installed') {
            Write-Host 'Adding' $Item -BackgroundColor Green | Out-Null
            Add-WindowsFeature -Name $Item                   
        }
        else {
            Write-Host $Item 'already present' -BackgroundColor Red 
        }
        }

        if ($Type -eq '1') {
        Write-Host 'Extracting binaries for WebAPI minature' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.WebAPI.zip') -DestinationPath ($using:TargetPath + $using:MinatureAPI) -Force
        Write-Host
        Write-Host 'Extracting binaries for TGMSPSOutboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGMSPSOutboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        Write-Host
        }
        elseif ($Type -eq '2') {
        Stop-Service -Name myWizard.GatewayManager.TGHPALMInboundService -ErrorAction SilentlyContinue | out-null
        Stop-Service -Name myWizard.GatewayManager.TGHPALMIterationInboundService  -ErrorAction SilentlyContinue  | out-null

        Write-Host 'Extracting binaries for WebAPI minature' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.WebAPI.zip') -DestinationPath ($using:TargetPath + $using:MinatureAPI) -Force
        Write-Host 'Extracting binaries for TGHPALMInboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGHPALMInboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        Write-Host
        Write-Host 'Extracting binaries for TGHPALMIterationInboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGHPALMIterationInboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        Write-Host
        Write-Host 'Extracting binaries for TGHPALMOutboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.Gatewaymanager.TGHPALMOutboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
     
        }

        elseif ($Type -eq '3') {
        Stop-Service -Name myWizard.GatewayManager.TGHPALMInboundService -ErrorAction SilentlyContinue | out-null
        Stop-Service -Name myWizard.GatewayManager.TGHPALMIterationInboundService  -ErrorAction SilentlyContinue  | out-null

        Write-Host 'Extracting binaries for WebAPI minature' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.WebAPI.zip') -DestinationPath ($using:TargetPath + $using:MinatureAPI) -Force
        Write-Host
        Write-Host 'Extracting binaries for TGMSPSOutboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGMSPSOutboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        Write-Host
        Write-Host 'Extracting binaries for TGHPALMInboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGHPALMInboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        Write-Host
        Write-Host 'Extracting binaries for TGHPALMIterationInboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGHPALMIterationInboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        Write-Host
        Write-Host 'Extracting binaries for TGHPALMOutboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.Gatewaymanager.TGHPALMOutboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
     
        }
        Write-Host
    }
    }

    function CreateWebsite {
    param()
    process { 
        Write-Host
        if ($null -eq (Get-IISAppPool $using:MinatureAPIHost)) {
       
           Write-Host 'Creating AppPool' $using:MinatureAPIHost -BackgroundColor Green 
           $appPool =  New-WebAppPool -Name $using:MinatureAPIHost | Out-Null
        }
        Else {
            Write-Host "App Pool $using:MinatureAPIHost already exists" -BackgroundColor Red 
            
        }
        Write-Host

        if ($null -eq (Get-Website -Name $using:MinatureAPIHost)){
            Write-Host 'Creating Website' $using:MinatureAPIHost -BackgroundColor Green
            New-WebSite -Name $using:MinatureAPIHost -Port $using:MinatureAPIPort -HostHeader $using:MinatureAPIHost -PhysicalPath ($using:TargetPath + $using:MinatureAPIHost) -ApplicationPool $using:MinatureAPIHost -Force | Out-Null 
            #single URL deployment fot multitenant
            if ($using:Version -eq '1') {
                New-WebApplication -Name $using:MinatureAPISubApp -Site $using:MinatureAPI -PhysicalPath ($using:TargetPath + $using:MinatureAPI) -ApplicationPool $using:MinatureAPIHost -force | Out-Null
                write-host ''
                ConvertTo-WebApplication "IIS:\Sites\$using:MinatureAPI" -ApplicationPool $using:MinatureAPIHost -force | Out-Null
            }
        }
        Else {
            Write-Host "Website $using:MinatureAPIHost already exists" -BackgroundColor Red 
        }
        Write-Host
    }
    }

    function ReplaceMacrosTask {
    param(
        [parameter(Mandatory = $true)]
        [string] $configFilePath = '',
        [parameter(Mandatory = $true)]
        $MacroJsonFile,
        [parameter(Mandatory = $true)]
        $AdditionalMacros = ''
       
    )
    process { 
        if ($configFilePath -eq "" -or $JsonTokens -eq "") {
            write-host "All Mandatory parameters were not provided to complete the process."
            return
        }
        if (Test-Path -Path $configFilePath) {
            Set-ItemProperty -path $configFilePath -Name IsReadOnly $false
            Get-ChildItem $configFilePath | Unblock-File
            
            $configFile = Get-Content $configFilePath 
            
            [string[]]$macrosInConfig = (([regex]('{\w+}')).Matches($configFile)) | Select-Object -ExpandProperty Value -Unique
            if ($configFilePath.EndsWith(".js")){
               $macrosInConfig = $macrosInConfig | Where-Object { $_ -ne "{clientName}"}
			   $macrosInConfig = $macrosInConfig | Where-Object { $_ -ne "{Name}"}
            }
            #if ($IsReplaceDefaultMacros -eq "true") {
                Write-Host "Updating macros for : " $configFilePath  -BackgroundColor Green 
                
                $DefaultMacros = Get-Content -Raw -Path $MacroJsonFile | ConvertFrom-Json
                foreach ($macro in $macrosInConfig) {                
                    if ($null -ne $DefaultMacros.PSObject.Properties.Item($macro).Value) {
                        $configFile = $configFile.Replace($macro, $DefaultMacros.PSObject.Properties.Item($macro).Value)
                        Write-Host "Replacing : " $macro  "With : " $DefaultMacros.PSObject.Properties.Item($macro).Value 
                    }
                }
            #}
            if ($AdditionalMacros -ne $null) {
                foreach ($token in $AdditionalMacros.Keys) {
                    Write-Host "Replacing : " $token  "With : " $AdditionalMacros.$token
                    $configFile = $configFile.Replace($token, $AdditionalMacros.$token)
                }
            }
       
            Set-Content $configFilePath $configFile
            Write-Host 'Macros replaced, config file updated and saved'
            Write-Host
        }
        else {
            write-host "Invalid config file, the specified path does not exist." -BackgroundColor Red 
             Write-Host
        } 
    }
}

    function ServiceInstallation {
    param()
    process {
        Write-Host
        If (!(Get-Service 'myWizard.GatewayManager.TGHPALMInboundService' -ErrorAction SilentlyContinue)) {
        Write-Host 'Creating service - myWizard.GatewayManager.TGHPALMInboundService' -BackgroundColor Green 
        New-Service -name 'myWizard.GatewayManager.TGHPALMInboundService' -binaryPathName ($using:TargetPath + 'GatewayManager\bin\TG-HPALM-Inbound\Accenture.MyWizard.GatewayManager.WinServices.exe') -displayName 'myWizard.GatewayManager.TGHPALMInboundService' -startupType Automatic 
        }
        else {
        Write-Host 'Service Already exist - myWizard.GatewayManager.TGHPALMInboundService' -BackgroundColor Red 
        }

        Write-Host
        If (!(Get-Service 'myWizard.GatewayManager.TGHPALMIterationInboundService' -ErrorAction SilentlyContinue)) {
        Write-Host 'Creating service - myWizard.GatewayManager.TGHPALMIterationInboundService' -BackgroundColor Green
        New-Service -name 'myWizard.GatewayManager.TGHPALMIterationInboundService' -binaryPathName ($using:TargetPath + 'GatewayManager\bin\TG-HPALM-ITR-Inbound\Accenture.MyWizard.GatewayManager.WinServices.exe') -displayName 'myWizard.GatewayManager.TGHPALMIterationInboundService' -startupType Automatic
        }
        else {
        Write-Host 'Service Already exist - myWizard.GatewayManager.TGHPALMIterationInboundService' -BackgroundColor Red 
        Write-Host
        }

    }
    }

    IISInstallation

    if ($using:InstallationType -eq '1') {
        Write-Host 'Extracting binaries for WebAPI minature' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.WebAPI.zip') -DestinationPath ($using:TargetPath + $using:MinatureAPI) -Force
        Write-Host
        Write-Host 'Extracting binaries for TGMSPSOutboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGMSPSOutboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        
        CreateWebsite

        foreach ($path in $using:ReplaceMacroPathsMSPS) {
        $configFilePath = $using:TargetPath + $path
        ReplaceMacrosTask -configFilePath $configFilePath -MacroJsonFile "C:\Accenture\myWizard-Installer.macro.tmp" -AdditionalMacros  @(@{'{ApplicationInstallationFolderWin}'=$using:TargetPath},@{'{WebAPIHostName}'=$using:MinatureAPI})
        }
    }
    elseif ($using:InstallationType -eq '2') {
        Stop-Service -Name myWizard.GatewayManager.TGHPALMInboundService -ErrorAction SilentlyContinue | out-null
        Stop-Service -Name myWizard.GatewayManager.TGHPALMIterationInboundService  -ErrorAction SilentlyContinue  | out-null

        Write-Host 'Extracting binaries for WebAPI minature' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.WebAPI.zip') -DestinationPath ($using:TargetPath + $using:MinatureAPI) -Force
        Write-Host
        Write-Host 'Extracting binaries for TGHPALMInboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGHPALMInboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        Write-Host
        Write-Host 'Extracting binaries for TGHPALMIterationInboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGHPALMIterationInboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        Write-Host
        Write-Host 'Extracting binaries for TGHPALMOutboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.Gatewaymanager.TGHPALMOutboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        
        CreateWebsite
        ServiceInstallation

        foreach ($path in $using:ReplaceMacroPathsHPALM) {
        $configFilePath = $using:TargetPath + $path
        ReplaceMacrosTask -configFilePath $configFilePath -MacroJsonFile "C:\Accenture\myWizard-Installer.macro.tmp" -AdditionalMacros  @(@{'{ApplicationInstallationFolderWin}'=$using:TargetPath},@{'{WebAPIHostName}'=$using:MinatureAPI})
        }

        Write-Host
        Write-Host "Restarting Service - myWizard.GatewayManager.TGHPALMInboundService" -BackgroundColor Green
        Restart-Service -Name myWizard.GatewayManager.TGHPALMInboundService -ErrorAction SilentlyContinue | out-null

        Write-Host
        Write-Host "Restarting Service - myWizard.GatewayManager.TGHPALMIterationInboundService" -BackgroundColor Green
        Restart-Service -Name myWizard.GatewayManager.TGHPALMIterationInboundService  -ErrorAction SilentlyContinue  | out-null
        Write-Host
    }
    elseif ($using:InstallationType -eq '3') {
        Stop-Service -Name myWizard.GatewayManager.TGHPALMInboundService -ErrorAction SilentlyContinue | out-null
        Stop-Service -Name myWizard.GatewayManager.TGHPALMIterationInboundService  -ErrorAction SilentlyContinue  | out-null

        Write-Host 'Extracting binaries for WebAPI minature' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.WebAPI.zip') -DestinationPath ($using:TargetPath + $using:MinatureAPI) -Force
        Write-Host
        Write-Host 'Extracting binaries for TGMSPSOutboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGMSPSOutboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        Write-Host
        Write-Host 'Extracting binaries for TGHPALMInboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGHPALMInboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        Write-Host
        Write-Host 'Extracting binaries for TGHPALMIterationInboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.GatewayManager.TGHPALMIterationInboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        Write-Host
        Write-Host 'Extracting binaries for TGHPALMOutboundService' -BackgroundColor Green
        Expand-Archive -LiteralPath ('C:\Accenture\myWizard.Gatewaymanager.TGHPALMOutboundService.zip') -DestinationPath ($using:TargetPath + '\GatewayManager') -Force
        CreateWebsite
        ServiceInstallation

        foreach ($path in $using:ReplaceMacroPathsMSPS) {
        $configFilePath = $using:TargetPath + $path
        ReplaceMacrosTask -configFilePath $configFilePath -MacroJsonFile "C:\Accenture\myWizard-Installer.macro.tmp" -AdditionalMacros  @(@{'{ApplicationInstallationFolderWin}'=$using:TargetPath},@{'{WebAPIHostName}'=$using:MinatureAPI})
        }

        foreach ($path in $using:ReplaceMacroPathsHPALM) {
        $configFilePath = $using:TargetPath + $path
        ReplaceMacrosTask -configFilePath $configFilePath -MacroJsonFile "C:\Accenture\myWizard-Installer.macro.tmp" -AdditionalMacros  @(@{'{ApplicationInstallationFolderWin}'=$using:TargetPath},@{'{WebAPIHostName}'=$using:MinatureAPI})
        }

        Write-Host
        Write-Host "Restarting Service - myWizard.GatewayManager.TGHPALMInboundService" -BackgroundColor Green
        Restart-Service -Name myWizard.GatewayManager.TGHPALMInboundService -ErrorAction SilentlyContinue | out-null

        Write-Host
        Write-Host "Restarting Service - myWizard.GatewayManager.TGHPALMIterationInboundService" -BackgroundColor Green
        Restart-Service -Name myWizard.GatewayManager.TGHPALMIterationInboundService  -ErrorAction SilentlyContinue  | out-null
        Write-Host
    }

    Write-Host "Restarting IIS" -BackgroundColor Green
    iisreset | out-null

   

    Write-Host
    Write-Host "Adding MSPS instance Ip and Hostname in hosts file - C:\Windows\System32\drivers\etc\hosts" -BackgroundColor Green
    If ((Get-Content "$($env:windir)\system32\Drivers\etc\hosts" ) -notcontains $using:HostEntry)   
       {ac -Encoding UTF8  "$($env:windir)\system32\Drivers\etc\hosts" $using:HostEntry }
    Write-Host
}

Stop-Transcript




