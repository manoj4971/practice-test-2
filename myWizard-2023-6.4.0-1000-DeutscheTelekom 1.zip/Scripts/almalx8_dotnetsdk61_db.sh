#!/bin/bash

echo "*********Installing dotnet core runtime 6.0*********"
sudo wget https://download.visualstudio.microsoft.com/download/pr/62181759-93ce-4512-8de1-92de74a6ba3f/f83ea41c3161f301d3584598f9c31801/dotnet-sdk-6.0.412-linux-x64.tar.gz
sudo mkdir -p /usr/share/dotnet/ && tar zxf dotnet-sdk-6.0.412-linux-x64.tar.gz -C /usr/share/dotnet/
cat >> /etc/profile.d/env.sh << EOL
export PATH=/usr/share/dotnet:$PATH
EOL
source /root/.bashrc
source /root/.bash_profile
source /etc/environment
sudo ln -s /usr/share/dotnet/dotnet /usr/bin/dotnet