#######Install JRE11.0.5
echo "*********Installing JRE11*********"
sudo yum -y install java-11-openjdk-devel



#######Install tomcat
echo "*********Installing tomcat9*********"
cd /mnt/win/OneClickTools/Softwares/zip
adduser -m -U -d /etc/tomcat9 -s /bin/false tomcat;
sudo mkdir -p /etc/tomcat9;
tar -xvf apache-tomcat-v9.0.45.tar.gz
cd apache-tomcat-v9.0.45
mv * /etc/tomcat9/
sudo ln -s /etc/tomcat9/ /etc/tomcat9/latest
#sudo chown -R tomcat: /etc/tomcat9
sudo chmod +x /etc/tomcat9/bin/*.sh;
chown -R tomcat:tomcat /etc/tomcat9
rm -f /etc/systemd/system/tomcat.service
cat >> /etc/systemd/system/tomcat.service << EOL
[Unit]
Description=Tomcat 9 servlet container
After=network.target



[Service]
Type=forking



User=tomcat
Group=tomcat



Environment="JAVA_HOME=/usr/lib/jvm/jre"
Environment="JAVA_OPTS=-Djava.security.egd=file:///dev/urandom%22



Environment="CATALINA_BASE=/etc/tomcat9"
Environment="CATALINA_HOME=/etc/tomcat9"
Environment="CATALINA_PID=/etc/tomcat9/temp/tomcat.pid"
Environment="CATALINA_OPTS=-Xms512M -Xmx4096M -server -XX:+UseParallelGC"



ExecStart=/etc/tomcat9/bin/startup.sh
ExecStop=/bin/kill -15 $MAINPID



[Install]
WantedBy=multi-user.target



EOL

cd /mnt/win/OneClickTools/Softwares/zip/jar_files.zip
yum -y install unzip
unzip jar_files.zip -d /etc/tomcat9/lib/
chown -R tomcat:tomcat /etc/tomcat9/
sudo systemctl daemon-reload
sudo systemctl enable tomcat
sudo systemctl start tomcat
sudo systemctl status tomcat
echo export CATALINA_HOME=/etc/tomcat9 >> /etc/bashrc
source /etc/bashrc
