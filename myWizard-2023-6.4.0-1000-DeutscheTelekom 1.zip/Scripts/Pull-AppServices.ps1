﻿param(
    [ValidateSet("S3", "Server")]
    [Parameter(Mandatory = $true)]
    $from = "",

    [Parameter(Mandatory = $true)]
    $accessKey = "",
 
    [Parameter(Mandatory = $true)]   
    $secretKey = "",
 
    [Parameter(Mandatory = $true)]    
    $folderName = ""
)

function Init{
begin {
    Clear-Host
}
process {
    if ($from -eq "S3") {
        Install-PSModules
        $sourcePath = "mywizard_OneClickInstaller/" + $folderName
        $keys = Get-S3Object -BucketName mywizard-oneclick-bucket  -KeyPrefix $sourcePath -AccessKey $accessKey -SecretKey $secretKey -Region us-east-1
        foreach ($key in $keys) {
            $info = $key.key -split '/'
            $appName = $info[3]
            $release = $info[4]
            $localFileName = $info[5]
            $destinationPath = "..\AppServices\" + $appName + "\" + $release + "\"
            if ($nul -ne $localFileName) {
                Write-Host $localFileName -BackgroundColor DarkCyan -ForegroundColor Yellow
                $destination = Join-Path $destinationPath $localFileName
                Copy-S3Object -BucketName mywizard-oneclick-bucket -Key $key.Key -LocalFile $destination -AccessKey $accessKey -SecretKey $secretKey -Region us-east-1 | Out-Null
            }
        }
    }
    elseif ($from -eq "Server") {
        $source = "\\10.156.5.76\d$\" + $folderName
        $bundles = Get-ChildItem $source -Force
    
        foreach ($bundle in $bundles) {
            $apps = Get-ChildItem $bundle.FullName
            foreach ($app in $apps) {
                Write-Host $app.Name -BackgroundColor DarkCyan -ForegroundColor Yellow
                Copy-Item -Path $app.FullName -Destination "..\AppServices\" -Force -Recurse
            }
        }
    }
    
}
end {
    Write-Host
    Write-Host "Downloading completed (Please press enter to exit)" -BackgroundColor Yellow -ForegroundColor Black
    Read-Host
}

}

function Install-PSModules {
    process {
            Write-Host "Checking required modules, Please wait..."
            $psModules = Get-Module -ListAvailable | Select-Object -Property Name, Version
            if ($null -eq ($psModules | Where-Object { $_.Name -match "AWSPowerShell" })) {
                Write-Host "Installing AWSPowerShell module"
                Install-Module AWSPowerShell
            }
    }
    end {
        Clear-Host
    }
}

Init