#!/bin/bash
#######Install rabbitmq
pwsh /mnt/win/OneClickTools/wget-files.ps1 -url "https://github.com/rabbitmq/rabbitmq-server/releases/download/v3.8.16/rabbitmq-server-3.8.16-1.el7.noarch.rpm"
yum -y install socat
#sudo rpm -ivh rabbitmq-server-3.8.16-1.el7.noarch.rpm
sudo rpm -Uvh rabbitmq-server-3.8.16-1.el7.noarch.rpm
sudo firewall-cmd --zone=public --permanent --add-port=4369/tcp --add-port=25672/tcp --add-port=5671-5672/tcp --add-port=15672/tcp  --add-port=61613-61614/tcp --add-port=1883/tcp --add-port=8883/tcp
sudo firewall-cmd --reload
sudo systemctl enable rabbitmq-server.service
sudo rabbitmq-plugins enable rabbitmq_management
sudo chown -R rabbitmq:rabbitmq /var/lib/rabbitmq/
sudo systemctl start rabbitmq-server.service
sudo systemctl status rabbitmq-server.service