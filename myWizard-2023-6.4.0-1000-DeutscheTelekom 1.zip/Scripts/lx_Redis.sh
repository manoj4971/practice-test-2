#!/bin/sh
yum -y install yum-utils
#yum --enablerepo=remi install redis -y
yum -y install redis
rpm -qi redis
systemctl enable --now redis
IP=$(hostname -I|cut -d" " -f 1)
sed -i 's|# maxmemory <bytes>|maxmemory 1g|g'  /etc/redis.conf
sed -i 's|# maxmemory-policy noeviction|maxmemory-policy allkeys-lru|g' /etc/redis.conf
sed -i "s|bind 127.0.0.1|bind 127.0.0.1 $IP|g" /etc/redis.conf
systemctl restart redis

