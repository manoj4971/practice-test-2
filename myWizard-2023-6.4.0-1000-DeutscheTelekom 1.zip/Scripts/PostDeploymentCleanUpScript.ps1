﻿param (
    $Path = ""
)
begin {
    Clear-Host
}
process{
    Remove-Item -Path $($Path + "\AppServices") -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
    (Get-ChildItem -File -Filter "*.bdef*" -Path $Path).FullName | Remove-Item -Force -ErrorAction SilentlyContinue | Out-Null
    (Get-ChildItem -File -Filter "*macro.tmp*" -Path $Path).FullName | Remove-Item -Force -ErrorAction SilentlyContinue | Out-Null
}