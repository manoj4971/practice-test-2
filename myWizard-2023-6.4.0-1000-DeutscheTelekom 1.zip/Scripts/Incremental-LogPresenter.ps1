﻿param (
    $nodeName = ""
)
begin {
    Clear-Host
    $logPath = "/var/www/Logs/IncrementalScripts"
    $files = (Get-ChildItem -Path $logPath -Filter "*.log")
    $data = @()
}
process {
    foreach ($file in $files) {
        $log = Get-Content -Raw -Path $file.FullName
        $log = $log.Substring($log.IndexOf("Executing Incremental Scripts")).Trim()

        $count = ($log | Select-String -Pattern "Script execution completed" -AllMatches).Matches.Count


        for($i = 1; $i -le $count; $i += 1) {
    
            $start = $log.IndexOf("Executing Incremental Scripts for")
            $end = $log.IndexOf("Script execution completed") + ("Script execution completed").Length - $start
            
            $portion = $log.Substring($start,$end)
        
            if($portion.Contains("[js] uncaught exception") -or $portion.Contains("[js] Error: couldn't connect to server")) {
                $data += select @{n="ID";e={$i}}, @{n="LogFile";e={$file.Name}}, @{n="Script";e={(Split-Path -Path ($portion -split "\n")[0] -Leaf)}}, @{n="Status";e={"Failed"}} -InputObject ''
            }
            else {
                $data += select @{n="ID";e={$i}}, @{n="LogFile";e={$file.Name}}, @{n="Script";e={(Split-Path -Path ($portion -split "\n")[0] -Leaf)}}, @{n="Status";e={"Passed"}} -InputObject ''
            }

            $log = $log.Substring($log.IndexOf("Script execution completed") + ("Script execution completed").Length).Trim()

        }
    }
    
    #$data
    $html = ""
    
    $logFiles = $data | Select-Object -ExpandProperty LogFile -Unique

    foreach($lf in $logFiles) {
        $html += $("<tr><td colspan='3' style='background: silver;border: 1px solid silver;padding: 5px;'>"+$lf+"</td></tr>")
        $scriptFiles = $data | Where-Object {$_.LogFile -eq $lf}

        foreach($sf in $scriptFiles) {
            if($sf.Status -eq "Passed") {$color = "#90ee90"} else {$color = "#ff5d5d"}
            $html += $("<tr><td style='border: 1px solid silver;padding: 5px;'>"+$sf.ID+"</td><td style='border: 1px solid silver;padding: 5px;'>"+$sf.Script+"</td><td style='border: 1px solid silver;padding: 5px;background: "+ $color +";'>"+$sf.Status+"</td></tr>")
        }
        $html += $("<tr><td colspan='3'>&nbsp;</td></tr>")
    }

    $html = $("<table style='border: 1px solid silver;margin: auto auto;border-collapse: collapse;'>" + $html + "</table>")

    $html | Set-Content -Path $("/mnt/win/OneClickTools/Logs/incremental-db-scripts_"+$nodeName+".html")
}