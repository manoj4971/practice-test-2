#!/bin/bash
#######Install googlechrome
pwsh /mnt/win/OneClickTools/wget-files.ps1 -url "https://dl.google.com/linux/direct/google-chrome-stable_current_x86_64.rpm"
sudo yum install ./google-chrome-stable_current_*.rpm -y
