﻿param (
    [Parameter(Mandatory = $true)]
    [string]$ConfigFile = "",
	
    [Parameter(Mandatory = $true)]
    [string] $MacroJsonFile = "",
    
    [Parameter(Mandatory = $true)]
    [string] $AESKey = "",

    [Parameter(Mandatory = $true)]
    [string] $VectorKey = ""
)


#REGION reusuable dsc configurations
configuration ReplaceMacrosTasks {
    param (
        $currentItem
    )

    $configFiles = $currentItem.ReplaceMacrosTasks
    $Name = $(";appName="+$currentItem.Name)
    $Nameand = $("&appName="+$currentItem.Name)
    $macroPath = $($Global:Environment.SMBSharePath + "\" + (Split-Path -Path $MacroJsonFile -Leaf))
    $Password = $Global:Environment.DBAdminPassword
    $cryptoSourcePath = $($Global:Environment.SMBSharePath + "\" + "Scripts\Common\Cryptography.ps1")
    $cryptoDestinationPath = $($Global:Environment.ApplicationInstallationFolder + "\CustomScripts\Cryptography.ps1")
    Script "ReplaceMacrosTasks" {
        SetScript = {
        if(-not (Test-Path -Path $using:cryptoDestinationPath)){
         New-Item -Path $(split-path -path $using:cryptoDestinationPath -Parent) -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
         Copy-Item -Path $using:cryptoSourcePath -Destination $using:cryptoDestinationPath -Force
        }
        $ociMacros = Get-Content -Raw -Path $using:macroPath
        $ArgumentList = " -Action Decrypt -KeyValue " + $using:AESKey + " -VectorValue " + $using:VectorKey + " -text " + $ociMacros
        $ociMacros = Invoke-Expression "$using:cryptoDestinationPath $ArgumentList" 
        if(Test-Path -Path $using:cryptoDestinationPath){
         Remove-Item -Path  $(split-path -path $using:cryptoDestinationPath -Parent) -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
        }
        #$ociMacros = .\Scripts\Common\Cryptography.ps1 -Action Decrypt -KeyValue $AESKey -VectorValue $VectorKey -text $ociMacros
        $ociMacros = $ociMacros | ConvertFrom-Json


            foreach($file in $using:configFiles) {
            
                if(Test-Path -Path $file) {
                    
                    Write-Host $("Running ReplaceMacrosTasks for " + $file)

                    $configContent = Get-Content -Raw -path $file
                    [string[]]$macrosInConfig = (([regex]('{\w+}')).Matches($configContent)) | Select-Object -ExpandProperty Value -Unique


                    if ($file.EndsWith(".js")){
                            $macrosInConfig = $macrosInConfig | Where-Object { $_ -ne "{clientName}"}
                            $macrosInConfig = $macrosInConfig | Where-Object { $_ -ne "{Name}"}
                    }

                    foreach ($macro in $macrosInConfig) {
                        
                        if ($null -ne $ociMacros.PSObject.Properties.Item($macro).Value) {
                        $value = $ociMacros.PSObject.Properties.Item($macro).Value
                            if(($macro -match "DBQueryConnectionString") -or ($macro -match "DBCommandConnectionString"))
                    {
                     if($value.Contains("&ssl=true")) {
                        $value = $value + $Nameand}
                        else {
                        $value =$value + $Name}
                    }
                    
                    if($macro -match "DBAdminAccountPassword"){
                        $value = $Password
                    }
                            $configContent = $configContent.Replace($macro, $value)
                            Write-Host "Replacing : " $macro
                            Write-Host "With : " $value   

                        }
                    }#inner foreach for macros in file
                    Set-Content $file $configContent

                }#test path for config files
            
            }#outer foreach for config files

        }#setscript ends

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }
    }#dsc script block ends

}
configuration ReplaceMacrosTaskInFolders {
    param (
        $currentItem
    )

    $macroPath = $($Global:Environment.SMBSharePath + "\" + (Split-Path -Path $MacroJsonFile -Leaf))
    $Name = $(";appName="+$currentItem.Name)
    $Nameand = $("&appName="+$currentItem.Name)
    $Password = $Global:Environment.DBAdminPassword
    $cryptoSourcePath = $($Global:Environment.SMBSharePath + "\" + "Scripts\Common\Cryptography.ps1")
    $cryptoDestinationPath = $($Global:Environment.ApplicationInstallationFolder + "\CustomScripts\Cryptography.ps1")
    Script "ReplaceMacrosTasks" {
        SetScript = {
        if(-not (Test-Path -Path $using:cryptoDestinationPath)){
         New-Item -Path $(split-path -path $using:cryptoDestinationPath -Parent) -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
         Copy-Item -Path $using:cryptoSourcePath -Destination $using:cryptoDestinationPath -Force
        }
        $ociMacros = Get-Content -Raw -Path $using:macroPath
        $ArgumentList = " -Action Decrypt -KeyValue " + $using:AESKey + " -VectorValue " + $using:VectorKey + " -text " + $ociMacros
        $ociMacros = Invoke-Expression "$using:cryptoDestinationPath $ArgumentList" 
        if(Test-Path -Path $using:cryptoDestinationPath){
         Remove-Item -Path  $(split-path -path $using:cryptoDestinationPath -Parent) -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
        }
        #$ociMacros = .\Scripts\Common\Cryptography.ps1 -Action Decrypt -KeyValue $AESKey -VectorValue $VectorKey -text $ociMacros
        $ociMacros = $ociMacros | ConvertFrom-Json
            $configFiles = (Get-childitem -Path $using:currentItem).FullName
            foreach($file in $using:configFiles) {
            
                if(Test-Path -Path $file) {
                    
                    Write-Host $("Running ReplaceMacrosTasks for " + $file)

                    $configContent = Get-Content -Raw -path $file
                    [string[]]$macrosInConfig = (([regex]('{\w+}')).Matches($configContent)) | Select-Object -ExpandProperty Value -Unique


                    if ($file.EndsWith(".js")){
                            $macrosInConfig = $macrosInConfig | Where-Object { $_ -ne "{clientName}"}
                            $macrosInConfig = $macrosInConfig | Where-Object { $_ -ne "{Name}"}
                    }

                    foreach ($macro in $macrosInConfig) {
                        
                        if ($null -ne $ociMacros.PSObject.Properties.Item($macro).Value) {

                            $value = $ociMacros.PSObject.Properties.Item($macro).Value
                            if(($macro -match "DBQueryConnectionString") -or ($macro -match "DBCommandConnectionString"))
                    {
                     if($value.Contains("&ssl=true")) {
                        $value =$value + $Nameand}
                        else {
                        $value =$value + $Name}
                    }
                    
                    if($macro -match "DBAdminAccountPassword"){
                        $value = $Password
                    }
                            $configContent = $configContent.Replace($macro, $value)
                            Write-Host "Replacing : " $macro
                            Write-Host "With : " $value   

                        }
                    }#inner foreach for macros in file
                    Set-Content $file $configContent

                }#test path for config files
            
            }#outer foreach for config files

        }#setscript ends

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }
    }#dsc script block ends

}
configuration PostDeploymentScripts {
    param (
        $currentItem
    )

    [string[]]$scriptFiles = $currentItem.PostDeploymentScript | Where-Object {$_.ToLower().EndsWith(".bat")}

    Script "PostDeploymentScripts" {
        SetScript = {
            foreach($file in $using:scriptFiles) {

                if(Test-Path -Path $file) {
                    Set-Location -Path "\"
                    Set-Location -Path $(Split-Path -Path $file -Parent)
                    $file = $file.Replace("/","\\")
                    &$file
                }
            }
        }

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }
    }#dsc Script block
}
configuration StartService {
    param
    (
        $serviceName
    )

    Script "StartService" {
        SetScript = {
            Set-Service -Name $using:serviceName -StartupType Automatic -ErrorAction SilentlyContinue | Out-Null
            Start-Service -Name $using:serviceName -ErrorAction SilentlyContinue | Out-Null
        }

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }
    }#dsc Script block
}
configuration StopService {
    param
    (
        $serviceName
    )

    Script "StartService" {
        SetScript = {
            Stop-Service -Name $using:serviceName -ErrorAction SilentlyContinue | Out-Null
        }

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }
    }#dsc Script block
}
configuration BackupApps {
    param (
        $appPath
    )
    $ApplicationInstallationFolder = $Global:Environment.ApplicationInstallationFolder

    Script "Backup" {
        SetScript = {
            $source = $using:appPath
            $backupPath = "D:\mywizard-backup"
            $Days = "2"
            $CurrentDate = (Get-Date -Format yyyyMMdd)    
            New-Item -ItemType Directory -Force -Path $backupPath -ErrorAction SilentlyContinue | Out-Null

            Get-ChildItem $backupPath  | ForEach-Object { 
                                    $folderName = $_.Name
                                    $fullPath = $_.FullName
                                    $date = $folderName.Split("_")
                                    $diff = $CurrentDate - $date[1]
                                    If ($diff -gt $Days) {
                                        Write-Host "Remove-Item -Path $fullPath -Force -Recurse"
                                        Remove-Item -Path $fullPath -Force -Recurse
                                    }
                                } #foreach-object ends here

            if (Test-Path -Path $source) {
                $backupFolderName = (Get-Date -Format "yyyyMMdd.hhmmss")
               
                $backupPath = $source.Replace($using:ApplicationInstallationFolder, $backupPath)

                if ( -Not ($source -like "*GatewayManager*")) {

                    $backupName = $backupPath + "_" + $backupFolderName
                    Move-Item $source -Destination $backupName -Force

                } #gm if ends
                else {
                    $AppPathProcessPipeline = $source.Replace("bin","ProcessPipelines")
                    $backupNameBin = $backupPath.Replace("GatewayManager",$("GatewayManager_" + $backupFolderName))

                    if (-Not (Test-Path -Path $backupNameBin)) {
                        Move-Item $source -Destination $backupNameBin -Force
                        Get-ChildItem $AppPathProcessPipeline -Recurse | 
                                Where-Object { 
                                    $_ -notmatch "ProcessLogs" -and 
                                    $_ -notmatch "Instances" 
                                } | 
                                ForEach-Object { 
                                    Move-Item -Path $_.FullName -Destination $_.FullName.Replace($using:ApplicationInstallationFolder, $backupPath).Replace("GatewayManager","GatewayManager_" + $backupFolderName + "")
                                }
                    }#test-path of gm bin folder ends

                } #gm else ends
            }#if test-path ends


        }#setscript ends

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }
    }#dsc script block ends

}
#ENDREGION



configuration CreateEnvVariables {
    param (
        $Node
    )
    Import-DscResource -Module xWebAdministration,  xPSDesiredStateConfiguration, xNetworking
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    Script "CreateEnvVariables" {
        SetScript = {
            [System.Environment]::SetEnvironmentVariable("JAVA_HOME", "C:\Program Files\Java\jdk-11.0.6; C:\Program Files\Java\jdk-11.0.6\bin", [System.EnvironmentVariableTarget]::Machine)
            [System.Environment]::SetEnvironmentVariable("JAVA_HOME", "C:\Program Files\Java\jdk-11.0.6; C:\Program Files\Java\jdk-11.0.6\bin", [System.EnvironmentVariableTarget]::Process)
            [System.Environment]::SetEnvironmentVariable("JAVA_HOME", "C:\Program Files\Java\jdk-11.0.6; C:\Program Files\Java\jdk-11.0.6\bin", [System.EnvironmentVariableTarget]::User)

            [System.Environment]::SetEnvironmentVariable("CATALINA_HOME", "C:\Program Files\tomcat9", [System.EnvironmentVariableTarget]::Machine)
            [System.Environment]::SetEnvironmentVariable("CATALINA_HOME", "C:\Program Files\tomcat9", [System.EnvironmentVariableTarget]::Process)
            [System.Environment]::SetEnvironmentVariable("CATALINA_HOME", "C:\Program Files\tomcat9", [System.EnvironmentVariableTarget]::User)

            #[System.Environment]::SetEnvironmentVariable("JRE_HOME", "C:\Program Files\Java\jre-10.0.2", [System.EnvironmentVariableTarget]::Machine)
            #[System.Environment]::SetEnvironmentVariable("JRE_HOME", "C:\Program Files\Java\jre-10.0.2", [System.EnvironmentVariableTarget]::Process)
            #[System.Environment]::SetEnvironmentVariable("JRE_HOME", "C:\Program Files\Java\jre-10.0.2", [System.EnvironmentVariableTarget]::User)
        }

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }

        Credential = $Node.ServerCredentials
    }#dsc Script block
}

configuration CreateSharedPath {
    param (
        $Node
    )
    Import-DscResource -Module xWebAdministration,  xPSDesiredStateConfiguration, xNetworking
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    $sharedPath = $($Global:Environment.ApplicationInstallationFolder + "\Shared")

    Script "CreateSMBShare" {
        SetScript = {
            New-Item -ItemType Directory -Path $using:sharedPath -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\DataLoader_DownloadTemplate") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\DataLoader_FileUpload") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\DeliveryPlanInbound") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\DeliveryPlanOutbound") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GatewayManager") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GatewayManager\OutboundMessages") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GatewayManager\ProcessPipelines") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadAPI") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadAPI\Error") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadAPI\New") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadAPI\Processed") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadGM") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadGM\Error") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadGM\New") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadGM\Processed") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadUI") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadUI\Error") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadUI\New") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadUI\Processed") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\GenericUploadUI\Log") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\Temp") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\Template") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\GenericUpload\TempZip") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\ICM_Shared") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\IngrAIn_Shared") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\myWizard.InsightfulTestPatternMining") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\myWizard.PatternMiningSAP") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\myWizard.PatternMiningSAP\Upload") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\om") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\ProjectInitiation_Shared") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\ReportAutomation_Shared") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\resourcedata") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\TestOptimizer") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\TestOptimizer\om") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\ToolGateway") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\ToolGateway\ProcessPipelines") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\BulkUploadTemporary") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\BulkUploadReportPath") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\BulkUploadTemplatePath") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\BulkUploadArtifactPath") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\IAOfflineFiles2.1") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\IAOfflineFiles2.1\Temp") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\IAOfflineFiles2.1\Temp\CustomHierarchy") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\IAOfflineFiles2.1\Temp\IndustryUpload") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\IAOfflineFiles2.1\CustomHierarchy") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\IAOfflineFiles2.1\ServiceReports") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-Item -Path $($using:sharedPath + "\apps\myWizard-phoenix\IAOfflineFiles2.1\Templates") -ItemType "directory" -Force -ErrorAction SilentlyContinue | Out-Null
            New-SmbShare -Name "Shared" -Path $using:sharedPath -FullAccess "Everyone" -ErrorAction SilentlyContinue -Verbose
            Set-SmbPathAcl -ShareName "Shared" -ErrorAction SilentlyContinue -Verbose
        }

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }

        Credential = $Node.ServerCredentials
    }#dsc Script block
}

configuration DeployWebSites {
    param (
        $Resources,
        $Node
    )
    
    Import-DscResource -Module xWebAdministration,  xPSDesiredStateConfiguration, xNetworking
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    #$webSites = $Resources | Select-Object @{ n="WebSiteName";e={(Split-Path -Path $_.WebSiteName -Parent)}}, @{n="WebSitePort";e={$_.WebSitePort }} -Unique | Where-Object WebSiteName -ne ""

    $websites = $Resources | Select-Object @{n="WebSiteName";e={(Split-Path -Path $_.WebSiteName -Parent)}}, 
                                           @{n="WebSitePort";e={ 
                                                                if($_.WebSiteName -match "api") {
                                                                    "8001"
                                                                } 
                                                                elseif ($_.WebSiteName -match "fortress"){
                                                                    "8003"
                                                                } 
                                                                else {
                                                                    "8002"
                                                                }}
                                                               } -Unique | Where-Object WebSiteName -ne ""

    foreach($webSite in $webSites)
    {
        xWebAppPool $webSite.WebSiteName {
            Name                           = $webSite.WebSiteName
            Ensure                         = 'Present'
            State                          = 'Started'
            autoStart                      = $true
            managedPipelineMode            = 'Integrated'
            managedRuntimeVersion          = 'v4.0'
            identityType                   = 'ApplicationPoolIdentity'
            loadUserProfile                = $true
        }

        xWebsite $webSite.WebSiteName {
            Ensure          = 'Present'
            Name            = $webSite.WebSiteName
            State           = 'Started'
            ApplicationPool = $webSite.WebSiteName
            BindingInfo     =  MSFT_xWebBindingInformation  {
                Protocol              = 'http'
                Port                  = $webSite.WebSitePort
                HostName              = $webSite.WebSiteName
            }
        } 
    }

    foreach ($item in $Resources)
    {
        $source = Get-Location -target Source -currentItem $item
        $destination = Get-Location -target Destination -currentItem $item -destinationField "WebSitePath"
            

        if(-not (Test-Path -Path $source))
        {
            Write-Host "Zip package not present for" $item.Name -BackgroundColor Red
        }
        else
        {
            Write-Host $item.Name -BackgroundColor green
            $parentSite = (Split-Path -Path $item.WebSiteHostName -Parent)
            if($parentSite -eq "") {
                $parentSite = (Split-Path -Path $item.WebSiteHostName -Leaf)
            }
            $childSite = (Split-Path -Path $item.WebSiteHostName -Leaf)

            File $item.Name {
                DestinationPath = $destination
                Ensure = 'Present'
                Type = 'Directory'
                Force = $true
                Checksum = 'ModifiedDate'
                Credential = $Node.ServerCredentials
            }


            BackupApps $item.Name {
                appPath = $destination
            }

            Archive $item.Name {
                Path = $source
                Destination = $destination
                Force = $true
                Ensure = 'Present'
                Checksum = 'ModifiedDate'
                Validate = $true
                Credential = $Node.ServerCredentials
            }

            xWebAppPool $item.Name {
                Name                           = $item.Name
                Ensure                         = 'Present'
                State                          = 'Started'
                autoStart                      = $true
                #enable32BitAppOnWin64          = $false
                #enableConfigurationOverride    = $true
                managedPipelineMode            = 'Integrated'
                managedRuntimeVersion          = 'v4.0'
                #passAnonymousToken             = $true
                #startMode                      = 'OnDemand'
                identityType                   = 'ApplicationPoolIdentity'
                loadUserProfile                = $true
            }

            #if not a parent-child site
            if($parentSite -eq $childSite) {
                #base website
                xWebsite $item.Name {
                    Ensure          = 'Present'
                    Name            = $parentSite
                    State           = 'Started'
                    ApplicationPool = $item.Name
                    PhysicalPath = $destination
                    BindingInfo     =  MSFT_xWebBindingInformation  {
                        Protocol              = 'http'
                        Port                  = $item.WebSitePort
                        HostName              = $parentSite
                    }
                }
            }
            else {
                xWebApplication $item.Name {
                    Name = $childSite
                    WebAppPool = $item.Name
                    PhysicalPath = $destination
                    Ensure = 'Present'
                    PreloadEnabled = $false
                    ServiceAutoStartEnabled = $true
                    Website = $parentSite
                }
            }


            ReplaceMacrosTasks $item.Name {
                currentItem = $item
            }

        }
    }

    Script "IISReset" {
        SetScript = {
            Invoke-Expression -Command "&iisreset" -Verbose
        }

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }
    }#dsc Script block
}

configuration DeployWindowsServices {
    param (
        $Resources,
        $Node
    )

    Import-DscResource -Module xWebAdministration,  xPSDesiredStateConfiguration, xNetworking
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    foreach ($item in $Resources)
    {
        $source = Get-Location -target Source -currentItem $item
        $destination = Get-Location -target Destination -currentItem $item -destinationField "ServicePath"

        if(-not (Test-Path -Path $source))
        {
            Write-Host "Zip package not present for" $item.Name -BackgroundColor Red
        }
        else
        {
            write-host $item.Name -BackgroundColor green

            StopService $item.Name {
                serviceName = $item.Name
            }

            File $item.Name {
                DestinationPath = $destination
                Ensure = 'Present'
                Type = 'Directory'
                Force = $true
                Checksum = 'ModifiedDate'
                Credential = $Node.ServerCredentials
            }

            BackupApps $item.Name {
                appPath = $destination
            }

            Archive $item.Name {
                Path = $source
                Destination = $destination
                Force = $true
                Ensure = 'Present'
                Checksum = 'ModifiedDate'
                Validate = $true
                Credential = $Node.ServerCredentials
            }

            ReplaceMacrosTasks $item.Name {
                currentItem = $item
            }

            xService $item.Name {
                Name        = $item.Name
                Description = $item.Name
                DisplayName = $item.Name
                Path        = $item.Path
                StartupType = $item.StartupType
                Ensure      = 'Present'
                State       = $item.State
            }

            StartService $item.Name {
                serviceName = $item.Name
            }
        }
    }
}

configuration DeployTomcat {
    param (
        $Resources,
        $Node
    )

    Import-DscResource -Module xWebAdministration,  xPSDesiredStateConfiguration, xNetworking
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    $importJavaCert1 = "&""C:\Program Files\Java\jdk-11.0.6\bin\keytool.exe"" -importcert -file ""D:\mongo\server\CA.crt"" -keystore ""C:\Program Files\Java\jdk-11.0.6\lib\security\cacerts"" -storepass changeit -alias caroot"
    $importJavaCert2 = "&""C:\Program Files\Java\jdk-11.0.6\bin\keytool.exe"" -v -importkeystore -srckeystore ""D:\mongo\server\clientjava.pfx"" -srcstorepass changeit -srcstoretype PKCS12 -destkeystore ""C:\Program Files\Java\jdk-11.0.6\lib\security\cacerts"" -deststoretype JKS -destkeypass changeit"

    foreach ($item in $Resources)
    {
        $source = Get-Location -target Source -currentItem $item
        $destination = $($Global:Environment.ApplicationInstallationFolder + "\TomcatApps\" + $item.Name)
        $catalinaProperties = "C:\Program Files\tomcat9\conf\catalina.properties"

        if(-not (Test-Path -Path $source))
        {
            Write-Host "Zip package not present for" $item.Name -BackgroundColor Red
        }
        else
        {
            Write-Host $item.Name -BackgroundColor green

            File $item.Name {
                DestinationPath = $destination
                Ensure = 'Present'
                Type = 'Directory'
                Force = $true
                Checksum = 'ModifiedDate'
                Credential = $Node.ServerCredentials
            }

            Archive $item.Name {
                Path = $source
                Destination = $destination
                Force = $true
                Ensure = 'Present'
                Checksum = 'ModifiedDate'
                Validate = $true
                Credential = $Node.ServerCredentials
            }

            Script $item.Name {
                SetScript = {
                    Move-Item -Path $($using:destination + "\" + (Split-Path -Path $using:item.WarFilePath -Leaf)) -Destination $using:item.WarFilePath -Force -Verbose
                    New-Item -ItemType Directory -Force -ErrorAction SilentlyContinue -Path $(Split-Path -Path $using:item.PropertyFilePath -Parent) | Out-Null
                    Move-Item -Path $($using:destination + "\*") -Destination $(Split-Path -Path $using:item.PropertyFilePath -Parent) -Force -Verbose
                }

                GetScript = {
                    return $true
                }

                TestScript = {
                    return $false
                }
            }#dsc Script block

            ReplaceMacrosTasks $item.Name {
                currentItem = $item
            }
        }
    }


    Script "AddCatalina" {
        SetScript = {
        if(-not(Select-String -Path $using:catalinaProperties -Pattern "javax.net.ssl.trustStore=C:\\Program Files\\Java\\jdk-11.0.6\\lib\\security\\cacerts" -SimpleMatch -Quiet)) {
                Add-Content -Path $using:catalinaProperties -Value "javax.net.ssl.trustStore=C:\\Program Files\\Java\\jdk-11.0.6\\lib\\security\\cacerts"
                Add-Content -Path $using:catalinaProperties -Value "javax.net.ssl.trustStorePassword=changeit"
                Add-Content -Path $using:catalinaProperties -Value "javax.net.ssl.keyStore=C:\\Program Files\\Java\\jdk-11.0.6\\lib\\security\\cacerts"
                Add-Content -Path $using:catalinaProperties -Value "javax.net.ssl.keyStorePassword=changeit"
                Add-Content -Path $using:catalinaProperties -Value "irp.log.path=D:\\myWizard\\Logs\\irp\\"
                Add-Content -Path $using:catalinaProperties -Value "rra.log.path=D:\\myWizard\\Logs\\rra\\"
                Add-Content -Path $using:catalinaProperties -Value "irp.properties.file.path=C:\\Program Files\\tomcat9\\conf\\IntelligentReleasePlanner\\application.properties"
                Add-Content -Path $using:catalinaProperties -Value "rra.properties.file.path=C:\\Program Files\\tomcat9\\conf\\RequirementReadinessAssistant\\application.properties"
                Add-Content -Path $using:catalinaProperties -Value "irp.config.file.path=C:\\Program Files\\tomcat9\\conf\\IntelligentReleasePlanner\\app.json"
                Add-Content -Path $using:catalinaProperties -Value "rra.config.file.path=C:\\Program Files\\tomcat9\\conf\\RequirementReadinessAssistant\\app.json"
            }
        }

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }
    }#dsc Script block

    Script "ImportJavaCerts" {
        SetScript = {
            Invoke-Expression -Command $importJavaCert1 -Verbose
            Invoke-Expression -Command $importJavaCert2 -Verbose
        }

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }
    }#dsc Script block

    StartService "Tomcat9" {
        serviceName = "Tomcat9"
    }



}

configuration DeployPythonApps {
    param (
        $Resources,
        $Node
    )

    Import-DscResource -Module xWebAdministration,  xPSDesiredStateConfiguration, xNetworking
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    #$webSites = $Resources | Select-Object @{ n="WebSiteName";e={(Split-Path -Path $_.WebSiteName -Parent)}}, @{n="WebSitePort";e={$_.Port }} -Unique | Where-Object WebSiteName -ne ""
    #
    #foreach($webSite in $webSites)
    #{
    #    xWebAppPool $webSite.WebSiteName {
    #        Name                           = $webSite.WebSiteName
    #        Ensure                         = 'Present'
    #        State                          = 'Started'
    #        autoStart                      = $true
    #        managedPipelineMode            = 'Integrated'
    #        managedRuntimeVersion          = 'v4.0'
    #        identityType                   = 'ApplicationPoolIdentity'
    #        loadUserProfile                = $true
    #    }
    #
    #    xWebsite $webSite.WebSiteName {
    #        Ensure          = 'Present'
    #        Name            = $webSite.WebSiteName
    #        State           = 'Started'
    #        ApplicationPool = $webSite.WebSiteName
    #        BindingInfo     =  MSFT_xWebBindingInformation  {
    #            Protocol              = 'http'
    #            Port                  = $webSite.WebSitePort
    #            HostName              = $webSite.WebSiteName
    #        }
    #    } 
    #}
    
    foreach ($item in $Resources)
    {
        $source = Get-Location -target Source -currentItem $item
        $destination = Get-Location -target Destination -currentItem $item -destinationField "Path"

        if(-not (Test-Path -Path $source))
        {
            Write-Host "Zip package not present for" $item.Name -BackgroundColor Red
        }
        else
        {
            Write-Host $item.Name -BackgroundColor green
            $parentSite = (Split-Path -Path $item.WebSiteName -Parent)
            if($parentSite -eq "") {
                $parentSite = (Split-Path -Path $item.WebSiteName -Leaf)
            }
            $childSite = (Split-Path -Path $item.WebSiteName -Leaf)

            File $item.Name {
                DestinationPath = $destination
                Ensure = 'Present'
                Type = 'Directory'
                Force = $true
                Checksum = 'ModifiedDate'
                Credential = $Node.ServerCredentials
            }

            BackupApps $item.Name {
                appPath = $destination
            }

            Archive $item.Name {
                Path = $source
                Destination = $destination
                Force = $true
                Ensure = 'Present'
                Checksum = 'ModifiedDate'
                Validate = $true
                Credential = $Node.ServerCredentials
            }

            xWebAppPool $item.Name {
                Name                           = $item.Name
                Ensure                         = 'Present'
                State                          = 'Started'
                autoStart                      = $true
                #enable32BitAppOnWin64          = $false
                #enableConfigurationOverride    = $true
                managedPipelineMode            = 'Integrated'
                managedRuntimeVersion          = 'v4.0'
                #passAnonymousToken             = $true
                #startMode                      = 'OnDemand'
                identityType                   = 'ApplicationPoolIdentity'
                loadUserProfile                = $true
            }

            #if not a parent-child site
            if($parentSite -eq $childSite) {
                #base website
                xWebsite $item.Name {
                    Ensure          = 'Present'
                    Name            = $parentSite
                    State           = 'Started'
                    ApplicationPool = $item.Name
                    PhysicalPath = $destination
                    BindingInfo     =  MSFT_xWebBindingInformation  {
                        Protocol              = 'http'
                        Port                  = $item.Port
                        HostName              = $parentSite
                    }
                }
            }
            else {
                xWebApplication $item.Name {
                    Name = $childSite
                    WebAppPool = $item.Name
                    PhysicalPath = $destination
                    Ensure = 'Present'
                    PreloadEnabled = $false
                    ServiceAutoStartEnabled = $true
                    Website = $parentSite
                }
            }


            ReplaceMacrosTasks $item.Name {
                currentItem = $item
            }

            PostDeploymentScripts $item.Name {
                currentItem = $item
            }

        }
    }


    Script "IISReset" {
        SetScript = {
            Invoke-Expression -Command "&iisreset" -Verbose
        }

        GetScript = {
            return $true
        }

        TestScript = {
            return $false
        }
    }#dsc Script block

}

configuration DeployPackages {
    param (
        $Resources,
        $Node
    )

    Import-DscResource -Module xWebAdministration,  xPSDesiredStateConfiguration, xNetworking
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    foreach ($item in $Resources)
    {
        $source = Get-Location -target Source -currentItem $item
        $destination = Get-Location -target Destination -currentItem $item -destinationField "PackagePath"

        if($destination -match "\\mnt\\myWizard-Phoenix") {
            $destination = $destination.Replace("\mnt\myWizard-Phoenix", $($Global:Environment.ApplicationInstallationFolder + "\Shared\Apps\myWizard-Phoenix"))
        }

        if(-not (Test-Path -Path $source))
        {
            Write-Host "Zip package not present for" $item.Name -BackgroundColor Red
        }
        else
        {
            File $item.Name {
                DestinationPath = $destination
                Ensure = 'Present'
                Type = 'Directory'
                Force = $true
                Checksum = 'ModifiedDate'
                Credential = $Node.ServerCredentials
            }

            BackupApps $item.Name {
                appPath = $destination
            }

            Archive $item.Name {
                Path = $source
                Destination = $destination
                Force = $true
                Ensure = 'Present'
                Checksum = 'ModifiedDate'
                Validate = $true
                Credential = $Node.ServerCredentials
            }

            ReplaceMacrosTasks $item.Name {
                currentItem = $item
            }
        }
    }
}

configuration DeployMongoDbRestore {
    param (
        $Resources,
        $Node
    )

    Import-DscResource -Module xWebAdministration,  xPSDesiredStateConfiguration, xNetworking
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    foreach ($item in $Resources)
    {
        $source = Get-Location -target Source -currentItem $item
        $destination = Get-Location -target Destination -currentItem $item -destinationField "BackupPath"

        if(-not (Test-Path -Path $source))
        {
            Write-Host "Zip package not present for" $item.Name -BackgroundColor Red
        }
        else
        {
            Write-Host $item.Name -BackgroundColor green
            $UserName = $Global:Environment.DBAdminUserName
            $Password = $Global:Environment.DBAdminPassword

            $BackupName = $item.BackupName
            $BackupPath = $item.BackupPath
            $DatabaseName = $item.DatabaseName
            $IP = $item.IP
            $Port = $item.Port
            $InstalledVersion = $item.InstalledVersion
            $PackageFolderName = $item.PackageFolderName
            $ConnectionString = $item.ConnectionString
            $MongoDBServerFolder = $item.MongoDBServerFolder
            $MongoDbInstallationBinPath = $item.MongoDbInstallationBinPath.Replace("/","\")
            $IsIncremental = $item.IsIncremental
            $sourceSharePath = $Global:Environment.SMBSharePath

            $IsSSL = ($item.ConnectionString -match 'ssl=true')
            If ($IsSSL -eq $true) {          
                $SSLCommand = '--ssl --sslCAFile ' + $MongoDBServerFolder + '\CA.crt --sslPEMKeyFile ' + $MongoDBServerFolder + '\server.pem'
            }
            else {
                $SSLCommand = ' '
            }
            $DatabaseNameUser = $DatabaseName + 'User'

            $restoreCommand = $("&""" + $MongoDbInstallationBinPath + "\mongorestore.exe"" --host " + $IP + " --db " + $DatabaseName + " " + $BackupPath + " -u " + $Username + " -p " + $Password + " --authenticationDatabase admin " + $SSLCommand + " --quiet --drop")
            $createUserCommand = $("&""" + $MongoDbInstallationBinPath + "\mongo.exe"" -host " + $IP + " -u " + $Username + " -p " + $Password + " " + $SSLCommand + " --eval ""db.getSiblingDB('" + $DatabaseName + "').createUser({user:'" + $DatabaseNameUser + "','pwd': $Password, roles : [{role: 'readWrite', db:'" + $DatabaseName + "'},{role: 'dbAdmin', db:'" + $DatabaseName + "'}]})""")
            If ($IsIncremental -eq $true) {
                $destination = $destination + "\IncrementalScripts\"
                #$incrementalCommand = $("&""" + $MongoDbInstallationBinPath + "\mongo.exe"" -host " + $IP + " -u " + $Username + " -p " + $Password + " " + $SSLCommand + " ")
                $incrementalCommand = $("&""" + $MongoDbInstallationBinPath + "\mongo.exe"" " + $IP + "/"+ $DatabaseName  + "  --authenticationDatabase admin -u admin  -p " + $Password + " " + $SSLCommand + " ")
                
            }
            
                        
            #Write-host $restoreCommand
            #Write-host $createUserCommand
            #Write-host $incrementalCommand

            Script "Deleting - $item.Name" {

                SetScript  = {
                    Remove-Item -Path $using:destination -Force | Out-null
                }

                GetScript = {
                    return $true
                }

                TestScript = {
                    return $false
                }
            }

            File $item.Name {
                DestinationPath = $destination
                Ensure = 'Present'
                Type = 'Directory'
                Force = $true
                Checksum = 'ModifiedDate'
                Credential = $Node.ServerCredentials
            }

            Archive $item.Name {
                Path = $source
                Destination = $destination
                Force = $true
                Ensure = 'Present'
                Checksum = 'ModifiedDate'
                Validate = $true
                Credential = $Node.ServerCredentials
            }

            If ($IsIncremental -eq $true) {
                ReplaceMacrosTaskInFolders $item.Name {
                   currentItem = $destination
                }
            }
            Else {
                ReplaceMacrosTasks $item.Name {
                currentItem = $item
                }
            }

            Script $item.Name {

                SetScript  = {
                    If ($using:IsIncremental -eq $true) {
                        $incrementalScripts = (Get-ChildItem -Path $using:destination).FullName
                        $CurrentDate = (Get-Date -Format yyyyMMdd.hhmmss)
                        $LogIncrementalPath = "D:\myWizard\Logs\IncrementalScripts\$using:DatabaseName.$CurrentDate.log"
                        Start-Transcript -Path $LogIncrementalPath
                        Write-Host
                        foreach($script in $incrementalScripts) {
                            Write-Host
                            Write-Host "Executing Incremental Scripts for DB - $using:DatabaseName, ScriptName - $script" 
                            Invoke-Expression -Command $($using:incrementalCommand + $script) -Verbose
                            Write-Host "Script execution completed"
                            Write-Host 
                        }
                        Stop-Transcript
                    }
                    else {
                        If ($DatabaseName -eq "mywizard-phoenix") {
                           
                            $ProductInstanceScriptPath = $using:sourceSharePath + "\Scripts\CustomScripts\FillProductInstanceByProductVersion.js"
                            New-Item -Path $using:BackupPath\ObjectJSON -ItemType 'Directory' -Force
                            $customDataPath = "$($using:sourceSharePath + "\DataLoader\Data\$using:InstalledVersion\*")"
                            Copy-Item $customDataPath -Destination $using:BackupPath\ObjectJSON -Force -Recurse
                            cd $using:BackupPath\Release
                            $DataLoaderPath = (Join-Path $using:BackupPath "\Release\Accenture.Mywizard.MongoDataLoader.exe")
                            & $DataLoaderPath
                            Invoke-Expression -Command $using:createUserCommand -Verbose
                            Write-Host "Executing Incremental Scripts for Core DB, ScriptName - FillProductInstanceByProductVersion.js" 
                            Invoke-Expression -Command $($using:incrementalCommand + $ProductInstanceScriptPath) -Verbose
                            Write-Host "Script execution completed"
                            Write-Host
                        }
                        Else
                        {
                            Invoke-Expression -Command $using:restoreCommand -Verbose
                            Invoke-Expression -Command $using:createUserCommand -Verbose
                        }
                    }
                }

                GetScript = {
                    return $true
                }

                TestScript = {
                    return $false
                }
            }
        }
    }
}

configuration DeployDataLoaderConfigurations {
    param (
        $Resources,
        $Node
    )

    Import-DscResource -Module xWebAdministration,  xPSDesiredStateConfiguration, xNetworking
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    foreach ($item in $Resources)
    {
        $source = $($Global:Environment.SMBSharePath + "\Dataloader")
        $destination = Get-Location -target Destination -currentItem $item -destinationField "PackagePath"

        if(-not (Test-Path -Path $source))
        {
            Write-Host "Zip package not present for" $item.Name -BackgroundColor Red
        }
        else
        {
            Write-Host $item.Name -BackgroundColor green

            If ($item.IsSSL -eq $true) {          
                $SSLCommand = '--ssl --sslCAFile ' + $item.MongoDBCertFolder + '\CA.crt --sslPEMKeyFile ' + $item.MongoDBCertFolder + '\server.pem'
            }
            else {
                $SSLCommand = ' '
            }
            
            $createUserCommand = $("&""" + $item.MongoBinPath + "\mongo.exe"" -host " + $item.DBHostName + " -u " + $item.DBUserName + " -p " + $item.DBPassword + " " + $SSLCommand + " --eval ""db.getSiblingDB('" + $item.MongoDatabaseName + "').createUser({user:'mywizard-phoenixUser','pwd': $Password, roles : [{role: 'readWrite', db:'" + $item.MongoDatabaseName + "'},{role: 'dbAdmin', db:'" + $item.MongoDatabaseName + "'}]})""")
            $customScript = $($Global:Environment.SMBSharePath + "\Scripts\CustomScripts\SetDataLoader.ps1")

            $SetScriptArguments = " -packagePath '" +$destination + "' -MongoDatabaseName '" +$item.MongoDatabaseName + "' -IsReplicated '" +$item.IsReplicated + "' -IsDropDatabase '" +$item.IsDropDatabase + "' -IsAuthenticated '" +$item.IsAuthenticated + "' -DBUserName '" +$item.DBUserName + "' -MongoDatabaseIP '" +$item.DBHostName + "' -DBPassword '" +$item.DBPassword + "' -ReplicationPartners '" +$($item.ReplicationPartners | ConvertTo-Json -Depth 100) + "' -IsExecPSScript '" +$item.ExecuteSchemaPSScript + "' -ConnectionString '" +$item.ConnectionString + "' -PackageDataPath '" +$item.PackageDataPath + "' -MongoBinPath '" +$item.MongoBinPath + "' -ClientCustomizationPath '" +$source + "' -InstalledVersion '" +$item.InstalledVersion + "' -IsSSL '" +$item.IsSSL + "' -MongoDBCertFolder '" +$item.MongoDBCertFolder + "' -MongoDBCertificatePassKey '" + $item.MongoDBCertificatePassKey + "'"
            
            write-host $createUserCommand

            File $item.Name {
                SourcePath = $customScript
                DestinationPath = $($destination + "\Scripts\SetDataLoader.ps1")
                Ensure = 'Present'
                Type = 'File'
                Force = $true
                Checksum = 'ModifiedDate'
                Credential = $Node.ServerCredentials
            }

            Script $item.Name {

                SetScript  = {
                    Invoke-Expression -Command $using:createUserCommand -ErrorAction SilentlyContinue -Verbose
                    Invoke-Expression -Command "$($using:destination + "\Scripts\SetDataLoader.ps1") $using:SetScriptArguments" -Verbose
                }

                GetScript = {
                    return $true
                }

                TestScript = {
                    return $false
                }
            }

        }
    }
}





#the entry point of DSC configuraton (other DSCs are called from this)
configuration ConfigureServer {
    param (
        $bdef
    )

    Import-DscResource -Module xWebAdministration,  xPSDesiredStateConfiguration, xNetworking
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    Node $AllNodes.NodeName {
        
        if($Node.Description -eq "Primary IIS Web Server") {
            CreateSharedPath "CreateSharedPath" {
                Node = $Node
            }
        }

        if($Node.Description -eq "Primary IIS Web Server") {
            CreateEnvVariables "CreateEnvVariables" {
                Node = $Node
            }
        }

        [psobject[]] $WebSites = Get-ResourcesForServer -ServerTemplateUid $Node.ServerTemplateUId -ResourceName WebSites -bdef $bdef
        if($WebSites.Count -gt 0) {
            DeployWebSites "WebSites" {
                Resources = $WebSites
                Node = $Node
            }
        }

        [psobject[]] $WindowsServices = Get-ResourcesForServer -ServerTemplateUid $Node.ServerTemplateUId -ResourceName WindowsServices -bdef $bdef
        if($WindowsServices.Count -gt 0) {
            DeployWindowsServices "WindowsServices" {
                Resources = $WindowsServices
                Node = $Node
            }
        }

        [psobject[]] $Tomcat = Get-ResourcesForServer -ServerTemplateUid $Node.ServerTemplateUId -ResourceName Tomcat -bdef $bdef
        if($Tomcat.Count -gt 0) {
            DeployTomcat "Tomcat" {
                Resources = $Tomcat
                Node = $Node
            }
        }

        [psobject[]] $PythonApps = Get-ResourcesForServer -ServerTemplateUid $Node.ServerTemplateUId -ResourceName PythonApps -bdef $bdef
        if($PythonApps.Count -gt 0) {
            DeployPythonApps "PythonApps" {
                Resources = $PythonApps
                Node = $Node
            }
        }

        [psobject[]] $Packages = Get-ResourcesForServer -ServerTemplateUid $Node.ServerTemplateUId -ResourceName Packages -bdef $bdef
        if($Packages.Count -gt 0) {
            DeployPackages "Packages" {
                Resources = $Packages
                Node = $Node
            }
        }

        [psobject[]] $MongoDbRestore = Get-ResourcesForServer -ServerTemplateUid $Node.ServerTemplateUId -ResourceName MongoDbRestore -bdef $bdef
        if($null -ne $MongoDbRestore) {
            DeployMongoDbRestore "MongoDbRestore" {
                Resources = $MongoDbRestore
                Node = $Node
            }
        }

        [psobject[]] $DataLoaderConfigurations = Get-ResourcesForServer -ServerTemplateUid $Node.ServerTemplateUId -ResourceName DataLoaderConfigurations -bdef $bdef
        if($DataLoaderConfigurations.Count -gt 0) {
            DeployDataLoaderConfigurations "DataLoaderConfigurations" {
                Resources = $DataLoaderConfigurations
                Node = $Node
            }
        }

    }
}






#get source & destination path of binaries
function Get-Location {
    param (
        [Parameter(Mandatory = $true)]
        [ValidateSet("Source", "Destination")]
        $target,

        [Parameter(Mandatory = $true)]
        $currentItem,

        $destinationField
    )
    process {
        if($target -eq "Source") {
            if($null -eq $item.PackageFile) {
                return $($Global:Environment.SMBSharePath + "\" + $Global:Environment.AppServices + "\" + $item.PackageFolderName + "\" + $item.InstalledVersion + "\" + $item.BackupName)
            }
            else {
                return $($Global:Environment.SMBSharePath + "\" + $Global:Environment.AppServices + "\" + $item.PackageFolderName + "\" + $item.InstalledVersion + "\" + $item.PackageFile)
            }
        }
        elseif ($target -eq "Destination") {
            return $($currentItem.$destinationField).Replace("/","\")
        }
    }
}

function Get-EnvironmentDetails {
    param (
        $bdef
    )
    process {
        return $bdef.Environment | Select-Object -Property MyWizardWebConsoleUrl,
        AdminUserName,
        AdminPassword,
        DBAdminUserName,
        DBAdminPassword,
        DBUserName,
        DBUserPassword,
        SMBShareName,
        @{n="SMBSharePath";e={$(($_.SMBSharePath)+(Resolve-Path .\).Path.Replace("C:\Accenture",""))}},
        InstallerFolder,
        SetupFolder,
        ApplicationInstallationFolder,
        SoftwareInstallationFolder,
        SoftwareFolder,
        CertificatesFolder,
        @{n = "AppServices"; e = { $_.ApplicationsFolder } },
        ModulesFolder,
        ScriptsFolder,
        DatabaseFolder,
        ConfigFolder,
        #@{n = "SoftwareFolder"; e = { $_.InstallerFolder + "\" + $_.SoftwareFolder } },
        #@{n = "CertificatesFolder"; e = { $_.InstallerFolder + "\" + $_.CertificatesFolder } },
        #@{n = "ApplicationsFolder"; e = { $_.InstallerFolder + "\" + $_.ApplicationsFolder } },        
        #@{n = "ModulesFolder"; e = { $_.InstallerFolder + "\" + $_.ModulesFolder } },
        #@{n = "ScriptsFolder"; e = { $_.InstallerFolder + "\" + $_.ScriptsFolder } },
        #@{n = "DatabaseFolder"; e = { $_.InstallerFolder + "\" + $_.DatabaseFolder } },
        #@{n = "ConfigFolder"; e = { $_.InstallerFolder + "\" + $_.ConfigFolder } },
        @{n = "MofOutputPath"; e = { (Resolve-Path .\).Path + "\" + $_.MofOutputPath } },
        @{n = "LogsFolder"; e = { (Resolve-Path .\).Path + "\Logs" } }, 
        @{n = "ThisPath"; e = { $(Split-Path $PSCommandPath -Parent) } }
    }
}

function Get-ResourcesForServer {
    param (
        $ServerTemplateUid,
        [ValidateSet("MongoDbRestore", "Packages", "PythonApps", "Tomcat", "WebSites", "WindowsServices", "DataLoaderConfigurations")]
        $ResourceName,
        $bdef
    )
    begin {
    }
    process {
        $serverTemplate = $bdef.ServerTemplates | Where-Object { $_.ServerTemplateUid -eq $ServerTemplateUid }

        if($serverTemplate | Get-Member | Where-Object {$_.Name -match $ResourceName}) {

            $serverTemplate = $serverTemplate | Select-Object -ExpandProperty $ResourceName
            if ($serverTemplate -ne $null) {
                $uid = $serverTemplate | Get-Member | Where-Object {$_.Name -match "uid"} | Select-Object -ExpandProperty Name
                return $bdef.Resources.$ResourceName | Where-Object {$_.$uid -in $serverTemplate.$uid -and $_.IsDeploymentEnabled -eq $true}
            }
        }
    }
}

function Install-PSModules {
    process {
        Write-Host "Checking required modules, Please wait..."

        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Install-PackageProvider -Name NuGet -Force -ForceBootstrap #-MinimumVersion 2.8.5.201

        #Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -PackageManagementProvider NuGet
        #Register-PSRepository -Name PSGallery
        #Get-Module -Name PackageManagement | Select-Object -ExpandProperty exportedcommands

        $psModules = Get-Module -ListAvailable | Select-Object -Property Name, Version

        if ($null -eq ($psModules | Where-Object { $_.Name -match "PackageManagement" })) {
            Write-Host "Installing PackageManagement module"
            Install-Module -Name PackageManagement -Force -AllowClobber -ErrorAction Stop | Out-Null #-MinimumVersion 1.4.6 
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "xWebAdministration" })) {
            Write-Host "Installing xWebAdministration module"
            Install-Module -Name xWebAdministration -Force -AllowClobber -ErrorAction Stop | Out-Null
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "xCertificate" })) {
            Write-Host "Installing xCertificate module"
            Install-Module -Name xCertificate -Force -AllowClobber -ErrorAction Stop | Out-Null
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "xDatabase" })) {
            Write-Host "Installing xDatabase module"
            Install-Module -Name xDatabase -Force -AllowClobber -ErrorAction Stop | Out-Null
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "xPSDesiredStateConfiguration" })) {
            Write-Host "Installing xPSDesiredStateConfiguration module"
            Install-Module -Name xPSDesiredStateConfiguration -Force -AllowClobber -ErrorAction Stop | Out-Null
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "nx" })) {
            Write-Host "Installing nx module"
            Install-Module -Name nx -Force -AllowClobber -ErrorAction Stop | Out-Null
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "ComputerManagementDsc" })) {
            Write-Host "Installing ComputerManagementDsc module"
            Install-Module -Name ComputerManagementDsc -Force -AllowClobber -ErrorAction Stop | Out-Null
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "SqlServerDsc" })) {
            Write-Host "Installing SqlServerDsc module"
            Install-Module -Name SqlServerDsc -Force -AllowClobber -ErrorAction Stop | Out-Null
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "xNetworking" })) {
            Write-Host "Installing xNetworking module"
            Install-Module -Name xNetworking -Force -AllowClobber -ErrorAction Stop | Out-Null
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "Microsoft.PowerShell.Archive" -and $_.Version -eq "1.2.3.0" })) {
            Write-Host "Installing Microsoft.PowerShell.Archive module"
            Install-Module Microsoft.PowerShell.Archive -MaximumVersion "1.2.3.0" -Force -AllowClobber -ErrorAction Stop | Out-Null
        }
    }
}

function Init {
    begin {

        $bdef = Get-Content -Raw -Path $ConfigFile
        $bdef = .\Scripts\Common\Cryptography.ps1 -Action Decrypt -KeyValue $AESKey -VectorValue $VectorKey -text $bdef 
        $bdef = $bdef | ConvertFrom-Json
        
        $configData = @{ AllNodes = @()}
        $Global:Environment = Get-EnvironmentDetails -bdef $bdef

        winrm set winrm/config/client '@{TrustedHosts="*"}' | Out-Null
        Set-Item -Path WSMan:\localhost\MaxEnvelopeSizekb -Value 10240

        #Install-PSModules

        Clear-Host
    }
    process {

        #create folders for Logs & MOFs
        New-Item -Path $Global:Environment.LogsFolder -Force -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
        New-Item -Path $Global:Environment.MofOutputPath -Force -ItemType Directory -ErrorAction SilentlyContinue | Out-Null

        ##INSTALL MONGO WITH REPLICATION
        #Write-Host "Mongo installation started"
        #$SMBSharePath = $($Global:Environment.SMBSharePath + "\" + $Global:Environment.AppServices)
        #$installMongoScript = $((Split-Path $PSCommandPath -Parent)+"\Install-Mongo.ps1")
        #$invokeInstallMongoScript = "$installMongoScript -configFile `"$ConfigFile`" -mofPath `".\MOF\Mongo`" -SMBSharePath `"$SMBSharePath`""
        #write-host  $invokeInstallMongoScript
        #Invoke-Expression $invokeInstallMongoScript
        #Write-Host "Mongo installation completed"
        [securestring]$password = ConvertTo-SecureString $Global:Environment.AdminPassword -AsPlainText -Force
        $credentials = New-Object System.Management.Automation.PSCredential ($Global:Environment.AdminUserName, $password)
                            
        #build server configuration $AllNodes
        $bdef.Servers | Where-Object {$_.Name -ne "" -and $_.IsRequired -eq $true} | 
                        
                        Select-Object -Property * -Unique | 
                        
                        ForEach-Object {

                            $configData.AllNodes += @{
                                NodeName = $_.Name
                                ServerTemplateUId = $_.ServerTemplateUId
                                PSDscAllowPlainTextPassword = $true
                                PSDscAllowDomainUser = $true
                                Description = $_.Description
                                ServerCredentials = $credentials
                            }
                        }




        #call the DSC and generate the MOF output
        Start-Transcript -Path $($Global:Environment.LogsFolder + "\myWizardBuildConfiguration_" + (Get-Date -Format "yyyyMMdd_hhmmss") + ".txt") | Out-Null
        ConfigureServer -OutputPath $Global:Environment.MofOutputPath -ConfigurationData $configData -bdef $bdef
        Stop-Transcript | Out-Null
    }
    end {
        #start the DSC and execute MOF
        Start-Transcript -Path $($Global:Environment.LogsFolder + "\myWizardDeployConfiguration_" + (Get-Date -Format "yyyyMMdd_hhmmss") + ".txt") | Out-Null
        
        foreach($node in $configData.AllNodes)
        {
            Start-DscConfiguration -Path $Global:Environment.MofOutputPath -ComputerName $node.NodeName -Wait -Force -Credential $node.ServerCredentials -Verbose
        }
        Remove-DscConfigurationDocument -Stage Pending -Force
        Remove-DscConfigurationDocument -Stage Previous -Force
        Remove-DscConfigurationDocument -Stage Current -Force
        Stop-Transcript | Out-Null
    }
}

Init