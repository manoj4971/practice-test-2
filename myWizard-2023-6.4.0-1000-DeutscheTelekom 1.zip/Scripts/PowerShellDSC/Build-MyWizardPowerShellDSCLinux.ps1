param(
    [Parameter(Mandatory = $true)]
    [string]$ConfigFile,
	
    [string] $MacroJsonFile,
    
    [string] $OutputPath = '',
    [string] $ConfigFilecontent,

    [Parameter(Mandatory = $true)]
    [string] $AESKey = "",

    [Parameter(Mandatory = $true)]
    [string] $VectorKey = ""
)


#region reusuables
configuration ReplaceMacrosTask
{
    param
    (
        $AppNode,
        $MacroJsonFile
    )
    $Password = [System.Web.HttpUtility]::UrlEncode($DscEnvironmentSettings.DBPwd)
    $ReplaceMacrosTasks = $AppNode.ReplaceMacrosTasks
    $Name = $(";appName="+$AppNode.Name)
    $Nameand = $("&appName="+$AppNode.Name)
    $MountPath = $DscEnvironmentSettings.LinuxMountPath
    $MacroJsonFile = $($MountPath + '/' + (Split-Path -Path $MacroJsonFile -Leaf))
    $CryptoScript = $($MountPath + '/Scripts/Common/Cryptography.ps1')
    $AzureAuth = $DscEnvironmentSettings.AuthProvider
    Import-DscResource -Module nx

    if($ReplaceMacrosTasks.Count -ge 1)
    {
        nxScript "replacemacros" {
            SetScript  = @"
#!/bin/pwsh
`$DefaultMacros = Get-Content -Raw -Path $MacroJsonFile
`$DefaultMacros = $CryptoScript -Action Decrypt -text `$DefaultMacros -KeyValue $AESKey -VectorValue $VectorKey | ConvertFrom-Json
foreach(`$file in "$ReplaceMacrosTasks".Split(' '))
{
    if(Test-Path -Path `$file)
    {
        Write-Host ""
        Write-Host ""
        Write-Host "Replacing macros in : " `$file
        `$configFile = Get-Content -Raw -path `$file
        [string[]]`$macrosInConfig = (([regex]('{\w+}')).Matches(`$configFile)) | Select-Object -ExpandProperty Value -Unique
        if (`$file.EndsWith(".js")){
            `$macrosInConfig = `$macrosInConfig | Where-Object { `$_ -ne "{clientName}"}
            `$macrosInConfig = `$macrosInConfig | Where-Object { `$_ -ne "{Name}"}
        }
        foreach (`$macro in `$macrosInConfig) {
            if (`$null -ne `$DefaultMacros.PSObject.Properties.Item(`$macro).Value) {
                `$value = `$DefaultMacros.PSObject.Properties.Item(`$macro).Value
                if((`$macro -match "DBQueryConnectionString") -or (`$macro -match "DBCommandConnectionString"))
                    {
                         if(($macro -match "MyWizardTestOptimizerRiskDBPrimaryDBQueryConnectionString") -or ($macro -match "MyWizardPatternMiningForSAPDBPrimaryDBQueryConnectionString"))
						{
							$value = $value
						}
						else{
                     If ($value.Contains("&ssl=true")) {
                        $value =$value + "$Nameand"}
                        else {
                        $value =$value + "$Name"}
                    }
					}
                    
                    if(`$macro -match "DBAdminAccountPassword"){
                        `$value = "$Password"
                    }
                    if("$AzureAuth" -eq "AzureAD"){
� � � � � � � � � � � �if(`$macro -match "ForgeRockAuthProvider" -or `$macro -match "ADFSAuthProvider"){
� � � � � � � � � � � � `$value = ""}
� � � � � � � � � � } 

� � � � � � � � �    if("$AzureAuth" -eq "ForgeRock"){
� � � � � � � � � � � �if(`$macro -match "AzureAD10AuthProvider" -or `$macro -match "ADFSAuthProvider"){
� � � � � � � � � � � � `$value = ""}
                    }
                    if("$AzureAuth" -eq "ADFS"){
� � � � � � � � � � � �if(`$macro -match "AzureAD10AuthProvider" -or `$macro -match "ForgeRockAuthProvider"){
� � � � � � � � � � � � `$value = ""}
                    } 
                `$configFile = `$configFile.Replace(`$macro,`$value )
                    Write-Host $("Replacing : `$macro ===> `$value")
            }
        }
        Set-Content `$file `$configFile
    }
}
"@
            GetScript  = @"
#!/bin/pwsh Write-Host "Test"
"@
            TestScript = @"
#!/bin/pwsh
exit 1
"@
        }
    }
}

configuration ReplaceMacrosTaskInFolders
{
    param
    (
        $AppPath,
        $MacroJsonFile
    )
    $Password = [System.Web.HttpUtility]::UrlEncode($DscEnvironmentSettings.DBPwd)
    $MountPath = $DscEnvironmentSettings.LinuxMountPath
    $MacroJsonFile = $($MountPath + '/' + (Split-Path -Path $MacroJsonFile -Leaf))
    $CryptoScript = $($MountPath + '/Scripts/Common/Cryptography.ps1')
	$AzureAuth = $DscEnvironmentSettings.AuthProvider
    Import-DscResource -Module nx

    
    
        nxScript "replacemacrosfolders" {
            SetScript  = @"
#!/bin/pwsh

`$ReplaceMacrosTasks = (Get-childitem -Path $AppPath).FullName 
`$DefaultMacros = Get-Content -Raw -Path $MacroJsonFile
`$DefaultMacros = $CryptoScript -Action Decrypt -text `$DefaultMacros -KeyValue $AESKey -VectorValue $VectorKey | ConvertFrom-Json
foreach(`$file in `$ReplaceMacrosTasks)
{
    if(Test-Path -Path `$file)
    {
        Write-Host "Replacing macros in : " `$file
        `$configFile = Get-Content -Raw -path `$file
        [string[]]`$macrosInConfig = (([regex]('{\w+}')).Matches(`$configFile)) | Select-Object -ExpandProperty Value -Unique
        if (`$file.EndsWith(".js")){
            `$macrosInConfig = `$macrosInConfig | Where-Object { `$_ -ne "{clientName}"}
            `$macrosInConfig = `$macrosInConfig | Where-Object { `$_ -ne "{Name}"}
            `$macrosInConfig = `$macrosInConfig | Where-Object { `$_ -ne "{ClientUId}"}
        }
        foreach (`$macro in `$macrosInConfig) {
            if (`$null -ne `$DefaultMacros.PSObject.Properties.Item(`$macro).Value) {
                
                    if(`$macro -match "DBAdminAccountPassword"){
                        `$DefaultMacros.PSObject.Properties.Item(`$macro).Value = "$Password"
                    }
					if("$AzureAuth" -eq "AzureAD"){
� � � � � � � � � � � �if($macro -match "ForgeRockAuthProvider" -or $macro -match "ADFSAuthProvider"){
� � � � � � � � � � � � $value = ""}
� � � � � � � � � � } 

� � � � � � � � �    if("$AzureAuth" -eq "ForgeRock"){
� � � � � � � � � � � �if($macro -match "AzureAD10AuthProvider" -or $macro -match "ADFSAuthProvider"){
� � � � � � � � � � � � $value = ""}
                    }
                    if("$AzureAuth" -eq "ADFS"){
� � � � � � � � � � � �if($macro -match "AzureAD10AuthProvider" -or $macro -match "ForgeRockAuthProvider"){
� � � � � � � � � � � � $value = ""}
                    } 
                `$configFile = `$configFile.Replace(`$macro, `$DefaultMacros.PSObject.Properties.Item(`$macro).Value)
                    Write-Host $("Replacing : `$macro ===> `$DefaultMacros.PSObject.Properties.Item(`$macro).Value")
            }
        }
        Set-Content `$file `$configFile
    }
}
"@
            GetScript  = @"
#!/bin/pwsh Write-Host "Test"
"@
            TestScript = @"
#!/bin/pwsh
exit 1
"@
        }
    
}

configuration lxFile
{
    param
    (
        [string]$SourcePath,
        [Parameter(Mandatory = $true)]
        [string]$DestinationPath,
        [Parameter(Mandatory = $true)]
        [ValidateSet("Present", "Absent")]
        [string]$Ensure,
        [boolean]$Recurse = $false,
        [Parameter(Mandatory = $true)]
        [ValidateSet("File", "Directory")]
        [string]$Type,
        [boolean]$Force,
        [ValidateSet("mtime", "ctime")]
        [string]$Checksum
    )
    Import-DscResource -Module nx
    
    if ($Type -eq "File") {
        $destination = $(Split-Path -Path $DestinationPath -Parent).Replace('\', '/')
    }
    if ($Type -eq "Directory") {
        $destination = $DestinationPath
    }
    nxFile "Directory" {
        DestinationPath = $destination
        Ensure          = $Ensure
        Type            = "Directory"
        Force           = $Force
    }
    if ($SourcePath.Trim() -ne '') {
        nxFile "File" {
            SourcePath      = $SourcePath
            DestinationPath = $DestinationPath
            Ensure          = $Ensure
            Recurse         = $Recurse
            Type            = $Type
            Force           = $Force
            Checksum        = $Checksum
        }
    }
}

configuration RestartService
{
    param
    (
        $ServiceName
    )
    Import-DscResource -Module nx
    nxScript "RestartService-$ServiceName" {
        GetScript  = @"
#!/bin/sh Write-Host "RestartService"
"@
        SetScript  = @"
#!/bin/sh
echo 'restarting service $ServiceName'
cd /etc/systemd/system
systemctl enable $ServiceName
systemctl restart $ServiceName
"@
        TestScript = @"
#!/bin/sh
exit 1
"@  

    }
}

configuration StopService
{
    param
    (
        $ServiceName
    )
    Import-DscResource -Module nx
    nxScript "StopService-$ServiceName" {
        GetScript  = @"
#!/bin/sh Write-Host "StopService"
"@
        SetScript  = @"
#!/bin/sh
systemctl stop $ServiceName
"@
        TestScript = @"
#!/bin/sh
exit 1
"@  

    }
}

configuration RestartServer
{
    Import-DscResource -Module nx
    nxScript "RestartServer" {
        GetScript  = @"
#!/bin/sh Write-Host "RestartServer"
"@
        SetScript  = @"
#!/bin/sh
sudo reboot
"@
        TestScript = @"
#!/bin/sh
exit 1
"@  

    }
}

configuration PostDeploymentScript
{
    param
    (
        $AppNode
    )
    [string[]]$PostDeploymentScripts = $AppNode.PostDeploymentScript | Where-Object {$_.ToLower().EndsWith(".sh")}
    $MountPath = $DscEnvironmentSettings.LinuxMountPath
    Import-DscResource -Module nx

    if($PostDeploymentScripts.Count -ge 1)
    {
        nxScript "postdeployment" {
            SetScript  = @"
#!/bin/pwsh
foreach(`$script in "$PostDeploymentScripts".Split(' '))
{
if(Test-Path -Path `$script)
{
Write-Host
`$scriptParent = (Split-Path `$Script -Parent)
Write-Host 'Executing below post deployment script'
Write-Host `$script

Write-Host
cd `$scriptParent
Write-Host "changed the directory to " `$scriptParent

sudo chmod -R 777 `$scriptParent
Write-Host "changed permission to 777 of " `$scriptParent

sudo dos2unix `$script
Write-Host "dos2unix executed for " `$script

Write-Host 
Write-Host "check script logs in "`$scriptParent"/out.log file"
sh `$script > out.log 2>&1
New-Item -Path "/mnt/win/myWizardSource/Logs/ShScriptExecutionLogs/" -ItemType Directory -ErrorAction SilentlyContinue -Force | Out-Null
Copy-Item -Path out.log -Destination $("/mnt/win/myWizardSource/Logs/ShScriptExecutionLogs/" + $AppNode.Name + ".log") -Force | Out-Null
}
else
{
Write-Host 'Below script path is incorrect in bdef or file not found'
Write-Host `$scriptParent
}
}
"@
            GetScript  = @"
#!/bin/pwsh Write-Host "Test"
"@
            TestScript = @"
#!/bin/pwsh
exit 1
"@
        }
    }
}

configuration BackupApp
{
    param
    (
        $AppPath
    )
    Import-DscResource -Module nx


    nxScript "BackupApp" {
    GetScript  = @"
#!/bin/pwsh Write-Host "Test"
"@
    TestScript = @"
#!/bin/pwsh
exit 1
"@
    SetScript  = @"
#!/bin/pwsh
`$Path = "/var/mywizard-backup"
`$Days = "2"
`$CurrentDate = (Get-Date -Format yyyyMMdd)
Get-ChildItem `$Path  | ForEach-Object { 
            `$folderName = `$_.Name
            `$fullPath = `$_.FullName
            `$date = `$folderName.Split("_")
            `$diff = `$CurrentDate - `$date[1]
            If (`$diff -gt `$Days) {
                Write-Host "Remove-Item -Path `$fullPath -Force -Recurse"
                Remove-Item -Path `$fullPath -Force -Recurse
            }
        }

if (Test-Path -Path "$AppPath") {
New-Item -ItemType Directory -Force -Path `$Path
if ( -Not ("$AppPath" -like "*GatewayManager*")) {
    `$BackupPath = "$AppPath".Replace("www","mywizard-backup") + "_" + (Get-Date -Format yyyyMMdd.hhmmss)
    Move-Item $AppPath -Destination `$BackupPath -Force
}
else {
    `$gmFolder = `$Path + "/GatewayManager_" + `$(Get-Date -Format yyyyMMdd)
    if("$AppPath" -match "bin") {
        New-Item -ItemType Directory -Force -Path `$gmFolder"/bin" | Out-Null
        Move-Item $AppPath -Destination `$gmFolder"/bin" -Force
    }
    New-Item -ItemType Directory -Force -Path `$gmFolder"/ProcessPipelines" | Out-Null
    `$AppPathProcessPipeline = "$AppPath".Replace("bin","ProcessPipelines")
    Get-ChildItem `$AppPathProcessPipeline -Recurse | Where-Object { `$_ -notmatch "ProcessLogs" -and `$_ -notmatch "Instances" } | ForEach-Object { Copy-Item -Path `$_.FullName -Destination `$_.FullName.Replace("var/www/GatewayManager",`$gmFolder) }
}
}
"@
}
}

configuration lxArchive
{
    param
    (
        $Source,
        $Destination
    )
    Import-DscResource -Module nx
    nxScript "UnzipApp" {
    GetScript  = @"
#!/bin/pwsh Write-Host "test archive"
"@
    TestScript = @"
#!/bin/pwsh
exit 1
"@
    SetScript  = @"
#!/bin/pwsh
Write-Host $("Extracting app from " + $Source + " to" + $Destination)
#Expand-Archive -Path "$Source" -DestinationPath "$Destination" -Force | Add-Content -Path /var/www/zipout.txt
New-Item -ItemType Directory -Path "/var/www/OneClickInstaller/Logs/UnzipLogs/" -Force -ErrorAction SilentlyContinue | Out-Null
New-Item -ItemType Directory -Path "$Destination" -Force -ErrorAction SilentlyContinue | Out-Null
`$outfile = "$("/var/www/OneClickInstaller/Logs/UnzipLogs/$(Split-Path -Path $Destination -Leaf).txt")"
unzip -o $Source -d $Destination > `$outfile
"@
    }
}
#end region







Configuration LinuxMountDrive
{
    param
    (
        # Target nodes to apply the configuration
        [String[]] $NodeName = 'localhost'
    )
    Import-DscResource -Module nx
    $DscEnvironmentSettings = $ConfigurationData.DscEnvironmentSettings
    $SMBSharePath = $DscEnvironmentSettings.SourceCustomizationsPath
    $MountPath = $DscEnvironmentSettings.LinuxMountPath
	$SMBSharePath = $SMBSharePath -replace "\\", "/"



    # SMB Credentials
    $AdminUserName = $DscEnvironmentSettings.AdminUserName
    $MountUserName = $DscEnvironmentSettings.MountUserName
    $MountPassword = $DscEnvironmentSettings.MountPassword
    #[SecureString] $AdminPassword = $DscEnvironmentSettings.AdminPassword | ConvertTo-SecureString -asPlainText -Force
    [PSCredential] $SMBCredential = New-Object System.Management.Automation.PSCredential($AdminUserName, $AdminPassword)
    Node  $NodeName
    {
        nxScript "MountShare" {
            GetScript  = @"
#!/bin/pwsh
Write-Host "Mounting SMB Share $MountPath "
"@
            SetScript  = @"
#!/bin/pwsh
mkdir -p $MountPath
mount -t cifs $SMBSharePath $MountPath -o username=$MountUserName,password=$MountPassword,vers=2.0,guest,noacl,noperm,rw
"@
            TestScript = @"
#!/bin/pwsh
`$checkMount = & df -P $MountPath | tail -1 | cut -d' ' -f 1 
 Write-Host `$checkMount
if (`$checkMount -eq "$SMBSharePath") 
{ 
Write-Host "MountPath exists." 
exit 0 
} 
else 
{ 
Write-Host "Mount Path does not exist" 
exit 1 
} 
"@
        }
       
    }
}

configuration DeployWebsite
{
    param
    (
        # Target nodes to apply the configuration
        [String[]] $NodeName = 'localhost'
    )

    Import-DscResource -Module nx
    $DscEnvironmentSettings = $ConfigurationData.DscEnvironmentSettings
    $SMBSharePath = $DscEnvironmentSettings.SMBSharePath
    $MountPath = $DscEnvironmentSettings.LinuxMountPath



    # SMB Credentials
    $AdminUserName = $DscEnvironmentSettings.AdminUserName
    #[SecureString] $AdminPassword = $DscEnvironmentSettings.AdminPassword | ConvertTo-SecureString -asPlainText -Force
    [PSCredential] $SMBCredential = New-Object System.Management.Automation.PSCredential($AdminUserName, $AdminPassword)

    # Define apps Localpath
    $sourceAppPackagesPath = $DscEnvironmentSettings.SourceAppServicesPathLinux 
    $localAppPackagesPath = $DscEnvironmentSettings.LocalAppServicesPath
    

    Node $NodeName
    {   
        Write-Host "$NodeName : Websites"
        ForEach ($site in $Node.WebSites) {
            if ($site.IsDeploymentEnabled -eq $true) {
                $websiteName = $site.WebSiteName
                # $WebsiteProtocol = $site.WebsiteProtocol
                # $WebSiteIpAddress = $site.WebSiteIpAddress
                $WebSitePort = $site.WebSitePort
                $WebSitePath = $site.WebSitePath
                # $WebSiteAppPoolName = $site.WebSiteAppPoolName
                # $WebSiteAppPoolUserName = $site.WebSiteAppPoolUserName
                # $WebSiteAppPoolPassword = $site.WebSiteAppPoolPassword
                # $WebSiteHostName = $site.WebSiteHostName
                # $CertificateStoreName = $site.CertificateStoreName 
                # $CertificateThumbprint = $site.CertificateThumbprint
                $PackageFile = $site.PackageFile
                # $CertificateType = $site.CertificateType
                # $CertificateSubject = ''
                $InstalledVersion = $site.InstalledVersion
                $PackageFolderName = $site.PackageFolderName
                $WebsiteNodeName = $site.Name
                $ExecutablePath = $site.ExecutablePath
                

                $sourceFilePath = "$sourceAppPackagesPath/$PackageFolderName/$InstalledVersion/$PackageFile"
                $localFilePath = "$localAppPackagesPath\$PackageFolderName\$InstalledVersion\$PackageFile"
                
                BackupApp "BackupApplicationPackage-$WebsiteNodeName" {
                    AppPath = $WebSitePath
                }
                
                lxArchive $("UnzipBinaries" + $WebsiteNodeName) {
                    Source = $sourceFilePath
                    Destination = $WebSitePath
                }          

                nxScript "CreateServiceFile-$WebsiteNodeName" {
                   GetScript = @"
#!/bin/pwsh Write-Host "CreateServiceFile-$WebsiteNodeName"
"@
                    SetScript = @"
#!/bin/pwsh
`$file = "/etc/systemd/system/$WebsiteNodeName.service"
if(!(Test-Path -Path `$file)) {
`$content = {[Unit]
Description=metrics .NET Web API Application running on CentOS 7

[Service]
WorkingDirectory=$WebSitePath
ExecStart=/usr/bin/dotnet $ExecutablePath
Restart=always
SyslogIdentifier=$WebSitePath
User=nginx
Group=nginx
Environment=ASPNETCORE_ENVIRONMENT=Dev

[Install]
WantedBy=multi-user.target
}
New-Item `$file -ItemType File
Set-Content `$file `$content
}
"@
                    TestScript = @"
#!/bin/pwsh
exit 1
"@
}

                ReplaceMacrosTask "WebsiteConfigFiles-$WebsiteNodeName" {
                    AppNode       = $site
                    MacroJsonFile = $MacroJsonFile
                }

                RestartService "RestartService-$WebsiteNodeName" {
                    ServiceName = $WebsiteNodeName
                }

            }
        }
    }
}

configuration DeployPythonApp
{
    param
    (
        # Target nodes to apply the configuration
        [String[]] $NodeName = 'localhost'
    )

    Import-DscResource -Module nx
    $DscEnvironmentSettings = $ConfigurationData.DscEnvironmentSettings
    $SMBSharePath = $DscEnvironmentSettings.SMBSharePath
    $MountPath = $DscEnvironmentSettings.LinuxMountPath



    # SMB Credentials
    $AdminUserName = $DscEnvironmentSettings.AdminUserName
    #[SecureString] $AdminPassword = $DscEnvironmentSettings.AdminPassword | ConvertTo-SecureString -asPlainText -Force
    [PSCredential] $SMBCredential = New-Object System.Management.Automation.PSCredential($AdminUserName, $AdminPassword)

    # Define apps Localpath
    $sourceAppPackagesPath = $DscEnvironmentSettings.SourceAppServicesPathLinux 
    $localAppPackagesPath = $DscEnvironmentSettings.LocalAppServicesPath



    Node $NodeName
    {   
        Write-Host "$NodeName : PythonApps"
        ForEach ($site in $Node.PythonApps) {
            if ($site.IsDeploymentEnabled -eq $true) {
                $websiteName = $site.WebSiteName
                $Port = $site.Port
                $Path = $site.Path
                $ExecutablePath = $site.ExecutablePath
                $ExecutableFile = $site.ExecutableFile
                $SockFilePath = $site.SockFilePath
                $Url = $site.Url
                $PackageFile = $site.PackageFile
                $InstalledVersion = $site.InstalledVersion
                $PackageFolderName = $site.PackageFolderName
                $WebsiteNodeName = $site.Name
                $ExecutablePath = $site.ExecutablePath
                

                $sourceFilePath = "$sourceAppPackagesPath/$PackageFolderName/$InstalledVersion/$PackageFile"
                $localFilePath = "$localAppPackagesPath\$PackageFolderName\$InstalledVersion\$PackageFile"

                BackupApp "BackupApplicationPackage-$WebsiteNodeName" {
                    AppPath = $Path
                }

                lxArchive $("UnzipBinaries" + $WebsiteNodeName) {
                    Source = $sourceFilePath
                    Destination = $Path
                }  
                
                nxScript "CopyServiceFile-$WebsiteNodeName" {
                   GetScript = @"
#!/bin/pwsh Write-Host "CopyServiceFile-$WebsiteNodeName"
"@
                    SetScript = @"
#!/bin/pwsh
`$file = "/etc/systemd/system/$WebsiteNodeName.service"
if(!(Test-Path -Path `$file)) {
Copy-Item -Path $($DscEnvironmentSettings.SourceInstallerPathLinux+"/pythonservicefiles/$WebsiteNodeName.service") -Destination "/etc/systemd/system/$WebsiteNodeName.service" -Force
}
"@
                    TestScript = @"
#!/bin/pwsh
exit 1
"@
}  

                ReplaceMacrosTask "WebsiteConfigFiles-$WebsiteNodeName" {
                    AppNode       = $site
                    MacroJsonFile = $MacroJsonFile
                }

                PostDeploymentScript "ExecCustomScripts-$WebsiteNodeName" {
                    AppNode = $site
                }

                nxService "StartService-$WebsiteNodeName" {
                    Name       = $WebsiteNodeName
                    State      = 'Running'
                    Enabled    = $true
                    Controller = 'systemd'
                }

                RestartService "RestartService-$WebsiteNodeName" {
                    ServiceName = $WebsiteNodeName
                }

            }
        }
    }
}

configuration DeployWindowsServices 
{
    param
    (
        # Target nodes to apply the configuration
        [String[]] $NodeName = 'localhost'
    )

    # Import the module that defines custom resources
    Import-DscResource -Module nx

    $DscEnvironmentSettings = $ConfigurationData.DscEnvironmentSettings

    # SMB Credentials
    $AdminUserName = $DscEnvironmentSettings.AdminUserName
    #[SecureString] $AdminPassword = $DscEnvironmentSettings.AdminPassword | ConvertTo-SecureString -asPlainText -Force
    [PSCredential] $SMBCredential = New-Object System.Management.Automation.PSCredential($AdminUserName, $AdminPassword)

    # Define apps Localpath
    $sourceAppPackagesPath = $DscEnvironmentSettings.SourceAppServicesPathLinux
    $localAppPackagesPath = $DscEnvironmentSettings.LocalAppServicesPath

    Node $NodeName
    {
        Write-Host "$NodeName : WindowServices"

        # iterates through each of the service defined in the config file
        ForEach ($service in $Node.WindowsServices) {
       
            if ($service.IsDeploymentEnabled -eq $true) {

                $ServiceName = $service.Name
                $ServiceDescription = $service.Description
                $PackageFile = $service.PackageFile
                $ServicePath = $service.ServicePath.Replace("{ApplicationInstallationFolder}", $DscEnvironmentSettings.ApplicationInstallationFolder).Replace("{SoftwareInstallationFolder}", $DscEnvironmentSettings.SoftwareInstallationFolder) 
                $AppServicesPath = $service.AppServicesPath.Replace("{ApplicationInstallationFolder}", $DscEnvironmentSettings.ApplicationInstallationFolder).Replace("{SoftwareInstallationFolder}", $DscEnvironmentSettings.SoftwareInstallationFolder) 
                $Path = $service.Path.Replace("{ApplicationInstallationFolder}", $DscEnvironmentSettings.ApplicationInstallationFolder).Replace("{SoftwareInstallationFolder}", $DscEnvironmentSettings.SoftwareInstallationFolder)
                $StartupType = $service.StartupType
                $State = $service.State
                $ConfigFilePath = $service.ConfigFilePath.Replace("{ApplicationInstallationFolder}", $DscEnvironmentSettings.ApplicationInstallationFolder).Replace("{SoftwareInstallationFolder}", $DscEnvironmentSettings.SoftwareInstallationFolder)
                $InstalledVersion = $service.InstalledVersion
                $PackageFolderName = $service.PackageFolderName


                $sourceFilePath = "$sourceAppPackagesPath/$PackageFolderName/$InstalledVersion/$PackageFile"
                $localFilePath = "$localAppPackagesPath\$PackageFolderName\$InstalledVersion\$PackageFile"
                $processpipelinePath = $AppServicesPath.Replace("bin","ProcessPipelines")

                if($processpipelinePath -match "GatewayManager") {

                nxScript "Remove-GMConfigs-$ServiceName" {
                    GetScript  = @"
#!/bin/pwsh
Write-Host " delete gm config files"
"@
                    SetScript  = @"
#!/bin/sh
if [ -d $processpipelinePath ]; then
echo "Removing the property injector from "$sourceFilePath
zip -d $sourceFilePath  *-PropertyInjector.xml
fi
}
"@
                    TestScript = @"
#!/bin/pwsh
Write-Host " delete gm config files"
exit 1
"@   
                }

                }

                BackupApp "BackupApplicationPackage-$ServiceName" {
                    AppPath = $AppServicesPath
                }
                
               
                lxArchive $("UnzipBinaries" + $ServiceName) {
                    Source = $sourceFilePath
                    Destination = $ServicePath
                }

                nxScript "CreateServiceFile $ServiceName" {
                   GetScript = @"
#!/bin/pwsh Write-Host "CreateServiceFile $ServiceName"
"@
                    SetScript = @"
#!/bin/pwsh
`$file = "/etc/systemd/system/$ServiceName.service"
if(!(Test-Path -Path `$file)) {
`$content = {[Unit] 
Description=metrics .NET Web API Application running on CentOS 7

[Service]
WorkingDirectory=$AppServicesPath
ExecStart=/usr/bin/dotnet $Path 
Restart=always
SyslogIdentifier=$ServicePath
User=nginx
Group=nginx
Environment=ASPNETCORE_ENVIRONMENT=Dev

[Install]
WantedBy=multi-user.target
}
New-Item `$file -ItemType File
Set-Content `$file `$content
}
"@
                    TestScript = @"
#!/bin/pwsh
exit 1
"@
}
                               
                ReplaceMacrosTask "ServiceConfigFiles $ServiceName" {
                    AppNode       = $service
                    MacroJsonFile = $MacroJsonFile
                }

                PostDeploymentScript "ExecCustomScripts-$ServiceName" {
                    AppNode = $service
                }

                RestartService "RestartService-$ServiceName" {
                    ServiceName = $ServiceName
                }
            }
        }  
    }
}

configuration ConfigureCustomScripts
{
    param
    (
        # Target nodes to apply the configuration
        [String[]] $NodeName = 'localhost'
    )

    Import-DSCResource -Module nx
    $DscEnvironmentSettings = $ConfigurationData.DscEnvironmentSettings

    # SMB Credentials
    $AdminUserName = $DscEnvironmentSettings.AdminUserName
    #[SecureString] $AdminPassword = $DscEnvironmentSettings.AdminPassword | ConvertTo-SecureString -asPlainText -Force
    [PSCredential] $SMBCredential = New-Object System.Management.Automation.PSCredential($AdminUserName, $AdminPassword)

    # Define Scripts Localpath
    $LinuxMountPath = $DscEnvironmentSettings.LinuxMountPath
    $LinuxTargetFolder = $DscEnvironmentSettings.LinuxTargetFolder
    $setUpFolderName = (Get-Location).Path.split("\")[-1]
    $sourceScriptsPath = "$LinuxMountPath/Scripts/CustomScripts/"
    $localScriptsPath = "$LinuxTargetFolder/Scripts/CustomScripts/"

    Node $NodeName {
        Write-Host "$NodeName : CustomScripts"

        ForEach ($script in $Node.CustomScripts) {
            if ($script.IsDeploymentEnabled -eq $true) {
                $ScriptName = $script.Name
                $SetScriptFile = $script.SetScriptFile
                $SetScriptArguments = $script.SetScriptArguments.Replace("{ApplicationInstallationFolder}", $DscEnvironmentSettings.ApplicationInstallationFolder).Replace("{SoftwareInstallationFolder}", $DscEnvironmentSettings.SoftwareInstallationFolder)
                $TestScriptFile = $script.TestScriptFile
                $TestScriptArguments = $script.TestScriptArguments.Replace("{ApplicationInstallationFolder}", $DscEnvironmentSettings.ApplicationInstallationFolder).Replace("{SoftwareInstallationFolder}", $DscEnvironmentSettings.SoftwareInstallationFolder)
                Write-Host $ScriptName
                # source filepath
                $sourceSetScriptFilePath = $sourceScriptsPath + $SetScriptFile
                $sourceTestScriptFilePath = $sourceScriptsPath + $TestScriptFile

                # local filepath
                $localSetScriptFilePath = $localScriptsPath + $SetScriptFile
                $localTestScriptFilePath = $localScriptsPath + $TestScriptFile

                nxFile "CreateDirectory-$ScriptName" { 
                    Ensure          = "Present" 
                    DestinationPath = "$localScriptsPath" 
                    Type            = "Directory" 
                }

                # copy set script
                nxFile "CopySetScript-$ScriptName" {
                    SourcePath      = $sourceSetScriptFilePath
                    DestinationPath = $localSetScriptFilePath
                    Type            = "File"
                    Mode            = "644"
                    Ensure          = "Present"
                    Force           = $true
                    Checksum        = "mtime"
                }

              

                #$localSetScriptFilePath = $localSetScriptFilePath -replace ' ', '` ' 
                #$localTestScriptFilePath = $localTestScriptFilePath -replace ' ', '` ' 

                $SetScriptArguments = $SetScriptArguments.Replace("{SMBSharePath}", $DscEnvironmentSettings.SMBSharePath).Replace("{Client}", $DscEnvironmentSettings.Client)

                # execute script
                nxScript "ExecuteCustomScript-$ScriptName" {
                    GetScript  = @"
#!/bin/pwsh Write-Host "Test"
"@
                    SetScript  = @"
#!/bin/pwsh
$localSetScriptFilePath $SetScriptArguments
"@
                    TestScript = @"
#!/bin/pwsh
exit 1
"@
           
                }

            }
        }
    }
}

configuration DeployPackages
{
    param
    (
        # Target nodes to apply the configuration
        [String[]] $NodeName = 'localhost'
    )

    # Import the module that defines custom resources
    Import-DscResource -Module nx

    $DscEnvironmentSettings = $ConfigurationData.DscEnvironmentSettings

   

    # Define apps Localpath
    $sourceAppPackagesPath = $DscEnvironmentSettings.SourceAppServicesPathLinux
   
    Node $NodeName
    {
        Write-Host "$NodeName : Packages"
     
        # iterates through each of the Windows defined in the config file
        ForEach ($package in $Node.Packages) {
            if ($package.IsDeploymentEnabled -eq $true) {
            $PackageName = $package.Name
            $PackageDescription = $package.Description
            $PackageFile = $package.PackageFile
            $PackagePath = $package.PackagePath
            $InstalledVersion = $package.InstalledVersion
            $PackageFolderName = $package.PackageFolderName

            $localFilePath = "$sourceAppPackagesPath/$PackageFolderName/$InstalledVersion/$PackageFile"
           
            #backup only GM packages, Others won't be backup
            if ($PackageFile -match "GatewayManager" -and $package.ReplaceMacrosTasks.Count -gt 0) {
                $AppServicesPath = $(Split-Path -Path $package.ReplaceMacrosTasks[0] -Parent).Replace("\\", "/").Replace("\", "/")
                BackupApp "BackupApplicationPackage-$PackageName" {
                    AppPath = $AppServicesPath
                }
            }


            if ($PackageFile -eq "myWizard.Scripts.zip" ) {
                $PackagePath = $PackagePath + "/IncrementalScripts/"
            }

            lxArchive $("UnzipBinaries" + $PackageName) {
                Source = $localFilePath
                Destination = $PackagePath
            }

			ReplaceMacrosTask "PackageConfigFiles-$PackageName" {
                    AppNode       = $package
                    MacroJsonFile = $MacroJsonFile
            }

            PostDeploymentScript "ExecCustomScripts-$PackageName" {
                AppNode = $package
            }
        }
        }
    }
}

configuration DeployFolders
{
    param
    (
        # Target nodes to apply the configuration
        [String[]] $NodeName = 'localhost'
    )

    $DscEnvironmentSettings = $ConfigurationData.DscEnvironmentSettings

   
    Node $NodeName {
        Write-Host "$NodeName : Folders"

        ForEach ($folder in $Node.Folders) {
            if ($folder.IsDeploymentEnabled -eq $true) {
                $folderName = $folder.Name
                $DestinationPath = $folder.DestinationPath
                $SourcePath = $folder.SourcePath
                $Checksum = $folder.Checksum
                $Recurse = $folder.Recurse
                $Force = $folder.Force

                if ($Recurse -eq "true") {
                    $Recurse = $true
                }
                else {
                    $Recurse = $false
                }

                if ($Force -eq "true") {
                    $Force = $true
                }
                else {
                    $Force = $false
                }

                # copy set script

                if ($SourcePath) {
                    nxFile "DeployFolder-$folderName" {
                        Type            = "Directory"
                        DestinationPath = $DestinationPath
                        SourcePath      = $SourcePath
                        Checksum        = $Checksum
                        Recurse         = $Recurse
                        Force           = $Force                        
                    }
                }
                else {
                    nxFile "DeployFolder-$folderName" {
                        Type            = "Directory"
                        DestinationPath = $DestinationPath
                        Force           = $Force
                    }
                }
            
        
            }
        }
    }
}

configuration DeployFiles
{
    param
    (
        # Target nodes to apply the configuration
        [String[]] $NodeName = 'localhost'
    )

    $DscEnvironmentSettings = $ConfigurationData.DscEnvironmentSettings

    # Get Templated values
    
    # Define Config Localpath
    $sourceConfigPath = $DscEnvironmentSettings.SourceAppServicesPathLinux + '/' + $DscEnvironmentSettings.ConfigFolder
    
    Node $NodeName {
        Write-Host "$NodeName : Files"

        ForEach ($file in $Node.Files) {
            if ($file.IsDeploymentEnabled -eq $true) {
                $fileName = $file.Name
                $DestinationPath = $file.DestinationPath
                $Checksum = $file.Checksum
                $Force = ($file.Force -eq 'true')
 
                $sourceFilePath = (Join-Path $sourceConfigPath $fileName)
                $localFilePath = (Join-Path $localConfigPath $fileName)

                nxFile "DeployFile1-$fileName-$fileUId" {
                    Ensure          = "Present"
                    DestinationPath = $DestinationPath
                    Type            = "Directory"
                }

                # copy set script
                nxFile "DeployFile1-$fileName-$fileUId" {
                    Type            = "File"  
                    SourcePath      = $sourceFilePath              
                    DestinationPath = $DestinationPath                   
                    Checksum        = $Checksum
                    Force           = $Force
                }

            }  
        }
    }
}

configuration ConfigureTomcat 
{
    param
    (
        # Target nodes to apply the configuration
        [String[]] $NodeName = 'localhost'
    )
    Import-DscResource -Module nx
    $DscEnvironmentSettings = $ConfigurationData.DscEnvironmentSettings

    Node $NodeName {
        Write-Host "$NodeName : ConfigureTomcat"

        StopService "Tomcat" {
            ServiceName = "tomcat"
        }
        
        BackupApp "BackupTomcatServerXML" {
            AppPath = "/etc/tomcat9/conf/server.xml"
        }

        nxFile "CopyTomcatServerXML" {
            DestinationPath = "/etc/tomcat9/conf/server.xml"
            SourcePath      = $DscEnvironmentSettings.SourceInstallerPathLinux + "/tomcat9/server.xml"
            Checksum        = "mtime"
            Force           = $true
            Ensure          = "Present"
            Type            = "File"
        }

        BackupApp "BackupTomcatCatalinaFile" {
            AppPath = "/etc/tomcat9/conf/catalina.properties"
        }

        nxFile "CopyTomcatCatalinaFile" {
            DestinationPath = "/etc/tomcat9/conf/catalina.properties"
            SourcePath      = $DscEnvironmentSettings.SourceInstallerPathLinux + "/tomcat9/catalina.properties"
            Checksum        = "mtime"
            Force           = $true
            Ensure          = "Present"
            Type            = "File"
        }

        ForEach ($tomcatNode in $Node.Tomcat) {
            if ($tomcatNode.IsDeploymentEnabled -eq $true) {
                $Name = $tomcatNode.Name
                $PropertyFileFullPath = $tomcatNode.PropertyFilePath
                $WarFileFullPath = $tomcatNode.WarFilePath
                $PackageFile = $tomcatNode.PackageFile
                $PackageFolderName = $tomcatNode.PackageFolderName
                $InstalledVersion = $tomcatNode.InstalledVersion

                $PropertyFilePath = (Split-Path -Path $PropertyFileFullPath).Replace('\','/')
                $PropertyFileName = Split-Path -Path $PropertyFileFullPath -Leaf

                $WarFilePath = (Split-Path -Path $WarFileFullPath).Replace('\','/')
                $WarFileName = Split-Path -Path $WarFileFullPath -Leaf
            
                # source filepath
                $sourceTomcatAppPackagesPath = $DscEnvironmentSettings.SourceAppServicesPathLinux + "/$PackageFolderName/$InstalledVersion/$PackageFile"
                $sourceTomcatAppPropertyFilePath = $DscEnvironmentSettings.SourceAppServicesPathLinux + "/$PackageFolderName/$InstalledVersion/$PropertyFileName"
                $NginxFileName = $Name + ".conf"

                BackupApp "BackupPackage-$Name" {
                    AppPath = "$WarFileFullPath"
                }

                nxScript "DeleteAutoGeneratedFolders-$Name" {
                GetScript  = @"
#!/bin/pwsh Write-Host "Test AutoGeneratedFolders Deletion"
"@
                SetScript  = @"
#!/bin/pwsh
if("$Name" -match "IntelligentReleasePlanner.WebAPI") {
    Remove-Item -Path "/etc/tomcat9/webapps/IntelligentReleasePlanner" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
}
if("$Name" -match "RequirementsReadinessAnalyzer.WebAPI") {
    Remove-Item -Path "/etc/tomcat9/webapps/RequirementReadinessAssistant" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
}
if("$Name" -match "ReleasePlannerAgile.WebAPI") {
    Remove-Item -Path "/etc/tomcat9/webapps/ReleasePlannerAgile" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
}
if("$Name" -match "ReleasePlannerAgile.WebConsole") {
    Remove-Item -Path "/etc/tomcat9/webapps/ReleasePlannerAgile" -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
}
"@
                TestScript = @"
#!/bin/pwsh
Write-Verbose "AutoGeneratedFolders Deletion"
exit 1
"@
                }

                lxArchive $("UnzipBinaries" + $Name) {
                    Source = $sourceTomcatAppPackagesPath
                    Destination =  "/var/www/temp/tomcat/"
                }    

                BackupApp "BackupTomPropertyFile-$Name" {
                    AppPath = "$PropertyFileFullPath"
                }

                nxScript "CopyTomcatFiles-$Name" {
                GetScript  = @"
#!/bin/pwsh Write-Host "Test"
"@
                SetScript  = @"
#!/bin/sh
mkdir -p $PropertyFilePath
mv -f /var/www/temp/tomcat/application.properties $PropertyFileFullPath
mv -f /var/www/temp/tomcat/app.json $PropertyFilePath/
mv -f /var/www/temp/tomcat/application-common-cryptography.jar $PropertyFilePath/
yes | cp -r /var/www/temp/tomcat/* /etc/tomcat9/webapps/
rm -f /etc/tomcat9/webapps/myWizard*.conf
rm -rf /var/www/temp/tomcat
"@
                TestScript = @"
#!/bin/pwsh
Write-Verbose "CopyTomcatFiles"
exit 1
"@
              }
                   
                ReplaceMacrosTask "TomcatConfigFiles-$Name" {
                    AppNode       = $tomcatNode
                    MacroJsonFile = $MacroJsonFile
                }

                PostDeploymentScript "ExecCustomScripts-$Name" {
                    AppNode = $tomcatNode
                }
            }
        } 
        
         
        RestartService "Rabbitmq" {
            ServiceName = "rabbitmq-server"
        }

        RestartService "Tomcat" {
            ServiceName = "tomcat"
        }
    }
}

configuration MongoDBRestore 
{
    param
    (
        # Target nodes to apply the configuration
        [String[]] $NodeName = 'localhost'
    )

    $DscEnvironmentSettings = $ConfigurationData.DscEnvironmentSettings
    $UserName = $DscEnvironmentSettings.DBAdminUserName
    $Password = $DscEnvironmentSettings.DBPwd
    Import-DscResource -Module nx

    Node $NodeName {
        Write-Host "$NodeName : MongoDBRestore"

        ForEach ($node in $Node.MongoDbRestore) {
            if ($node.IsDeploymentEnabled -eq $true) {
      
                $BackupName = $node.BackupName
                $BackupPath = $node.BackupPath
                $DatabaseName = $node.DatabaseName
                $IP = $node.IP
                $Port = $node.Port
                $Name = $node.Name
                
                $InstalledVersion = $node.InstalledVersion
                $PackageFolderName = $node.PackageFolderName
                $ConnectionString = $node.ConnectionString
                # source filepath
               
                $sourceBackUpPackagesPath = $DscEnvironmentSettings.SourceAppServicesPathLinux + "/$PackageFolderName/$InstalledVersion/$BackupName"
                
                $IsSSL = ($ConnectionString -match 'ssl=true')
                $MongoDBServerFolder = $node.MongoDBServerFolder
                $SSLCommand = '--ssl --sslCAFile ' + $MongoDBServerFolder + '/CA.crt --sslPEMKeyFile ' + $MongoDBServerFolder + '/server.pem'
                $DatabaseNameUser = $DatabaseName + 'User'
                $BackupPathScript = $BackupPath + "/IncrementalScripts/"
                if($DatabaseName -eq "mywizard-phoenix"){
                $BackupPathScript = $BackupPath
                }
                $BackupPathScriptInc = $BackupPath + "/IncrementalScripts/"
                $HostName = $IP


                If ($IP.Contains(",")) {
                    $IP = "myWizardMongo1RS/" + $IP 
                }
                 
              

                If ($node.IsIncremental -eq $true) {

                nxFile "Deleting-$Name"{
                    Ensure          = "Absent"
                    DestinationPath = $BackupPathScript
                    Force           = $true
                    Type            = "Directory"
                } 

                If((Test-Path ($DscEnvironmentSettings.SourceAppServicesPath + "\$PackageFolderName\$InstalledVersion\$BackupName")) -eq $true) {

                # extracts the Scripts package to a incremental folder 
                
                lxArchive $("UnzipBinaries" + $Name) {
                    Source = $sourceBackUpPackagesPath
                    Destination = $BackupPathScript
                }    

                ReplaceMacrosTaskInFolders "MongoIncrementalFiles-$Name" {
                    AppPath       = $BackupPathScriptInc
                    MacroJsonFile = $MacroJsonFile
                }

                ReplaceMacrosTask "MongoRestoreConfigFiles-$Name" {
                    AppNode       = $node
                    MacroJsonFile = $MacroJsonFile
                }

                If ($IsSSL -eq $true) {
                If ($DatabaseName -eq "mywizard-phoenix") {
                        $LinuxMountPath = $DscEnvironmentSettings.LinuxMountPath
                        $sourceScriptsPath = "$LinuxMountPath/Scripts/CustomScripts/"
                        nxScript "MongoDataloader-$Name" {
                        GetScript  = @"
#!/bin/sh
Write-Host "Mongo DB uptodate"
"@
                        TestScript = @"
#!/bin/sh
exit 1 
"@
                        SetScript  = @"
#!/bin/pwsh
cd $BackupPath/Release
Write-Host "Running Incremental DataLoader..."
/usr/bin/dotnet Accenture.Mywizard.MongoDataLoader.dll DeployINCJSON DeployINCScripts

"@
                    }  
                    
                    }
                    Else{
                    nxScript "ExecuteMongoDbScript-$Name" {
                        GetScript  = @"
#!/bin/sh
Write-Host "Mongo DB uptodate"
"@
                        TestScript = @"
#!/bin/sh
exit 1 
"@
                        SetScript  = @"
#!/bin/pwsh
`$CurrentDate = (Get-Date -Format yyyyMMdd.hhmmss)
`$LogIncrementalPath = "/var/www/Logs/IncrementalScripts/$DatabaseName.`$CurrentDate.log"
`$DBHost = "$HostName"

Start-Transcript -Path `$LogIncrementalPath
Write-Host

If ("$DatabaseName" -ne "mywizard-phoenix"){
Write-Host "Taking DB backup - $DatabaseName" 
mongodump --host $IP --db $DatabaseName $SSLCommand --authenticationDatabase $DatabaseName -u $DatabaseNameUser -p $Password --out /var/IncrementalBackup
Write-Host
}

If (`$DBHost.Contains(",")) {
    `$result = Invoke-Expression -Command "mongo `$DBHost/$DatabaseName -u $Username -p $Password --authenticationDatabase admin $SSLCommand --quiet --eval 'rs.status().members.find(r=>r.state===1).name'"
    `$DBHost = `$result[`$result.Length - 1]
     Write-Host "DatabasePrimaryHostName : `$DBHost and Command used for finding primary host as follows"
     Write-Host "mongo `$DBHost/$DatabaseName -u $Username -p $Password --authenticationDatabase admin $SSLCommand --quiet --eval 'rs.status().members.find(r=>r.state===1).name'"
}

`$files  = Get-ChildItem $BackupPathScript
foreach (`$file in `$files) {
    Write-Host
    Write-Host "Executing Incremental Scripts for DB - $DatabaseName, ScriptName - `$file" 
    mongosh `$DBHost/$DatabaseName -u $Username -p $Password --authenticationDatabase admin $SSLCommand `$file
    Write-Host "Script execution completed"
    Write-Host
}
Stop-Transcript
"@
                    }
                    }
                }
                Else {
                    nxScript "ExecuteMongoDbScript-$Name" {
                        GetScript  = @"
#!/bin/sh
Write-Host "Mongo DB uptodate"
"@
                        TestScript = @"
#!/bin/sh
exit 1 
"@
                        SetScript  = @"
#!/bin/pwsh
mongosh -host $IP -u $Username -p $Password --eval "db.getSiblingDB('$DatabaseName').createUser({user:'$DatabaseNameUser','pwd': '$Password', roles : [{role: 'readWrite', db:'$DatabaseName'},{role: 'dbAdmin', db:'$DatabaseName'}]})"
`$files  = Get-ChildItem $BackupPathScript
foreach (`$file in `$files) {
mongosh $IP/$DatabaseName -u $Username -p $Password --authenticationDatabase admin`$file
}
"@
                    }
                }

                }
                }

                Else {
                # extracts the application package to a folder
                
                lxArchive $("UnzipBinaries" + $Name) {
                    Source = $sourceBackUpPackagesPath
                    Destination = $BackupPath
                }    

                ReplaceMacrosTask "MongoRestoreConfigFiles-$Name" {
                    AppNode       = $node
                    MacroJsonFile = $MacroJsonFile
                }

                If ($IsSSL -eq $true) {
                    If ($DatabaseName -eq "mywizard-phoenix") {
                        $LinuxMountPath = $DscEnvironmentSettings.LinuxMountPath
                        $sourceScriptsPath = "$LinuxMountPath/Scripts/CustomScripts/"
                        $ProductInstanceScriptPath = $sourceScriptsPath + "FillProductInstanceByProductVersion.js"
                        $ProductInstanceDeserializationPath = $sourceScriptsPath + "ProductInstanceDeserializationFixes.js"
                        $EntityUIdScriptPath = $sourceScriptsPath + "MetricMeasure_EntityUId_WorkItemTypeUId_update.js"
                        nxScript "MongoDataloader-$Name" {
                        GetScript  = @"
#!/bin/sh
Write-Host "Mongo DB uptodate"
"@
                        TestScript = @"
#!/bin/sh
exit 1 
"@
                        SetScript  = @"
#!/bin/pwsh
cd $BackupPath/Release
Write-Host "Running DataLoader..."
/usr/bin/dotnet Accenture.Mywizard.MongoDataLoader.dll DeployDB
Write-Host "Running Encryption..."
cd $BackupPath/MyWizard.DB.Encryption
/usr/bin/dotnet Accenture.Mongo.DataEncryption.dll
mongosh -host $IP -u $Username -p $Password $SSLCommand --eval "db.getSiblingDB('$DatabaseName').createUser({user:'$DatabaseNameUser','pwd': '$Password', roles : [{role: 'readWrite', db:'$DatabaseName'},{role: 'dbAdmin', db:'$DatabaseName'}]})"
mongosh $IP/$DatabaseName -u $Username -p $Password --authenticationDatabase admin $SSLCommand $ProductInstanceScriptPath > /var/www/Mongo.DataLoader/FillProductInstanceByProductVersion.log
mongosh $IP/$DatabaseName -u $Username -p $Password --authenticationDatabase admin $SSLCommand $ProductInstanceDeserializationPath > /var/www/Mongo.DataLoader/ProductInstanceDeserializationFixes.log
mongosh $IP/$DatabaseName -u $Username -p $Password --authenticationDatabase admin $SSLCommand $EntityUIdScriptPath > /var/www/Mongo.DataLoader/MetricMeasureEntityUIdWorkItemTypeUIdupdate.log

"@
                    }  
                    
                    }
                    Else{
                    nxScript "RestoreMongoDb-$Name" {
                        GetScript  = @"
#!/bin/sh
Write-Host "Mongo DB uptodate"
"@
                        TestScript = @"
#!/bin/sh
exit 1 
"@
                        SetScript  = @"
#!/bin/sh
mongorestore --host $IP --db $DatabaseName $BackupPath -u $Username -p $Password --authenticationDatabase admin $SSLCommand --quiet --drop
mongosh -host $IP -u $Username -p $Password $SSLCommand --eval "db.getSiblingDB('$DatabaseName').createUser({user:'$DatabaseNameUser','pwd': '$Password', roles : [{role: 'readWrite', db:'$DatabaseName'},{role: 'dbAdmin', db:'$DatabaseName'}]})"

"@
                    }
  }
                }
                Else {
                    nxScript "RestoreMongoDb-$Name" {
                        GetScript  = @"
#!/bin/sh
Write-Host "Mongo DB uptodate"
"@
                        TestScript = @"
#!/bin/sh
exit 1 
"@
                        SetScript  = @"
#!/bin/sh
mongorestore --host $IP --db $DatabaseName $BackupPath --drop -u $Username -p $Password --authenticationDatabase admin --quiet --drop
mongosh -host $IP -u $Username -p $Password --eval "db.getSiblingDB('$DatabaseName').createUser({user:'$DatabaseNameUser','pwd': '$Password', roles : [{role: 'readWrite', db:'$DatabaseName'},{role: 'dbAdmin', db:'$DatabaseName'}]})"
"@
                    }
                }
                
              

                PostDeploymentScript "ExecCustomScripts-$BackupName" {
                    AppNode = $node
                }

              }
            }
        }
    }
 }

configuration DeployCustomObjects
{
    param
    (
        # Target nodes to apply the configuration
        [String[]] $NodeName = 'localhost'
    )

    Import-DscResource -Module nx

    Node $NodeName
    {

        nxScript "DeployCustomObjects" {
            GetScript  = @"
#!/bin/pwsh
Write-Host "Deploying OCI custom files/folders/scripts etc."
"@
            SetScript  = @"
#!/bin/pwsh
Copy-Item -Path "/mnt/win/myWizardSource/Scripts/CustomScripts/Shellscript_Menu.sh" -Destination "/var/www/appConfigFiles/Shellscript_Menu.sh" -Force -ErrorAction SilentlyContinue | Out-Null

New-Item -Path "/var/www/appConfigFiles/PackageInfoAPIService" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
Copy-Item -Path "/mnt/win/myWizardSource/Scripts/CustomScripts/Pull-PackageInfo.ps1" -Destination "/var/www/appConfigFiles/PackageInfoAPIService/Pull-PackageInfo.ps1" -Force -ErrorAction SilentlyContinue | Out-Null
"@
            TestScript = @"
#!/bin/pwsh
Write-Host "Checking  OCI custom files/folders/scripts etc on target machine."
exit 1
"@ 
        }

        ReplaceMacrosTaskInFolders "DeployCustomObjects" {
            AppPath = "/var/www/appConfigFiles/PackageInfoAPIService"
            MacroJsonFile = $MacroJsonFile
        }

        nxScript "CronJobs" {
            GetScript  = @"
#!/bin/pwsh
Write-Host "Creating cron jobs on target machine."
"@
            SetScript  = @"
#!/bin/sh
crontab -l > /var/www/appConfigFiles/PackageInfoAPIService/cronjob

if grep -q Pull-PackageInfo.ps1 /var/www/appConfigFiles/PackageInfoAPIService/cronjob; then
    echo "CornJob exists"
else
    echo "0 18 * * * /usr/bin/pwsh /var/www/appConfigFiles/PackageInfoAPIService/Pull-PackageInfo.ps1" >> /var/www/appConfigFiles/PackageInfoAPIService/cronjob
    crontab /var/www/appConfigFiles/PackageInfoAPIService/cronjob
fi
rm -f /var/www/appConfigFiles/PackageInfoAPIService/cronjob
"@
            TestScript = @"
#!/bin/pwsh
Write-Host "Creating cron jobs on target machine."
exit 1
"@ 
        }

    }
}



configuration ConfigureServer
{
    Import-DscResource -Module nx
    Node $AllNodes.NodeName
    {
        write-host "`nBuilding DSC configation for $NodeName"

        LinuxMountDrive "LinuxMountDrive" {
            NodeName = $Node.NodeName
        }

        nxScript "PreDeploymentReport" {
            GetScript  = @"
#!/bin/pwsh
Write-Host "Executing Pre Deployment GetScript Report"
"@
            SetScript  = @"
#!/bin/sh
yum -y install zip
yum -y install unzip
yum -y install dos2unix
dos2unix /mnt/win/myWizardSource/Scripts/CustomScripts/GeneratePostDeploymentReport.sh 
sh /mnt/win/myWizardSource/Scripts/CustomScripts/GeneratePostDeploymentReport.sh Pre
#pwsh /mnt/win/myWizardSource/Scripts/CustomScripts/Values-FromGMConfigs.ps1 -reportType Pre -nodeName $($Node.NodeName)
"@
            TestScript = @"
#!/bin/pwsh
Write-Host "Executing Pre Deployment TestScript Report" 
exit 1
"@
            
        }

        DeployCustomObjects "DeployCustomObjects" {
            NodeName = $Node.NodeName
        }

        #Copying GoneFishingFiles from Software folder
        $SourcePath = $ConfigurationData.DscEnvironmentSettings.SourceInstallerPathLinux  + "/GoneFishingFiles/html/"
        nxScript "GoneFishingFilesCopy" {
        GetScript  = @"
#!/bin/sh
"@
        SetScript  = @"
#!/bin/sh
yes | cp -r $SourcePath /usr/share/nginx/
"@
        TestScript = @"
#!/bin/sh
exit 1
"@
        }

        # WebSites
        if ($Node.WebSites -ne $null -and $Node.WebSites.IsDeploymentEnabled -eq $true ) {
           
        
            DeployWebSite "DeployWebsites" {
                NodeName = $Node.NodeName
               
            }
        }

        # PythonApps
        if ($Node.PythonApps -ne $null -and $Node.PythonApps.IsDeploymentEnabled -eq $true ) {
           
        
            DeployPythonApp "DeployPythonApps" {
                NodeName = $Node.NodeName
               
            }
        }

        # Packages
        if ($Node.Packages -ne $null -and $Node.Packages.IsDeploymentEnabled -eq $true) {
            DeployPackages "DeployPacks" {
                NodeName = $Node.NodeName
            }
        }

        # WindowsServices
        if ($Node.WindowsServices -ne $null -and $Node.WindowsServices.IsDeploymentEnabled -eq $true) {
            DeployWindowsServices "DeployWinServices" {
                NodeName = $Node.NodeName
            }
        }

        # MongoDBRestore
        if ($Node.MongoDBRestore -ne $null -and $Node.MongoDBRestore.IsDeploymentEnabled -eq $true) {
            MongoDBRestore "MongoDBRestore" {
                NodeName = $Node.NodeName
            }
        }

        # CustomScripts
        if ($Node.CustomScripts -ne $null -and $Node.CustomScripts.IsDeploymentEnabled -eq $true) {
            ConfigureCustomScripts "ConfigureCustomScripts" {
                NodeName = $Node.NodeName
            }
        }

        # Configure Tomcat
        if ($Node.Tomcat -ne $null -and $Node.Tomcat.IsDeploymentEnabled -eq $true) {
            ConfigureTomcat "Tomcat" {
                NodeName = $Node.NodeName
            }
        }


#        nxScript "HostChange" {
#        GetScript  = @"
##!/bin/sh Write-Host "HostChange"
#"@
#        SetScript  = @"
##!/bin/sh
#for file in `$(find /var/www/ -name 'appsettings.json')
#do
#sed -i 's|\"hostingUrl\":\"http://localhost|\"hostingUrl\":\"http://0.0.0.0|g' `$file
#sed -i 's|\"hostingUrl\": \"http://localhost|\"hostingUrl\": \"http://0.0.0.0|g' `$file
#done
#"@
#        TestScript = @"
##!/bin/sh
#exit 1
#}
#"@
#        }

#        nxScript "RestarAllService" {
#        GetScript  = @"
##!/bin/sh Write-Host "RestartService"
#"@
#        SetScript  = @"
##!/bin/sh
#cd /etc/systemd/system
#for f in my*.service;  do systemctl enable `${f};  systemctl restart `${f}; done
#"@
#        TestScript = @"
##!/bin/sh
#exit 1
#"@  
#
#    }

        #Modifying permission of folders to nginx
        nxScript "AddFolderPermission" {
        GetScript  = @"
#!/bin/sh 
echo "Adding nginx permission to folders"
"@
        SetScript  = @"
#!/bin/sh
IP=`$(hostname -I|cut -d" " -f 1)
dos2unix /mnt/win/myWizardSource/Scripts/CustomScripts/AddFolderPermissions.sh 
sh /mnt/win/myWizardSource/Scripts/CustomScripts/AddFolderPermissions.sh > /mnt/win/myWizardSource/Logs/FolderPermissionsLogs_`$IP.log 2>&1
"@
        TestScript = @"
#!/bin/sh
exit 1
"@
        }

        #copying dsc execution logs back to deployment server
        nxScript "CopyLogs" {
        GetScript  = @"
#!/bin/pwsh 
echo "copying logs to deployment server"
"@
        SetScript  = @"
#!/bin/pwsh
echo "moving logs to deployment server"
Move-Item -Path '/var/opt/omi/log/dsc.log' -Destination $('/mnt/win/myWizardSource/Logs/demacronization_'+$($Node.NodeName)+'_'+$(Get-Date -Format "ddMMyyyy")+'.log') -Force
Move-Item -Path '/var/opt/omi/log/omiserver.log' -Destination $('/mnt/win/myWizardSource/Logs/omiserver_'+$($Node.NodeName)+'_'+$(Get-Date -Format "ddMMyyyy")+'.log') -Force
Move-Item -Path '/var/www/OneClickInstaller/Logs/UnzipLogs/' -Destination '/mnt/win/myWizardSource/Logs/'						
sh /mnt/win/myWizardSource/Scripts/CustomScripts/GeneratePostDeploymentReport.sh Post
#/mnt/win/myWizardSource/Scripts/CustomScripts/binary-enumeration.ps1 -reportType Count -nodeName $($Node.NodeName)
#/mnt/win/myWizardSource/Scripts/CustomScripts/Values-FromGMConfigs.ps1 -reportType Post -nodeName $($Node.NodeName)
"@
        TestScript = @"
#!/bin/sh
exit 1
"@
        }

        #Unmounting mount path
        nxScript "UnmountPath" {
        GetScript  = @"
#!/bin/sh 
echo "Unmounting mount path"
"@
        SetScript  = @"
#!/bin/sh
echo "Unmounting mount path"
umount /mnt/win/myWizardSource
"@
        TestScript = @"
#!/bin/sh
exit 1
"@
        }

        nxScript "DeleteOfflineHTML" {
        GetScript  = @"
#!/bin/sh 
"@
        SetScript  = @"
#!/bin/sh
rm -f /usr/share/nginx/html/phoenix/app_offline.html
"@
        TestScript = @"
#!/bin/sh
exit 1
"@
        }
    }
}

function CreateDeploymentPackage {
    param(
        [object] $jsonParams
    )

    process {
        $CustomerName = $jsonParams.Client.Name
        $Version = $jsonParams.Version.Name
        $Environment = $jsonParams.Environment.Name
        $rootFolder
        #Write-Host "CustomerName: $CustomerName"
        #Write-Host "Version: $Version"
        #Write-Host "Environment: $Environment"

        $SourcePath = (Join-Path ".\Clients\" $CustomerName)
        $OutputFile = "$($CustomerName)_$($Version)_$($Environment).zip"

        # create temp folder
        $tmpFolder = ".\tmp"
        if ((Test-Path $tmpFolder) -ne $true) {
            new-item -ItemType Directory -Path $tmpFolder
        }
        else {
            Write-Warning "$tmpFolder already exists."
        }

        # copy application packages
        Write-Host "Copying application packages..."
        Copy-Item -Path ".\Clients\$CustomerName\$Environment\$Version" -Destination ".\tmp\$CustomerName\$Environment\$Version" -Recurse -Force
        #Copy-Item -Path ".\Clients\$CustomerName\$Environment\$Version\Packages" -Destination ".\tmp\$CustomerName\$Environment\$Version" -Recurse -Force

        # create zip file
        Write-Host "Creating zip file..."
        Push-Location $tmpFolder
        Compress-Archive -Path ".\$CustomerName" -DestinationPath "..\$OutputFile" -Force

        # delete temp folder
        Push-Location "..\"
        Write-Host "Deleting tmp folder..."
        #Remove-Item -Path ".\tmp" -Recurse -Force
    }
}

function CreateDeploymentJsonFile {
    param(
        [hashtable] $DscEnvironmentSettings,
        [object] $ServerList
    )

    process {
        Write-Host "`nGenerating Deployment Parameters File"
        
        $CustomerName = $jsonParams.Client.Name
        $Version = $jsonParams.Version.Name
        $Environment = $jsonParams.Environment.Name
        # $LocalPath = $DscEnvironmentSettings.LocalPath
        #$EnvironmentBasePath = ""
        $DeploymentParamsFile = "$($DscEnvironmentSettings.EnvironmentBasePath)\$($DscEnvironmentSettings.DeploymentParamsFile)"
        
        $servers = [System.Collections.ArrayList]@()
        foreach ($server in $ServerList) {
            $serverht = @{
                ServerName        = $server.Name
                Description       = $server.Description
                OperatingSystem   = $server.OperatingSystem
                ConfigurationPath = $DscEnvironmentSettings.MofOutputPath
                AdminUser         = $server.AdminUser
                AdminPassword     = $server.AdminPassword
                Configure         = "true"
            }

            [void]$servers.Add($serverht)
        }

        $serversht = @{
            Servers = $servers
        }
        $deployJsonString = $serversht | ConvertTo-json -depth 100

        Set-Content -Path $DeploymentParamsFile -value $deployJsonString
        
        Write-Host "Generated $DeploymentParamsFile"
    }
}

function CreateInstallPreReqJsonFile {
    param(
        [hashtable] $DscEnvironmentSettings,
        [object] $ServerList
    )

    process {
        Write-Host "`nGenerating Install-PreReq Parameters File"

        $CustomerName = $jsonParams.Client.Name
        $Version = $jsonParams.Version.Name
        $Environment = $jsonParams.Environment.Name
        #$LocalPath = $DscEnvironmentSettings.LocalPath
        #$EnvironmentBasePath = "DscEnvironmentSettings.EnvironmentBasePath"
        
        $PreReqParamsFile = "$($DscEnvironmentSettings.EnvironmentBasePath)\$($DscEnvironmentSettings.PreReqParamsFile)"
        
        $EnvironmentSettings = @{
            AdminUserName       = $DscEnvironmentSettings.AdminUserName
            AdminPassword       = $DscEnvironmentSettings.AdminPassword
            ModulesSourcePath   = $DscEnvironmentSettings.ModulesSourcePath
            ModulesLocalPath    = $DscEnvironmentSettings.ModulesLocalPath
            PreReqMofOutputPath = $DscEnvironmentSettings.PreReqMofOutputPath
            ConfigureLcm        = "false"
            BuildConfiguration  = "true"
            DeployConfiguration = "true"
        }

        $servers = [System.Collections.ArrayList]@()
        $isAnyWindowsServer = $false
        foreach ($server in $ServerList) {
            if ($server.OperatingSystem -eq 'Windows') {
                $isAnyWindowsServer = $true;
                $serverht = @{
                    ServerName    = $server.Name
                    Description   = $server.Description
                    AdminUser     = $server.AdminUser
                    AdminPassword = $server.AdminPassword
                    Configure     = "true"
                }

                [void]$servers.Add($serverht)
            }
        }

        if ($isAnyWindowsServer) {
            $serversht = @{
                EnvironmentSettings = $EnvironmentSettings
                Servers             = $servers
            }
            $deployJsonString = $serversht | ConvertTo-json -depth 100

            Set-Content -Path $PreReqParamsFile -value $deployJsonString
            
            Write-Host "Generated $PreReqParamsFile"
        }
        else {
            Write-Host "No Windows Server found. Need not run Prerequisites for Linux server"
        }
    }
}

function BuildConfiguration {
    begin {
        # # set strict mode
        # Set-StrictMode -Version 5.0

        # import modules
        Import-Module .\Scripts\Common\myWizard-HelperFunctions.psm1 -Force

        # configure transaction log file
        $LogFilePath = ".\Logs\BuildConfigurationLinux" + (Get-Date -Format "yyyyMMdd_hhmmss") + ".log"

        # output filter that adds a timestamp
        filter timestamp { "$(Get-Date -Format "MM/dd/yyyy hh:mm:ss:fff tt"): $_" }

        Clear-Host
        Stop-DscConfiguration -Force -ErrorAction SilentlyContinue
        Remove-DscConfigurationDocument -Stage Current -Force -ErrorAction SilentlyContinue
        Remove-DscConfigurationDocument -Stage Pending -Force -ErrorAction SilentlyContinue
        Remove-DscConfigurationDocument -Stage Previous -Force -ErrorAction SilentlyContinue
        # start transcript
        Start-Transcript -Path $LogFilePath

    }
    process {
    
        try {
            Write-Output "Opening  $ConfigFile." | timestamp
            $jsonParams = Get-Content -Raw -Path $ConfigFile 
            $jsonParams = .\Scripts\Common\Cryptography.ps1 -Action Decrypt -KeyValue $AESKey -VectorValue $VectorKey -text $jsonParams 
            $jsonParams = $jsonParams | ConvertFrom-Json
            # process params
            $configData = ParseDscJson_v1_1 -jsonParams $jsonParams

            $CustomerName = $jsonParams.Client.Name
            $Version = $jsonParams.Version.Name
            $Environment = $jsonParams.Environment.Name
            $LocalPath = $jsonParams.Client.SetupFolder
            $EnvironmentBasePath = "$LocalPath"
            
            # Check if password is provided by user for SMB share else prompt for it.

            # Read Environment settings
            $DscEnvironmentSettings = $jsonParams.Environment
            
            # SMB Credentials
            $AdminUserName = $DscEnvironmentSettings.AdminUserName
           
            if ($DscEnvironmentSettings.AdminPassword) {
                [SecureString] $AdminPassword = ConvertTo-SecureString $DscEnvironmentSettings.AdminPassword -AsPlainText -Force 
            }
            else {
                [SecureString] $AdminPassword = Read-Host "Please enter SMB Share password for [$($AdminUserName)] :" -AsSecureString
            }
          
            #$OutputPath = "$EnvironmentBasePath\MOF"
            $OutputPath = $configData.DscEnvironmentSettings.MofOutputPath

            # create mof
            Write-Output "Creating mof files." | timestamp
            if (![bool]$OutputPath) {
                ConfigureServer -ConfigurationData $configData
            }
            else {
                ConfigureServer -ConfigurationData $configData -OutputPath $OutputPath
            }

            # create json file
            CreateDeploymentJsonFile -DscEnvironmentSettings $configData.DscEnvironmentSettings -ServerList ($jsonParams.Servers | Where-Object -Property IsRequired -EQ $true)

            # create prereq json file
            CreateInstallPreReqJsonFile -DscEnvironmentSettings $configData.DscEnvironmentSettings -ServerList ($jsonParams.Servers | Where-Object -Property IsRequired -EQ $true)

            # create deployment zip
            if ($configData.DscEnvironmentSettings.CreateZip -eq "true") {
                CreateDeploymentPackage -jsonParams $jsonParams 
            }

            Write-Output "`n"
            Write-output "Build complete." | timestamp
        }
        catch {
            $ErrorMessage = $_.Exception.Message

            Write-Output "An exception occurred: $ErrorMessage" | timestamp
        }
        
    }

    end {
        # end transcript
        Stop-Transcript
    }
}

BuildConfiguration -ConfigFile $ConfigFile -ConfigFilecontent $ConfigFileContent