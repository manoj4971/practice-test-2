﻿param
(
    $configFile = '.\myWizard-EA-01.00.201903-PROD-mywizard.bdef.tmp.json',
    $mofPath = '.\MOF\Mongo',
    $SMBSharePath = '\\192.168.16.102\Accenture\myWizard\myWizard-Installer-mywizard-PROD-01.00.201903\AppServices'
)

configuration ConfigureMongo
{
    param
    (
        [string]$nodeName = '',
        $mongo
    )
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource –Module 'xNetworking'

    $unzipPath = 'D:\myWizard\MongoDB\'
    
    $currentReplicationPartner = $mongo.ReplicationPartners | Where-Object { $_.bindIp -eq $nodeName }
    $mycreds = GetCredentials -node $currentReplicationPartner

    Node $nodeName
    {
        File CopyMongoZip {
            DestinationPath = $($unzipPath + $mongo.PackageName)
            SourcePath      = $($SMBSharePath + '\' + $mongo.PackageFolderName + '\' + $mongo.InstalledVersion + '\' + $mongo.PackageName)
            Ensure          = 'Present'
            Force           = $true
            Type            = 'File'
            Checksum        = 'ModifiedDate'
            MatchSource     = $true
            Credential      = $mycreds
        }

        Archive UnzipMongoPackage {
            Path        = $($unzipPath + $mongo.PackageName)
            Destination = $unzipPath
            Ensure      = 'Present'
            Force       = $true
            DependsOn   = '[File]CopyMongoZip'
            Validate    = $true
            Checksum    = 'ModifiedDate'
        }

        File MongoDBDataFolder {
            DestinationPath = $mongo.MongoDBDataFolder
            Ensure          = 'Present'
            Force           = $true
            Type            = 'Directory'
        }

        File MongoDBLogsFolder {
            DestinationPath = $mongo.MongoDBLogsFolder
            Ensure          = 'Present'
            Force           = $true
            Type            = 'Directory'
        }

        File MongoDBServerFolder_MongoDBKeyFile {
            DestinationPath = $($mongo.MongoDBServerFolder + '\' + $mongo.MongoDBKeyFile)
            SourcePath      = $($unzipPath + $mongo.MongoDBKeyFile)
            Ensure          = 'Present'
            Force           = $true
            Type            = 'File'
            DependsOn       = '[Archive]UnzipMongoPackage'
            Checksum        = 'ModifiedDate'
            MatchSource     = $true
        }

        File MongoDBServerFolder_MongoDBPEMKeyFile {
            DestinationPath = $($mongo.MongoDBServerFolder + '\' + $mongo.MongoDBPEMKeyFile)
            SourcePath      = $($unzipPath + $mongo.MongoDBPEMKeyFile)
            Ensure          = 'Present'
            Force           = $true
            Type            = 'File'
            DependsOn       = '[Archive]UnzipMongoPackage'
            Checksum        = 'ModifiedDate'
            MatchSource     = $true
        }

        File MongoDBServerFolder_MongoDBCAFile {
            DestinationPath = $($mongo.MongoDBServerFolder + '\' + $mongo.MongoDBCAFile)
            SourcePath      = $($unzipPath + $mongo.MongoDBCAFile)
            Ensure          = 'Present'
            Force           = $true
            Type            = 'File'
            DependsOn       = '[Archive]UnzipMongoPackage'
            Checksum        = 'ModifiedDate'
            MatchSource     = $true
        }

        File MongoDBServerFolder_MongoDBClientPFXFile {
            DestinationPath = $($mongo.MongoDBServerFolder + '\client.pfx')
            SourcePath      = $($unzipPath + '\client.pfx')
            Ensure          = 'Present'
            Force           = $true
            Type            = 'File'
            DependsOn       = '[Archive]UnzipMongoPackage'
            Checksum        = 'ModifiedDate'
            MatchSource     = $true
        }

        File MongoDBConfigFolder_MongoDBConfigFile {
            DestinationPath = $($mongo.MongoDBConfigFolder + '\' + $mongo.MongoDBConfigFile)
            SourcePath      = $($unzipPath + $mongo.MongoDBConfigFile)
            Ensure          = 'Present'
            Force           = $true
            Type            = 'File'
            DependsOn       = '[Archive]UnzipMongoPackage'
            Checksum        = 'ModifiedDate'
            MatchSource     = $true
        }

        xFirewall MongoDBFirewall {
            Direction   = 'Inbound'
            Name        = 'MongoDbRules'
            DisplayName = 'MongoDbRules'
            Program     = $($mongo.MongoDbInstallationBinPath + '\mongod.exe')
            Enabled     = $true
            Action      = 'Allow'
            Protocol    = 'TCP'
            LocalPort   = $currentReplicationPartner.Port
        }
               
        foreach ($rp in $mongo.ReplicationPartners) {
            xHostsFile $('HostEntry' + $rp.bindIp) {
                HostName  = $rp.HostName
                IPAddress = $rp.bindIp
                Ensure    = "Present"
            }
        }

        Script MongoConfigMacros {
            SetScript  = {
                $configContent = Get-Content -Raw $($using:mongo.MongoDBConfigFolder + '\' + $using:mongo.MongoDBConfigFile)        
        
                $configContent = $configContent.Replace("{bindIp}", $using:currentReplicationPartner.bindIp)
                $configContent = $configContent.Replace("{DatabasePort}", $using:currentReplicationPartner.Port)
                $configContent = $configContent.Replace("{MongoDBServerFolder}", $using:mongo.MongoDBServerFolder)
                $configContent = $configContent.Replace("{MongoDBPEMKeyFile}", $using:mongo.MongoDBPEMKeyFile)
                $configContent = $configContent.Replace("{MongoDBCAFile}", $using:mongo.MongoDBCAFile)
                $configContent = $configContent.Replace("{MongoDBKeyFile}", $using:mongo.MongoDBKeyFile)
                $configContent = $configContent.Replace("{MongoDBDataFolder}", $using:mongo.MongoDBDataFolder)
                $configContent = $configContent.Replace("{MongoDBLogsFolder}", $using:mongo.MongoDBLogsFolder)
                $configContent = $configContent.Replace("{MongoDBServiceName}", $using:mongo.MongoDBServiceName)
                $configContent = $configContent.Replace("{MongoDBConfigFolder}", $using:mongo.MongoDBConfigFolder)
                 
                Set-Content -Path $($using:mongo.MongoDBConfigFolder + '\' + $using:mongo.MongoDBConfigFile) -Value $configContent
            }
            GetScript  = {
                return $true
            }
            TestScript = {
                return $false
            }
            DependsOn  = '[File]MongoDBConfigFolder_MongoDBConfigFile'
        }

        Package InstallMongo {
            Ensure    = 'Present'
            Path      = $($unzipPath + $mongo.InstallerExecutable)
            Name      = $mongo.InstallerProductName
            ProductId = $mongo.InstallerProductId
            Arguments = $mongo.InstallerCommandlineArguments
            DependsOn = '[Archive]UnzipMongoPackage'
        } 

        Script Pause {
            SetScript  = {
                Start-Sleep -Seconds 5
            }
            GetScript  = {
                return $true
            }
            TestScript = {
                return $false
            }
            DependsOn  = '[Package]InstallMongo'
        }

        Service DeleteDefaultMongoService {
            Name      = 'MongoDB'
            State     = 'Stopped'
            Ensure    = 'Absent'
            DependsOn = '[Package]InstallMongo'
        }

        Script InstallMongoService {
            SetScript  = {
                Start-Sleep -Seconds 10
                $cmd = $('&"' + 
                    $using:mongo.MongoDbInstallationBinPath + 
                    '\mongod.exe" --config ' + 
                    $using:mongo.MongoDBConfigFolder + 
                    '\' + 
                    $using:mongo.MongoDBConfigFile + 
                    ' --serviceName ' + 
                    $using:mongo.MongoDBServiceName + 
                    ' --serviceDisplayName ' + 
                    $using:mongo.MongoDBServiceName + 
                    ' --serviceDescription ' + 
                    $using:mongo.MongoDBServiceName + 
                    ' --install')
                Invoke-Expression -Command "$cmd" -Verbose
                Start-Sleep -Seconds 5
            }
            GetScript  = {
                return $true
            }
            TestScript = {
                (Get-Service | Where-Object { $_.Name -eq $using:mongo.MongoDBServiceName }).Count -gt 0
            }
            DependsOn  = '[Service]DeleteDefaultMongoService'
        }

        Service EnableMongoService {
            Name        = $mongo.MongoDBServiceName
            State       = 'Running'
            Ensure      = 'Present'           
            StartupType = 'Automatic'
            DependsOn   = '[Script]InstallMongoService'
        }
    }
}

configuration Replication
{
    param
    (
        $mongo
    )
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    $primaryReplicationPartner = $mongo.ReplicationPartners | Where-Object { $_.bindIp -eq $mongo.PrimaryIP }
    $arbiterReplicationPartner = $mongo.ReplicationPartners | Where-Object { $_.bindIp -eq $mongo.ArbiterIP }

    Node $mongo.PrimaryIP
    {
        Script ReplicationCommands {
            SetScript  = {
                $query = 'rs.initiate();'
                $result = $('&"' + $using:mongo.MongoDbInstallationBinPath + '\mongo.exe" --eval "' + $query + '" --quiet 2>&1')
                write-warning $result
                $result = Invoke-Expression -Command "$result"
                Start-Sleep -Seconds 3
                #write-warning ($result | ConvertTo-Json)

            
                $query = $('cnf = rs.config();cnf.members[0].host = ''' + $using:primaryReplicationPartner.HostName + ':' + $using:primaryReplicationPartner.Port + ''';rs.reconfig(cnf);')
                $result = $('&"' + $using:mongo.MongoDbInstallationBinPath + '\mongo.exe" --eval "' + $query + '" --quiet 2>&1')
                write-warning $result
                $result = Invoke-Expression -Command "$result"
                Start-Sleep -Seconds 3
                #write-warning ($result | ConvertTo-Json)

                foreach ($rs in $using:mongo.ReplicationPartners) {
                    if ($rs.bindIp -ne $using:mongo.PrimaryIP -and $rs.bindIp -ne $using:mongo.ArbiterIP) {
                        $query = $('rs.add (''' + $rs.HostName + ':' + $rs.Port + ''');')
                        $result = $('&"' + $using:mongo.MongoDbInstallationBinPath + '\mongo.exe" --eval "' + $query + '" --quiet 2>&1')
                        write-warning $result
                        $result = Invoke-Expression -Command "$result"
                        Start-Sleep -Seconds 3
                        #write-warning ($result | ConvertTo-Json)
                    }
                }

                $query = 'rs.addArb(''' + $using:arbiterReplicationPartner.HostName + ':' + $using:arbiterReplicationPartner.Port + ''');'
                $result = $('&"' + $using:mongo.MongoDbInstallationBinPath + '\mongo.exe" --eval "' + $query + '" --quiet 2>&1')
                write-warning $result
                $result = Invoke-Expression -Command "$result"
                Start-Sleep -Seconds 3
                #write-warning ($result | ConvertTo-Json)

                $query = 'rs.status();'
                $result = $('&"' + $using:mongo.MongoDbInstallationBinPath + '\mongo.exe" --eval "' + $query + '" --quiet 2>&1')
                $result = Invoke-Expression -Command "$result"
                Start-Sleep -Seconds 3
                #write-warning ($result | ConvertTo-Json)

                if ($LASTEXITCODE -ne 0) {
                    write-warning 'MongoDbReplicationSet commands execution was not successful'
                    #write-warning ($result | convertto-json)
                }
                else {
                    write-warning 'MongoDbReplicationSet commands execution was successful'
                    #write-warning ($result | ConvertTo-Json)                    
                }

            }
            GetScript  = {
                return $true
            }
            TestScript = {
                return $false
            }
        }
    }
}

configuration Authentication
{
    param
    (
        $mongo,
        $mongoDBs
    )
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    $primaryReplicationPartner = $mongo.ReplicationPartners | Where-Object { $_.bindIp -eq $mongo.PrimaryIP }

    Node $mongo.PrimaryIP
    {
        Script AuthenticationCommands {
            SetScript  = {



                function CreateUsers {
                    param(
                        $isReplicated,
                        $serviceName,
                        $binPath,
                        $hostName,
                        $portNumber,
                        $databaseName,
                        $userName,
                        $dbPassword
                    )
                    process {
                        if ($isReplicated -eq $true) {                 
                            $result = $('&"' + $binPath + '\mongo.exe" --host "' + $serviceName + 'RS/' + $hostName + ':' + $portNumber + '" --authenticationDatabase "' + $databaseName + '" --eval "db.getSiblingDB(''' + $databaseName + ''').createUser({user: ''' + $userName + ''', ''pwd'': ''' + $dbPassword + ''', roles : [{role: ''readWrite'', db: ''' + $databaseName + '''},{role: ''dbAdmin'', db: ''' + $databaseName + '''}]})" --quiet 2>&1')
                        }
                        else {
                            $result = $('&"' + $binPath + '\mongo.exe" --host "' + $hostName + ':' + $portNumber + '" --authenticationDatabase "' + $databaseName + '" --eval "db.getSiblingDB(''' + $databaseName + ''').createUser({user: ''' + $userName + ''',pwd: ''' + $dbPassword + ''',roles:[{role: ''readWrite'', db: ''' + $databaseName + '''},{role: ''dbAdmin'', db: ''' + $databaseName + '''}]} )" --quiet 2>&1')                
                        }
                    }
                    end {
                        Write-Warning $result
                        $result = Invoke-Expression -Command "$result"
                        Start-Sleep -Seconds 1
                        #write-warning ($result | ConvertTo-Json)
            
                        if ($LASTEXITCODE -ne 0) {
                            write-warning $('MongoDbAuthenticationSet commands execution for ' + $databaseName + ' user was not successful')
                        }
                        else {
                            write-warning $('MongoDbAuthenticationSet commands execution for ' + $databaseName + ' user was successful')
                        }
                    }
                }



                if ($using:mongo.IsReplicated -eq $true) {
                    $result = $('&"' + $using:mongo.MongoDbInstallationBinPath + '\mongo.exe" --host "' + $using:mongo.MongoDBServiceName + 'RS/' + $using:primaryReplicationPartner.HostName + ':' + $using:primaryReplicationPartner.Port + '" --authenticationDatabase "admin" --eval "db.getSiblingDB(''admin'').createUser({user: ''' + $using:mongo.DBAdminUserName + ''',pwd: ''' + $using:mongo.DBAdminPassword + ''',roles:[{ role: ''dbOwner'', db: ''admin'' },{ role: ''readWrite'', db:''admin'' },{role: ''root'', db:''admin'' },{role: ''__system'', db:''admin'' }]} )" --quiet 2>&1')

                    Write-Warning $result
                    $result = Invoke-Expression -Command "$result"
                    Start-Sleep -Seconds 1
                    #write-warning ($result | ConvertTo-Json)

                    if ($LASTEXITCODE -ne 0) {
                        write-warning 'MongoDbAuthenticationSet commands execution for admin user was not successful'
                        #write-warning ($result | convertto-json)
                    }
                    else {
                        write-warning 'MongoDbAuthenticationSet commands execution for admin user was successful'
                        #write-warning ($result | ConvertTo-Json)                    
                    }
                }
                else {
                    $result = $('&"' + $using:mongo.MongoDbInstallationBinPath + '\mongo.exe" --host "' + $using:primaryReplicationPartner.HostName + ':' + $using:primaryReplicationPartner.Port + '" --authenticationDatabase "admin" --eval "db.getSiblingDB(''admin'').createUser({user: ''' + $using:mongo.DBAdminUserName + ''',pwd: ''' + $using:mongo.DBAdminPassword + ''',roles:[{ role: ''dbOwner'', db: ''admin'' },{ role: ''readWrite'', db:''admin'' },{role: ''root'', db:''admin'' },{role: ''__system'', db:''admin'' }]} )" --quiet 2>&1')
                    
                    Write-Warning $result
                    $result = Invoke-Expression -Command "$result"
                    Start-Sleep -Seconds 1
                    #write-warning ($result | ConvertTo-Json)

                    if ($LASTEXITCODE -ne 0) {
                        write-warning 'MongoDbAuthenticationSet commands execution for admin user was not successful'
                        #write-warning ($result | convertto-json)
                    }
                    else {
                        write-warning 'MongoDbAuthenticationSet commands execution for admin user was successful'
                        #write-warning ($result | ConvertTo-Json)                    
                    }


                }

            }
            GetScript  = {
                return $true
            }
            TestScript = {
                return $false
            }
        }
    }
}

configuration UncommentConfigMacros
{
    param
    (
        [string]$nodeName = '',
        $mongo,
        [string]$region = ''
    )
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'

    Node $nodeName
    {
        Script MongoConfigMacros {
            SetScript  = {   
            
                Stop-Service -Name $using:mongo.MongoDBServiceName -Force -NoWait -Verbose
                  
                $configContent = Get-Content -Raw $($using:mongo.MongoDBConfigFolder + '\' + $using:mongo.MongoDBConfigFile)

                if ($using:region -eq 'IsReplicated') {       
                    $configContent = $configContent.Replace("#{IsReplicated}", "")
                }
                if ($using:region -eq 'IsAuthenticated') {       
                    $configContent = $configContent.Replace("#{IsAuthenticated}", "")
                }
                if ($using:region -eq 'IsSSL') {       
                    $configContent = $configContent.Replace("#{IsSSL}", "")
                }


                Set-Content -Path $($using:mongo.MongoDBConfigFolder + '\' + $using:mongo.MongoDBConfigFile) -Value $configContent

                Start-Service -Name $using:mongo.MongoDBServiceName -Verbose
            }
            GetScript  = {
                return $true
            }
            TestScript = {
                return $false
            }
        }
    }

}



function GetCredentials {
    param(
        $node
    )
    process {
        [securestring]$password = ConvertTo-SecureString $node.Password -AsPlainText -Force
        $credentials = New-Object System.Management.Automation.PSCredential ($node.UserName, $password)
    }
    end {
        return $credentials
    }
}

function MongoDeployment {
    begin { 
        $mongo = (Get-Content -Raw -Path $ConfigFile | ConvertFrom-Json).Resources.MongoInstance
        $mongo.ReplicationPartners = $mongo.ReplicationPartners | Where-Object { $_.bindIp -ne '' }
        $mongoDBs = (Get-Content -Raw -Path $ConfigFile | ConvertFrom-Json).Resources.MongoDbRestore.DatabaseName

        if (Test-Path -Path $mofPath) {
            Remove-Item -Path  $mofPath -Force -Recurse
        }
        Start-Transcript -Path $((Split-Path (Split-Path $mofPath -Parent) -Parent) + '\Logs\InstallMongo_' + (Get-Date -Format "yyyyMMdd_HHmm") + '.log')
    }
    process {
        if ($mongo.IsDeploymentEnabled -eq $true) {
            #Building mof - ConfigureMongo
            foreach ($node in $mongo.ReplicationPartners) {
                $cd = @{
                    AllNodes = @(
                        @{
                            NodeName                    = $node.bindIp
                            PSDscAllowPlainTextPassword = $true
                            PSDscAllowDomainUser        = $true
                        }
                    )
                } 

                $mycreds = GetCredentials -node $node
                Write-Host
                Write-Host $('Building MOF for ConfigureMongo ' + $node.bindIp) -BackgroundColor Red
                ConfigureMongo -nodeName $node.bindIp -mongo $mongo  -OutputPath $($mofPath + '\ConfigureMongo\') -PsDscRunAsCredential $mycreds -ConfigurationData $cd
            }

            #Building mof - Replication
            if ($mongo.IsReplicated -eq $true) {

                foreach ($node in $mongo.ReplicationPartners) {
                    Write-Host
                    Write-Host $('Building MOF for IsReplicatedMacros ' + $node.bindIp) -BackgroundColor Green
                    UncommentConfigMacros -nodeName $node.bindIp -mongo $mongo -region 'IsReplicated' -OutputPath $($mofPath + '\IsReplicatedMacros\')
                }

                Write-Host
                Write-Host $('Building MOF for Replication on primary node ' + $mongo.PrimaryIP) -BackgroundColor Blue
                Replication -mongo $mongo  -OutputPath $($mofPath + '\Replication\')
            }

            #Building mof - Authentication
            if ($mongo.IsAuthenticated -eq $true) {

                Write-Host
                Write-Host $('Building MOF for Authentication on primary node ' + $mongo.PrimaryIP) -BackgroundColor Blue
                Authentication -mongo $mongo -mongoDBs $mongoDBs -OutputPath $($mofPath + '\Authentication\')

                foreach ($node in $mongo.ReplicationPartners) {
                    Write-Host
                    Write-Host $('Building MOF for IsAuthenticatedMacros ' + $node.bindIp) -BackgroundColor Green
                    UncommentConfigMacros -nodeName $node.bindIp -mongo $mongo -region 'IsAuthenticated' -OutputPath $($mofPath + '\IsAuthenticatedMacros\')
                }
            }

            #Building mof - SSL
            if ($mongo.IsSSL -eq $true) {

                foreach ($node in $mongo.ReplicationPartners) {
                    Write-Host
                    Write-Host $('Building MOF for IsSSLMacros ' + $node.bindIp) -BackgroundColor Green
                    UncommentConfigMacros -nodeName $node.bindIp -mongo $mongo -region 'IsSSL' -OutputPath $($mofPath + '\IsSSLMacros\')
                }
            }
        }
    }
    end {
        if ($mongo.IsDeploymentEnabled -eq $true) {

            #Starting dsc - ConfigureMongo
            foreach ($node in $mongo.ReplicationPartners) {
                Write-Host
                Write-Host $('DSC execution started for ConfigureMongo ' + $node.bindIp) -BackgroundColor Red

                $mycreds = GetCredentials -node $node
                Start-DscConfiguration -ComputerName $node.bindIp -Credential $mycreds -Path $($mofPath + '\ConfigureMongo\') -Wait -Force -Verbose 
            }

            #Starting dsc - Replication
            if ($mongo.IsReplicated -eq $true) {
                foreach ($node in $mongo.ReplicationPartners) {
                    Write-Host
                    Write-Host $('DSC execution started for IsReplicatedMacros ' + $node.bindIp) -BackgroundColor Green

                    $mycreds = GetCredentials -node $node
                    Start-DscConfiguration -ComputerName $node.bindIp -Credential $mycreds -Path $($mofPath + '\IsReplicatedMacros\') -Wait -Force -ErrorAction Stop
                }
                Write-Host
                Write-Host $('DSC execution started for Replication on primary node ' + $mongo.PrimaryIP) -BackgroundColor Blue
                $primaryReplicationPartner = $mongo.ReplicationPartners | Where-Object { $_.bindIp -eq $mongo.PrimaryIP }            

                $mycreds = GetCredentials -node $primaryReplicationPartner
                Start-DscConfiguration -ComputerName $mongo.PrimaryIP -Credential $mycreds -Path $($mofPath + '\Replication\') -Wait -Force -Verbose -ErrorAction Stop
            }

            #Starting dsc - Authentication
            if ($mongo.IsAuthenticated -eq $true) {
                Write-Host
                Write-Host $('DSC execution started for Authentication on primary node ' + $mongo.PrimaryIP) -BackgroundColor Blue
                $primaryReplicationPartner = $mongo.ReplicationPartners | Where-Object { $_.bindIp -eq $mongo.PrimaryIP }            

                $mycreds = GetCredentials -node $primaryReplicationPartner
                Start-DscConfiguration -ComputerName $mongo.PrimaryIP -Credential $mycreds -Path $($mofPath + '\Authentication\') -Wait -Force -Verbose -ErrorAction Stop

                foreach ($node in $mongo.ReplicationPartners) {
                    Write-Host
                    Write-Host $('DSC execution started for IsAuthenticatedMacros ' + $node.bindIp) -BackgroundColor Green

                    $mycreds = GetCredentials -node $node
                    Start-DscConfiguration -ComputerName $node.bindIp -Credential $mycreds -Path $($mofPath + '\IsAuthenticatedMacros\') -Wait -Force -ErrorAction Stop
                }
            }

            #Starting dsc - SSL
            if ($mongo.IsSSL -eq $true) {
                foreach ($node in $mongo.ReplicationPartners) {
                    Write-Host
                    Write-Host $('DSC execution started for IsSSLMacros ' + $node.bindIp) -BackgroundColor Green

                    $mycreds = GetCredentials -node $node
                    Start-DscConfiguration -ComputerName $node.bindIp -Credential $mycreds -Path $($mofPath + '\IsSSLMacros\') -Wait -Force -ErrorAction Stop
                }
            }
        }
        
        Stop-Transcript
    }
}
MongoDeployment