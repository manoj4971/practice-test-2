﻿param(
    [string] $ConfigFile = "",
    [bool]$splitMOFs = $true,
    [bool]$saveMOFs = $true
    
)

begin {
    #Clear-Host
    
    Set-StrictMode -Version 5.0
    
    $LogFilePath = ".\logs\myWizardDeployLinux_" + (Get-Date -Format "yyyyMMddHHmm") + ".log"
    
    filter timestamp {"$(Get-Date -Format "MM/dd/yyyy hh:mm:ss:fff tt"): $_"}
    
    $paramsJson = Get-Content -Raw -Path $ConfigFile | ConvertFrom-Json
    
    $apps = Get-Content -Raw -Path $((Split-Path $PSCommandPath -Parent) + '\apps.json') | ConvertFrom-Json
    Start-Transcript -Path $LogFilePath

}

process {
    try {
   
        $configuredCount = 0
        # iterate through the servers
        foreach ($server in $paramsJson.Servers) {
            if ($server.Configure -eq $true) {
                # build credentials
                $securePassword = ConvertTo-SecureString $server.AdminPassword -AsPlainText -Force
                $credential = New-Object pscredential($server.AdminUser, $securePassword)

                # start-dscconfiguration
                $serverName = $server.ServerName
                $configurationPath = $server.ConfigurationPath
    
                # create OMI session    
                $opt = New-CimSessionOption -UseSsl -SkipCACheck -SkipCNCheck -SkipRevocationCheck -Verbose
                $session = New-CimSession -Credential $credential -ComputerName $serverName -Port "5986" -Authentication Basic -SessionOption $opt -Verbose -OperationTimeoutSec 3000
                Write-Output "OMI session established for $serverName." | timestamp
                Write-Output "Beginning configuration of $serverName." | timestamp
                

                #execute mofs without splitting
                if($splitMOFs -eq $false)
                {
                    Set-Content -Path "$configurationPath\$serverName.mof" -Value (Get-Content -Raw -Path "$configurationPath\$serverName.mof" -Encoding UTF8)
                    Start-DscConfiguration -CimSession $session -Path $configurationPath -Wait -Force                    
                }


                #split mofs and execute
                if($splitMOFs -eq $true)
                {
                    #create backup folder
                    If (-not (Test-Path "$configurationPath\backup")) 
                    {
                        New-Item -Path "$configurationPath\backup" -Force -ItemType Directory -ErrorAction SilentlyContinue
                    }
                    #create savedmof folder
                    if (($saveMOFs -eq $true) -and (-not(Test-Path "$configurationPath\SavedMOF")))
                    {
                        New-Item -Path "$configurationPath\SavedMOF" -Force -ItemType Directory -ErrorAction SilentlyContinue
                    }

                    $mofContent = Get-Content -Raw -Path "$configurationPath\$serverName.mof"
                    Set-Content -Path "$configurationPath\backup\$serverName$(Get-Date -Format "_yyyyMMddHHmmss").mof" -Value $mofContent -Encoding UTF8 -Force
                    $mofLastSection = $mofContent.Substring($mofContent.IndexOf("instance of OMI_ConfigurationDocument"))

                    foreach($appName in $apps)
                    {
                        $elapsed = [System.Diagnostics.Stopwatch]::StartNew()
                        #if($mofContent -imatch $appName)
                        if($mofContent.Contains($appName))
                        {
                            Write-Host "Executing MOF for $appName started @$(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')" -BackgroundColor Green -ForegroundColor Black

                            $firstAppearance = $mofContent.IndexOf($appName)
                            $lastAppearance = $mofContent.LastIndexOf($appName)
                            $begin = $mofContent.Substring(0,$firstAppearance).LastIndexOf('instance of MSFT_')
                            $end = $mofContent.Substring($lastAppearance).IndexOf('};') + "};".Length

                            #if($saveMOFs -eq $true)
                            #{
                            #    Write-Host "firstAppearance : " $firstAppearance
                            #    Write-Host "lastAppearance : " $lastAppearance
                            #    Write-Host "begin : " $begin
                            #    Write-Host "end : " $end
                            #}

                            if($firstAppearance -gt -1)
                            {
                                $appMOF = $mofContent.Substring($begin, $lastAppearance+$end-$begin)
                                Set-Content -Path "$configurationPath\$serverName.mof" -Value $appMOF -Encoding UTF8 -Force
                                Add-Content -Path "$configurationPath\$serverName.mof" -Value $mofLastSection

                                if($saveMOFs -eq $true)
                                {
                                    Set-Content -Path "$configurationPath\SavedMOF\$appName.txt" -Value $appMOF -Encoding UTF8 -Force
                                    Add-Content -Path "$configurationPath\SavedMOF\$appName.txt" -Value $mofLastSection
                                }

                                $mofContent = $mofContent.Replace($appMOF,"")
                                Start-DscConfiguration -CimSession $session -Path $configurationPath -Wait -Force
                            }
        
                            Write-Host "Executing MOF for $appName complete, took $($elapsed.Elapsed.Hours.ToString())h $($elapsed.Elapsed.Minutes.ToString())m $($elapsed.Elapsed.Seconds.ToString())s"
                            Write-Host
                        }
                    }

                    Write-Host "Executing MOF for remaining DSCs started @$(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')" -BackgroundColor Green -ForegroundColor Black
                    $elapsed = [System.Diagnostics.Stopwatch]::StartNew()
                    Set-Content -Path "$configurationPath\$serverName.mof" -Value $mofContent
                    if($saveMOFs -eq $true)
                    {
                        Set-Content -Path "$configurationPath\SavedMOF\Remaining.txt" -Value $mofContent
                    }
                    Start-DscConfiguration -CimSession $session -Path $configurationPath -Wait -Force
                    Write-Host "Executing MOF for remaining DSCs complete, took $($elapsed.Elapsed.Hours.ToString())h $($elapsed.Elapsed.Minutes.ToString())m $($elapsed.Elapsed.Seconds.ToString())s" 

                }

                $configuredCount += 1
                Write-Host
            }
        }

        #Write-output "Configured [$configuredCount] machines." | timestamp
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        Write-Output "An exception occurred: $ErrorMessage" | timestamp
    }
}
end {
    Stop-Transcript
    Write-Host
	Write-Host "Completed, you can close this window" -BackgroundColor DarkGreen
}