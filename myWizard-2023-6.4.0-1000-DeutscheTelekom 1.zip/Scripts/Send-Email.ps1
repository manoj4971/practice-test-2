﻿param (
    $subject = "",
    $to = "",
    $emailBody = "",
    $attachments = ""
)
begin {
    Clear-Host
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $from = "OneClick Installer <oneclick@mywizard360.com>"
    $smtp = "email-smtp.us-east-1.amazonaws.com"
    $port = 587
    [securestring]$param = ConvertTo-SecureString 'BDPcatF9k7BrUac8OfW0vzq2YYPfEs1AnbujyqA20VOP' -AsPlainText -Force
    $cred = New-Object System.Management.Automation.PSCredential ('AKIASLNFXDCIMFECR5PM', $param)
    [string[]]$to = $to -split ','

    if($attachments.Trim().Length -le 0) {
        [string[]]$attachments = $null
    }
    else {
        [string[]]$attachments = $attachments -split ','
    }
}
process {
    if ($attachments.Count -gt 0) {
        Send-MailMessage -From $from -To $to -Subject $subject -Body $emailBody -BodyAsHtml -UseSsl -Credential $cred -SmtpServer $smtp -Port $port -Attachments $attachments -Cc @($($env:USERNAME + "@accenture.com"))
    }
    else {
        Send-MailMessage -From $from -To $to -Subject $subject -Body $emailBody -BodyAsHtml -UseSsl -Credential $cred -SmtpServer $smtp -Port $port -Cc @($($env:USERNAME + "@accenture.com"))
    }
}
    
