IP=$(hostname -I|cut -d" " -f 1)

mkdir -p /etc/systemd/system/MyWIzard
mkdir -p /var/www/Logs/OCI.Cryptography
logfile=$IP-CryptoLog-`date "+%Y%m%d%H%M"`.log
while read line
do 
if [[ $line == *"IntelligentReleasePlanner"* ]]; then

cd /etc/tomcat9/conf/IntelligentReleasePlanner
echo "Updating the EncryptionEnabled flag for the file " $line

echo "Running the decryption for" $line
java -jar -Dmode="AES/CBC/PKCS5PADDING" ./application-common-cryptography.jar --sourcePropertyFile ./application.properties  --destinationPropertyFile ./application.properties --operation decrypt --configFile ./app.json --overwriteDestinationPropertyFile true
sed -i 's|EncryptionEnabled=true|EncryptionEnabled=false|g' application.properties
systemctl restart tomcat

elif [[ $line == *"RequirementReadinessAssistant"* ]]; then

cd /etc/tomcat9/conf/RequirementReadinessAssistant
echo "Updating the EncryptionEnabled flag for the file " $line
echo "Running the decryption for" $line
java -jar -Dmode="AES/CBC/PKCS5PADDING" ./application-common-cryptography.jar --sourcePropertyFile ./application.properties  --destinationPropertyFile ./application.properties --operation decrpyt --configFile ./app.json --overwriteDestinationPropertyFile true
sed -i 's|EncryptionEnabled=true|EncryptionEnabled=false|g' application.properties
systemctl restart tomcat

elif [[ $line == *"StorySlicing"* ]]; then

cd /etc/tomcat9/conf/StorySlicing
echo "Updating the EncryptionEnabled flag for the file " $line
echo "Running the decryption for" $line
java -jar -Dmode="AES/CBC/PKCS5PADDING" ./application-common-cryptography.jar --sourcePropertyFile ./application.properties  --destinationPropertyFile ./application.properties --operation decrpyt --configFile ./app.json --overwriteDestinationPropertyFile true
sed -i 's|EncryptionEnabled=true|EncryptionEnabled=false|g' application.properties
systemctl restart tomcat

elif [[ $line == *"RequirementsTraceabilityAssistant.AIModel"* ]]; then

echo "Running the decryption for" $line
cd /var/www/myWizard.RequirementsTraceabilityAssistant.AIModel/pythonscripts
python3.7 decryptor.py

echo "Decrypting the confg files mentioned in " $line/app.json
sudo dotnet /var/www/appConfigFiles/OCI.Cryptography/myWizard.OCI.Cryptography.Console.dll /var/www/$line/app.json decrypt
echo "Updating the EncryptionEnabled flag for the file " $line/app.json
sed -i 's|true|false|g' /var/www/$line/app.json

elif [[ $line == *"RequirementsTraceabilityAssistant.MetricModel"* ]]; then

echo "Running the decryption for" $line
cd /var/www/myWizard.RequirementsTraceabilityAssistant.MetricModel/pythonscripts
python3.7 decryptor.py

echo "Decrypting the confg files mentioned in " $line/app.json
sudo dotnet /var/www/appConfigFiles/OCI.Cryptography/myWizard.OCI.Cryptography.Console.dll /var/www/$line/app.json decrypt
echo "Updating the EncryptionEnabled flag for the file " $line/app.json
sed -i 's|true|false|g' /var/www/$line/app.json

elif [[ $line == *"IngrAIn.SelfServiceAI"* ]]; then

echo "Running the decryption for" $line
cd /var/www/myWizard.IngrAIn.SelfServiceAI/IngrAIn_Python/main
sh encryptPythonfile.sh -d

elif [[ $line == *"WebAPI.Python"* ]]; then

echo "Running the decryption for" $line
cd $line
sh toggle_encryption.sh -d

else


echo "Decrypting the confg files mentioned in " $line/app.json
sudo dotnet /var/www/appConfigFiles/OCI.Cryptography/myWizard.OCI.Cryptography.Console.dll /var/www/$line/app.json decrypt
echo "Updating the EncryptionEnabled flag for the file " $line/app.json
sed -i 's|true|false|g' /var/www/$line/app.json

fi
systemctl restart $line
done < /mnt/win/OneClickTools/Decrypt.txt

yes | cp /var/www/Logs/OCI.Cryptography/$logfile /mnt/win/OneClickTools/Logs