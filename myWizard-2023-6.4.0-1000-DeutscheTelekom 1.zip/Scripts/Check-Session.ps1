﻿param (
[Parameter(Mandatory = $true)]
    $Node = "",

    [Parameter(Mandatory = $true)]
    $userName = "",

    [Parameter(Mandatory = $true)]
    $password = ''
)
begin {
    clear-host
}
process {
    [securestring]$pwd = ConvertTo-SecureString $password -AsPlainText -Force
    $Credential = New-Object System.Management.Automation.PSCredential ($userName, $pwd)
    $opt = New-CimSessionOption -UseSsl -SkipCACheck -SkipCNCheck -SkipRevocationCheck
    $Sess=New-CimSession -Credential $credential -ComputerName $Node -Port 5986 -Authentication basic -SessionOption $opt -OperationTimeoutSec 3
}