#!/bin/bash
sudo yum install -y mongodb-org-shell

