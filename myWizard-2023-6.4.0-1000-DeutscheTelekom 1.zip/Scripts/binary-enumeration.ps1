﻿param (
    [Parameter(Mandatory = $true)]
    $nodeName = "Count",
    [Parameter(Mandatory = $true)]
    [ValidateSet("Count", "Full")]
    $reportType = "Count"
)



function Get-Data {
    param (
        $rootFolder
    )
    process {
        if ($reportType -eq "Count") {
            if(Test-Path -Path $rootFolder) {
                return Get-ChildItem -Path $rootFolder -Directory | 
                Where-Object { $_.FullName -notmatch "appConfigFiles" -and 
                    $_.FullName -notmatch "Logs" -and 
                    $(if($rootFolder -match "GatewayManager") {$_.FullName -match "GatewayManager"} else {$_.FullName -notmatch "GatewayManager"}) -and 
                    $_.FullName -notmatch "venv" } |
                ForEach-Object { 
                    $appName = $_.Name 
                    Get-ChildItem -Path $_.FullName -File -Recurse | 
                    Group-Object Extension | 
                    Select-Object  @{n = "AppName"; e = { $appName } }, 
                    @{n = "Extension"; e = { $_.Name } }, 
                    @{n = "Count"; e = { $_.Count } }
                }
            }
        }
        elseif ($reportType -eq "Full") {
            if(Test-Path -Path $rootFolder) {
                return Get-ChildItem -Path $rootFolder -Directory | 
                Where-Object { $_.FullName -notmatch "appConfigFiles" -and 
                    $_.FullName -notmatch "Logs" -and 
                    $(if($rootFolder -match "GatewayManager") {$_.FullName -match "GatewayManager"} else {$_.FullName -notmatch "GatewayManager"}) -and 
                    $_.FullName -notmatch "venv" } |
                ForEach-Object { 
                    $appName = $_.Name 
                    Get-ChildItem -Path $_.FullName -File -Recurse | 
                    Group-Object DirectoryName, Extension | 
                    Select-Object  @{n = "AppName"; e = { $appName } }, 
                    @{n = "Path"; e = { (($_.Name -split ",")[0]).Replace($rootFolder, "") } }, 
                    @{n = "Extension"; e = { ($_.Name -split ",")[1] } }, 
                    @{n = "Count"; e = { $_.Count } }
                }
            }
        }
    }
}

function Build-Html {
    param (
        [string[]]$rootFolder
    )
    begin {
        foreach ($path in $rootFolder) {
            $appStats += Get-Data -rootFolder $path
        }
    }
    process {
        if($appStats.Count -gt 0) {        
            $apps = $($appStats | Select-Object -ExpandProperty AppName -Unique)

            $html = @()
            $html += '<table style="margin: auto auto;padding:0;width: 80%;border-collapse: collapse;font-family: calibri;">'
            foreach ($app in $apps) {
                $html += '<tr style="background-color: skyblue;font-weight: bold;"><td colspan="3" style="border:1px solid silver">' + $app + '</td></tr>'

                $appDetails = $appStats | Where-Object { $_.AppName -eq $app }

                foreach ($detail in $appDetails) {
                    if ($reportType -eq "Count") {
                        $html += '<tr><td style="border:1px solid silver">' + $detail.Extension + '</td> <td style="border:1px solid silver">' + $detail.Count + '</td></tr>'
                    }
                    elseif ($reportType -eq "Full") {
                        $html += '<tr><td style="border:1px solid silver">' + $detail.Path + '</td> <td style="border:1px solid silver">' + $detail.Extension + '</td> <td style="border:1px solid silver">' + $detail.Count + '</td></tr>'
                    }
                }
            }
            $html += '</table>'
            return $html
        }
    }
}

function Init {
    begin {
        Clear-Host
        
    }
    process {
        $be = Build-Html -rootFolder @("/var/www/") 
        if($be.Count -gt 0) {
            $be | Set-Content $("/mnt/win/OneClickTools/Logs/binary-enumeration-"+$nodeName+".html")
        }

        $gbe = Build-Html -rootFolder @("/var/www/GatewayManager/bin", "/var/www/GatewayManager/ProcessPipelines") 
        if($gbe.Count -gt 0) {
            $gbe | Set-Content $("/mnt/win/OneClickTools/Logs/gm-binary-enumeration-"+$nodeName+".html")
        }
    }
    end {
        
    }
}


Init