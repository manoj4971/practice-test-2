#!/bin/bash

###Installing Python 3.10.11 version####
echo "Python Insatllation"

yum install wget -y
yum -y install gcc epel gcc-c++ openssl11-devel bzip2-devel sqlite-devel zlib-devel libcurl-devel sqlite libffi libffi-devel
sleep 2
cd /tmp
wget https://www.python.org/ftp/python/3.10.11/Python-3.10.11.tgz
sleep 2
tar xzf Python-3.10.11.tgz
cd Python-3.10.11
sed -i 's/PKG_CONFIG openssl /PKG_CONFIG openssl11 /g' configure
sleep 2
./configure --enable-optimizations
sleep 2
yum install make -y
make altinstall
sleep 2
####Now set up environment variable Python3.10.11#####
echo 'alias python3.10=/usr/local/bin/python3.10' >> /root/.bashrc
sleep 2
source /root/.bashrc
export PATH=$PATH:/usr/local/bin
ln -s /usr/local/bin/python3.10 /usr/bin/python3.10
ln -s /usr/local/bin/python3.10 /usr/bin/python
# check installation
python3.10 --version

####Now set up environment variable Pip3.10#####
echo 'alias pip3.10=/usr/local/bin/pip3.10' >> /root/.bashrc
source /root/.bashrc
pip3.10 -V

python3.10 -m pip install psycopg2-binary
python3.10 -m pip3 install psycopg2-binary

yum -y install python3-devel
