#!/bin/bash

###Installing Python 3.9.4 version####

echo "Python Insatllation"

yum install wget
yum install gcc openssl-devel bzip2-devel libffi libffi-devel -y
sleep 2
wget https://www.python.org/ftp/python/3.9.4/Python-3.9.4.tgz
sleep 2
tar xzf Python-3.9.4.tgz
cd Python-3.9.4
sleep 2
./configure --enable-optimizations
sleep 2
make altinstall
sleep 2
####Now set up environment variable#####
echo 'alias python3.9=/usr/local/bin/python3.9' >> /root/.bashrc
sleep 2
source /root/.bashrc
export PATH=$PATH:/usr/local/bin
ln -s /usr/local/bin/python3.9 /usr/bin/python3.9
# check installation
python3.9 --version


