######Install nginx
echo "*********Installing nginx*********"
groupadd nginx -g 9999
adduser nginx --uid 9999 --gid 9999 --comment "Nginx web server" --home /var/lib/nginx
usermod -s /sbin/nologin nginx
rm -f /etc/yum.repos.d/nginx.repo
yum -y install nginx



rm -f /etc/nginx/nginx.conf
cat > /etc/nginx/nginx.conf << EOL
# For more information on configuration, see:
# * Official English Documentation: http://nginx.org/en/docs/
# * Official Russian Documentation: http://nginx.org/ru/docs/



user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;



# Load dynamic modules. See /usr/share/nginx/README.dynamic.
include /usr/share/nginx/modules/*.conf;



events {
worker_connections 1024;
}



http {
log_format main '$remote_user [$time_local]- $status - $upstream_response_time "$request" '
'$remote_addr $body_bytes_sent "$http_referer" '
'"$http_user_agent" "$http_x_forwarded_for"';



 access_log /var/log/nginx/access.log main;



 sendfile on;
tcp_nopush on;
tcp_nodelay on;
keepalive_timeout 600;
types_hash_max_size 2048;
server_tokens off;



 include /etc/nginx/mime.types;
include /etc/nginx/proxy.conf;
#include /etc/nginx/sites-enabled/reverse-proxy.conf;
default_type application/octet-stream;



 # Load modular configuration files from the /etc/nginx/conf.d directory.
# See http://nginx.org/en/docs/ngx_core_module.html#include
# for more information.
include /etc/nginx/sites-enabled/*.conf;
server_names_hash_bucket_size 128;
server {
listen 80;
#listen [::]:80 default_server;
server_name *.aiam-dh.com;
root /usr/share/nginx/html;



 # Load configuration files for the default server block.
include /etc/nginx/default.d/*.conf;



 location / {
proxy_set_header x-real-IP \$remote_addr;
proxy_set_header x-forwarded-for \$proxy_add_x_forwarded_for;
proxy_set_header host \$host;
proxy_pass http://localhost;
include uwsgi_params;
}



 error_page 404 /404.html;
location = /40x.html {
}



 error_page 500 502 503 504 /50x.html;
location = /50x.html {
}
}



 }



EOL
rm -f /etc/nginx/proxy.conf
cat >> /etc/nginx/proxy.conf << EOL
proxy_redirect off;
proxy_set_header Host \$host;
proxy_set_header X-Real-IP \$remote_addr;
proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto \$scheme;
client_max_body_size 1024m;
client_body_buffer_size 1024k;
proxy_connect_timeout 300;
proxy_send_timeout 300;
proxy_read_timeout 300;
send_timeout 300;
proxy_buffers 4 256k;
proxy_buffer_size 128k;
proxy_busy_buffers_size 256k;
proxy_ignore_client_abort on;
large_client_header_buffers 4 32k;
EOL



mkdir /etc/nginx/sites-enabled
systemctl enable nginx
systemctl restart nginx