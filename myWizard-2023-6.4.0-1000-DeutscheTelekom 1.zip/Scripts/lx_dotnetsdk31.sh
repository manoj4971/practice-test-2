#!/bin/bash

echo "*********Installing dotnet core runtime 6.0*********"
sudo yum --disablerepo=* --enablerepo=offline.repo install dotnet-sdk-6.0 -y