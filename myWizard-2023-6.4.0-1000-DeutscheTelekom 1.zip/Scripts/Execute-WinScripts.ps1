﻿param(
    $scriptPaths = "",
    $ipAddress = "" ,
    $AdminUser = "",
    $AdminPassword = "",
    $runningFor = ""
)

begin{
    $thisPath = $(Split-Path -Path $PSCommandPath -Parent)
    $scriptPaths = $scriptPaths -replace "\s+"," " -replace " ,",","
    $scripts = $scriptPaths.Split(",")
     $logFile = $($runningFor + "_WINLog_" + $ipAddress + "_" + (Get-Date -Format "yyyyMMdd_HHmm") + ".txt")
     $logPath = $($thisPath + "\Logs\" + $logFile)
        Start-Transcript -Path $logPath -Force | Out-Null
        Clear-Host
}
process{
    foreach($script in $scripts) {
        $credentials = Get-Credential -Message $("Enter credential for " + $ipAddress) -UserName $($env:USERDOMAIN+"\"+$env:USERNAME)
        & .\Scripts\$script -ipAddress $ipAddress -AdminUser $credentials.UserName -AdminPassword $credentials.GetNetworkCredential().Password
    }
 }
end{
    Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
}


 