###Installing Python ####
echo "Python3.11 Installation"

yum -y install gcc epel-release.noarch openssl-devel gcc-c++ bzip2-devel sqlite-devel zlib-devel libcurl-devel sqlite libffi libffi-devel xz-devel lzma
yum -y install http://repos2.sopnet.com.ar/rpms/centos9/x86_64/compat-openssl10/20220817143025/compat-openssl10-1.0.2o-3.el9.0.1.x86_64.rpm
cd /tmp
wget https://www.python.org/ftp/python/3.11.5/Python-3.11.5.tgz

tar -xzf Python-3.11.5.tgz

cd Python-3.11.5 
sed -i 's/PKG_CONFIG openssl /PKG_CONFIG openssl11 /g' configure
sleep 2
./configure
sleep 2
make altinstall
sleep 2
alternatives --install /usr/bin/python3 python3 /usr/local/bin/python3.11 2
sleep 2

echo 'alias python3.11=/usr/local/bin/python3.11' >> /root/.bashrc

sleep 2

source /root/.bashrc

export PATH=$PATH:/usr/local/bin

ln -s /usr/local/bin/python3.11 /usr/bin/python3.11