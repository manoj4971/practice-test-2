#!/bin/bash

#########Install ODBC driver

echo "*********Installing ODBC drive for hive*********"
yum install unixODBC -y
cd /mnt/win/OneClickTools/Softwares/rpms
rpm -ivh postgresql-libs-9.2.24-4.el7_8.x86_64.rpm
#yum install cyrus-sasl* -y
yum install cyrus-sasl* -y
cd /mnt/win/OneClickTools/Softwares/rpms
rpm -ivh hive-odbc-native-2.6.5.1005-1.x86_64.rpm

IP=$(hostname -I|cut -d" " -f 1)
yes | cp odbc.ini /usr/lib/hive/lib/native/hiveodbc/Setup/
sed -i "s|{hadoopip}|$IP|g" /usr/lib/hive/lib/native/hiveodbc/Setup/odbc.ini

yes | cp /usr/lib/hive/lib/native/hiveodbc/Setup/odbcinst.ini /etc/
yes | cp /usr/lib/hive/lib/native/hiveodbc/Setup/odbc.ini /etc/