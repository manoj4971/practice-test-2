#!/bin/bash

aws s3 cp s3://mywizard-bootcamp-bucket/Hadoop/hadoop.tar.gz /home/centos/

tar -xvf hadoop.tar.gz

cd /home/centos/hadoop
