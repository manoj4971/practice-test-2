#!/bin/bash
#
###############################################################################################
# This script is created to Install MySQL, update password and create user for Hive metastore
# Created by Shabana
# MySQL Version 5.7
# MySQL Connector Version 8.0.18
###############################################################################################

#Setting the variable for mysql

hostname=$(hostname)
MYSQL_DOWNLOAD_URL=https://dev.mysql.com/get/mysql57-community-release-el7-9.noarch.rpm
MYSQL_JAVA_CONNECTOR=https://dev.mysql.com/get/Downloads/Connector-J/mysql-connector-java-8.0.18-1.el7.noarch.rpm
HIVE_DATABASE="hive"
NEW_PASSWORD="MyNewPass4!"

#############################################################
# Verify all the executions are successfully performed or not
# Arguments:
#   - execution information
# Return:
#   - None
##############################################################

verify_exec()
{
    if [ $? -eq 0 ]; then
        echo $1 + " - Success"
    else
        echo $1 + " - Failed"
        exit 1
    fi
}

#############################################################
# Download and Install MySQL 5.7 for Hive
#
# Arguments:
#   - None
# Return:
#   - None
##############################################################


install_MySQL()
{
    yum localinstall "$MYSQL_DOWNLOAD_URL" -y
    verify_exec "Download MySQL server"

    #Installing MySQL-Server
    yum install mysql-community-server mysql-community-client -y
    verify_exec "MySQL server and client installation"
}

#############################################################
# Get temporary password and change MySQL password
#
# Arguments:
#   - None
# Return:
#   - None
##############################################################

update_mysql_password()
{
    yum install expect -y
    temp_password=$(grep 'A temporary password' /var/log/mysqld.log |tail -1 | awk '{print $NF}')

    SECURE_MYSQL=$(expect -c "
    set timeout 10
    spawn /usr/bin/mysql_secure_installation
    expect \"Enter password for user root:\"
    send \"$temp_password\r\"
    expect \"New password:\"
    send \"$NEW_PASSWORD\r\"
    expect \"Re-enter new password:\"
    send \"$NEW_PASSWORD\r\"
    expect \"Change the password for root ?*\"
    send \"n\r\"
    expect \"Remove anonymous users?*\"
    send \"y\r\"
    expect \"Disallow root login remotely?*\"
    send \"n\r\"
    expect \"Remove test database and access to it?*\"
    send \"y\r\"
    expect \"Reload privilege tables now?*\"
    send \"y\r\"
    expect eof
    ")

    echo "$SECURE_MYSQL"
}

#############################################################
# Create new hive user
#
# Arguments:
#   - None
# Return:
#   - None
##############################################################

create_hive_users()
{
    mysql -u root -p$NEW_PASSWORD -e "SET GLOBAL validate_password_policy=LOW"
    mysql -u root -p$NEW_PASSWORD -e "SET GLOBAL validate_password_length=4"
    mysql -u root -p$NEW_PASSWORD -e "CREATE USER 'hive'@'localhost' IDENTIFIED BY 'hive'"
    mysql -u root -p$NEW_PASSWORD -e "GRANT ALL PRIVILEGES ON *.* TO 'hive'@'localhost'"
    mysql -u root -p$NEW_PASSWORD -e "CREATE USER 'hive'@'%' IDENTIFIED BY 'hive'"
    mysql -u root -p$NEW_PASSWORD -e "GRANT ALL PRIVILEGES ON *.* TO 'hive'@'%'"
    mysql -u root -p$NEW_PASSWORD -e "CREATE USER 'hive'@'$hostname' IDENTIFIED BY 'hive'"
    mysql -u root -p$NEW_PASSWORD -e "GRANT ALL PRIVILEGES ON *.* TO 'hive'@'$hostname'"
    mysql -u root -p$NEW_PASSWORD -e "FLUSH PRIVILEGES"
    mysql -u root -p$NEW_PASSWORD -e "CREATE DATABASE $HIVE_DATABASE"
}


#############################################################
# Download MySQL driver/connector
#
# Arguments:
#   - None
# Return:
#   - None
##############################################################

install_MySQL_Java_connector()
{
    yum localinstall $MYSQL_JAVA_CONNECTOR -y
    verify_exec "MySQL connector installation"
}

install_MySQL
service mysqld start
verify_exec "Start MySQL service"
update_mysql_password
create_hive_users
install_MySQL_Java_connector

