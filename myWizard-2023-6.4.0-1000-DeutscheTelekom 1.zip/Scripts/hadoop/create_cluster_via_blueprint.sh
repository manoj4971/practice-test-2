#!/bin/bash

# Usage: $./create_cluster_via_blueprint.sh <ambari-hostename> <blueprint-name> <target-cluster-name>

# This script creates Hadoop cluster via Blueprint.
HOSTNAME=`hostname -f`
AMBARI_HOST=$1
AMBARI_ADMIN_USER=admin
AMBARI_ADMIN_PASSWORD=admin
BLUEPRINT_NAME=$2
TARGET_CLUSTER_NAME=$3
#HDP_HOST=http://public-repo-1.hortonworks.com/HDP/centos7/3.x/updates/3.1.4.0/HDP-3.1.4.0-315.xml
CLUSTER_CONF_FILE=cluster_configuration.json
HOST_MAPPING_FILE=hostmapping.json

cp /var/opt/public_html_bkp/HDP/centos7/3.1.4.0-315/hdp.repo /etc/yum.repos.d/

echo "***** Start replacing all the hostname in $CLUSTER_CONF_FILE *****"
sed -i "s/<#HOSTNAME>/$HOSTNAME/g" $CLUSTER_CONF_FILE
echo "***** Replaced all the hostname in $CLUSTER_CONF_FILE *****"

echo "***** Start replacing all the hostname in $HOST_MAPPING_FILE *****"
sed -i "s/<#HOSTNAME>/$HOSTNAME/g" $HOST_MAPPING_FILE
echo "***** Replaced all the hostname in $HOST_MAPPING_FILE *****"

echo "***** Start replacing all the Blueprint in $CLUSTER_CONF_FILE *****"
sed -i "s/<#BLUEPRINT>/$BLUEPRINT_NAME/g" $CLUSTER_CONF_FILE
echo "***** Replaced all the Blueprint in $CLUSTER_CONF_FILE *****"

echo "***** Start replacing all the Blueprint in $HOST_MAPPING_FILE *****"
sed -i "s/<#BLUEPRINT>/$BLUEPRINT_NAME/g" $HOST_MAPPING_FILE
echo "***** Replaced all the Blueprint in $HOST_MAPPING_FILE *****"

echo "***** Start replacing all the cluster name in $HOST_MAPPING_FILE *****"
sed -i "s/<#CLUSTER_NAME>/$TARGET_CLUSTER_NAME/g" $HOST_MAPPING_FILE
echo "***** Replaced all the cluster name in $HOST_MAPPING_FILE *****"

#Adding HDP repo url
response=$(curl -v -k -u $AMBARI_ADMIN_USER:$AMBARI_ADMIN_PASSWORD -H "X-Requested-By:ambari" -X POST ${AMBARI_HOST}/api/v1/version_definitions -d '{  "VersionDefinition": {   "version_url":"file:///var/opt/public_html_bkp/HDP/centos7/3.1.4.0-315/HDP-3.1.4.0-315.xml"    }  }')

# Register Blueprint with Ambari
echo "Registering Blueprint to Ambari..."
API_REF=/api/v1/blueprints/${BLUEPRINT_NAME}?validate_topology=false
response=$(curl -s -o /dev/null -w "%{http_code}" -u $AMBARI_ADMIN_USER:$AMBARI_ADMIN_PASSWORD -i -H 'X-Requested-By: ambari' -X POST -d @${CLUSTER_CONF_FILE} ${AMBARI_HOST}${API_REF})

echo "###########   $response #####################"

if [ $response -ne 201 ]; then
    echo "Error: Not able to register Blueprint to Ambari!"
    exit 1
fi
echo "Blueprint successfully registered to Ambari!"

# Create Cluster
echo "Creating Cluster..."
API_REF=/api/v1/clusters/${TARGET_CLUSTER_NAME}
response=$(curl -s -o /dev/null -w "%{http_code}" -u $AMBARI_ADMIN_USER:$AMBARI_ADMIN_PASSWORD -i -H 'X-Requested-By: ambari' -X POST -d @${HOST_MAPPING_FILE} ${AMBARI_HOST}${API_REF})

if [ $response -ne 202 ]; then
    echo "Error: Not able to create Hadoop cluster!"
    exit 1
fi
echo "Successfully created Hadoop cluster!"

