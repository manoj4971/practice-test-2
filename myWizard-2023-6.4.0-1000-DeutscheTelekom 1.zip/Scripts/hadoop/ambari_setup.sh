#!/bin/bash
#
##########################################################################
# This script is created to Setup Ambari Server and Agent
# Created by Shabana
# Ambari Version 2.7.4.0
##########################################################################


#Generate public and private SSH keys on the Ambari Server host (~/.ssh)
#=======================================================================
#ssh-keygen
#.ssh/id_rsa.pub
#cat id_rsa.pub >> ~/.ssh/authorized_keys
#chmod 700 ~/.ssh
#chmod 600 ~/.ssh/authorized_keys
#=======================================================================

#Setting variables to get hostame and IP of server
#=================================================

hostname=$(hostname)
IP=$(hostname -I|cut -d" " -f 1)
AMBARI_REPO_URL=file:///var/opt/public_html_bkp/ambari/centos7/2.7.4.0-118/ambari.repo


#############################################################
# Verify all the executions are successfully performed or not
# Arguments:
#   - execution information
# Return:
#   - None
##############################################################
verify_exec()
{
    if [ $? -eq 0 ]; then
        echo $1 + " - Success"
    else
        echo $1 + " - Failed"
        exit 1
    fi
}

#setting up ulimit value, instllating and ntp and

ulimit -n 10000
verify_exec "verify ulimit"


yum install -y ntp
systemctl enable ntpd

#Adding IP & hostname in hosts file
#==================================
sed -i "3i $IP $hostname" /etc/hosts
#sed -i "4i $IP mywizard-gp2-ambari.aiam-dh.com" /etc/hosts
verify_exec "Update host file"

#Add/modify the HOSTNAME property to set the fully qualified domain name
#=======================================================================
sed -i "1i HOSTNAME=$hostname" /etc/sysconfig/network
verify_exec "Update Hostname"

#Temporarily Disable iptables & Disable SELinux - Set umask value
#=================================================================
systemctl disable firewalld
service firewalld stop
setenforce 0
umask 0022


#Download the Ambari repository file to a directory on your installation host
#============================================================================
#wget -nv http://public-repo-1.hortonworks.com/ambari/centos7/2.x/updates/2.7.4.0/ambari.repo -O /etc/yum.repos.d/ambari.repo
cp $AMBARI_REPO_URL /etc/yum.repos.d/

yum install ambari-server -y

#Add/modify the ambari-server file to run url with 8090 port
#==========================================================
sed -i "1i client.api.port=8090" /etc/ambari-server/conf/ambari.properties
verify_exec "Install Ambari"

#Ambari server host to start the setup process
#============================================
ambari-server setup -s
ambari-server start
verify_exec "Start Ambari server"

#Run Ambari-Server setup command with mysql jdbc
#===============================================
ambari-server setup --jdbc-db=mysql --jdbc-driver=/usr/share/java/mysql-connector-java.jar
verify_exec "Setup MySQL JDBC for Ambari"

#Download the Ambari repository file to a directory on your installation host (server)
#====================================================================================
#wget -nv $AMBARI_REPO_URL -O /etc/yum.repos.d/ambari.repo
yum repolist

#Install Ambari Agent on every host in your cluster.
#==================================================
yum install ambari-agent -y

#Using a text editor, configure the Ambari Agent to provide Ambari Server host by editing the ambari-agent.ini file. as shown in the following: /etc/ambari-agent/conf/ambari-agent.ini
#====================================================================================================================================
sed -i "s/hostname=localhost/hostname=$hostname/" /etc/ambari-agent/conf/ambari-agent.ini
Line_number=$(cat /etc/ambari-agent/conf/ambari-agent.ini | grep -n "security" | head -1 | cut -d : -f1)
Line_number=$(($Line_number+1))"i"
sed -i "$Line_number force_https_protocol=PROTOCOL_TLSv1_2" /etc/ambari-agent/conf/ambari-agent.ini

#Edit verify value platform_default to disable cert-verification.cfg
#===================================================================
sed -i 's/verify=platform_default/verify=disable/' /etc/python/cert-verification.cfg

ambari-agent start
verify_exec "Start Ambari agent"
