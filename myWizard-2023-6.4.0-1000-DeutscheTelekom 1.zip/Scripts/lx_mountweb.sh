#!/bin/bash
#Mount process between two Centos Instances in webserver

#Create folder myWizard-Phoenix in mnt folder
mkdir -p /mnt/myWizard-Phoenix
mkdir -p /mnt/myWizard-Phoenix/DataLoader_DownloadTemplate
mkdir -p /mnt/myWizard-Phoenix/DataLoader_FileUpload
mkdir -p /mnt/myWizard-Phoenix/DeliveryPlanInbound
mkdir -p /mnt/myWizard-Phoenix/DeliveryPlanOutbound
mkdir -p /mnt/myWizard-Phoenix/GenericUpload
mkdir -p /mnt/myWizard-Phoenix/IngrAIn_Shared
mkdir -p /mnt/myWizard-Phoenix/resourcedata
mkdir -p /mnt/myWizard-Phoenix/TestOptimizer/om
mkdir -p /mnt/myWizard-Phoenix/ReportAutomation_Shared
mkdir -p /mnt/myWizard-Phoenix/ICM_Shared
mkdir -p /mnt/myWizard-Phoenix/ProjectInitiation_Shared
mkdir -p /mnt/myWizard-Phoenix/myWizard.InsightfulTestPatternMining
mkdir -p /mnt/myWizard-Phoenix/GatewayManager/ProcessPipelines
mkdir -p /mnt/myWizard-Phoenix/GatewayManager/OutboundMessages
mkdir -p /mnt/myWizard-Phoenix/ToolGateway/ProcessPipelines
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/GenericUploadGM/New
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/GenericUploadGM/Processed
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/GenericUploadGM/Error
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/GenericUploadUI/New
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/GenericUploadUI/Processed
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/GenericUploadUI/Error
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/GenericUploadUI/Log
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/GenericUploadAPI/New
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/GenericUploadAPI/Processed
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/GenericUploadAPI/Error
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/Template
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/Temp
mkdir -p /mnt/myWizard-Phoenix/GenericUpload/TempZip
mkdir -p /mnt/myWizard-Phoenix/om
mkdir -p /mnt/myWizard-Phoenix/myWizard.PatternMiningSAP/Upload
chown -R nginx:nginx /mnt/myWizard-Phoenix/

#Install the nfs utilities
yum install nfs-utils -y

#start the services and enable them to be started at boot time. 
systemctl enable rpcbind
systemctl enable nfs-server
systemctl enable nfs-lock
systemctl enable nfs-idmap
systemctl start rpcbind
systemctl start nfs-server
systemctl start nfs-lock
systemctl start nfs-idmap

#Now we will share the NFS directory over the network a follows
#Edit the file with mounting paths: Sharing directories

#Change the target server ip address (App server ip address need to be update)
echo "/mnt/myWizard-Phoenix 192.168.16.113(rw,sync,no_root_squash,no_all_squash)" >> /etc/exports 
echo "/mnt/myWizard-Phoenix *(rw)" >> /etc/exports

#Start the NFS service:
systemctl restart nfs-server
#Again we need to add the NFS service override in CentOS 7 firewall-cmd public zone service as
#Install firewalld if not installed
yum install firewalld -y
systemctl start firewalld
firewall-cmd --permanent --zone=public --add-service=nfs
firewall-cmd --permanent --zone=public --add-service=mountd
firewall-cmd --permanent --zone=public --add-service=rpc-bind
firewall-cmd --reload
systemctl start firewalld
systemctl status firewalld
sudo systemctl disable firewalld
sudo systemctl stop firewalld