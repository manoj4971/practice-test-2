sudo yum -y install epel-release yum-utils
	echo "################Postgres Insatllation##############"
	#echo "Postgres Repo update"
	dnf install -y https://download.postgresql.org/pub/repos/yum/reporpms/EL-8-x86_64/pgdg-redhat-repo-latest.noarch.rpm
	echo "###############information on installed package#######################"
	rpm -qi pgdg-redhat-repo
	echo "###############Install Postgres 12####################################"
	echo "###############List the Postgres versions#############################"
	dnf repolist
	dnf list postgresql*
	echo "###############Install Postgres 12 Server#############################"
	sleep 2
	sudo dnf install postgresql12-server.x86_64 -y
	sudo dnf install postgresql12.x86_64 -y
	sudo dnf install postgresql12-contrib.x86_64 -y
	sleep 2
	echo "###############Version of Postgres####################################"
	psql -V
	
	echo "###############Creating a New PostgreSQL with initdb##################"
	sudo /usr/pgsql-12/bin/postgresql-12-setup initdb
	echo "###############start and enable PostgreSQL using systemctl############"
	sudo systemctl start postgresql-12
	sudo systemctl enable postgresql-12
	echo "###############----------------------------###########################"
	echo "###############Login into the postgres user###########################"
	cd /
	
	sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'Psql_Admin@2023';"
	echo "####################updating the postgresql.conf file########################"
	HOSTNAME=$(hostname -f)
	sed -i '/^#listen_addresses/a listen_addresses = "localhost"' /var/lib/pgsql/12/data/postgresql.conf
	sed -i 's/localhost/'"$HOSTNAME"'/g' /var/lib/pgsql/12/data/postgresql.conf
	sed -i 's/#ssl = off/ssl = on/g' /var/lib/pgsql/12/data/postgresql.conf
	sed -i '/^#ssl_ca_file/a ssl_ca_file = "'/var/lib/pgsql/12/data/postgres-certs/postgresCA.pem'"' /var/lib/pgsql/12/data/postgresql.conf
	sed -i '/^#ssl_cert_file/a ssl_cert_file = "'/var/lib/pgsql/12/data/postgres-certs/$HOSTNAME.pem'"' /var/lib/pgsql/12/data/postgresql.conf
	sed -i '/^#ssl_key_file/a ssl_key_file = "'/var/lib/pgsql/12/data/postgres-certs/$HOSTNAME.key'"' /var/lib/pgsql/12/data/postgresql.conf
	sed -i "y/\"/'/" /var/lib/pgsql/12/data/postgresql.conf
	sed -i 's/#ssl_ciphers/ssl_ciphers/g' /var/lib/pgsql/12/data/postgresql.conf
	sed -i 's/#ssl_prefer_server_ciphers/ssl_prefer_server_ciphers/g' /var/lib/pgsql/12/data/postgresql.conf
	echo "********postgresql.conf was updated*******"
	echo "#########################updating the pg_hba.conf file ###########################"
	sed -i 's/^host/#host/g' /var/lib/pgsql/12/data/pg_hba.conf
	sed -i '/^#host/a hostssl    all             all            0.0.0.0/0        md5' /var/lib/pgsql/12/data/pg_hba.conf
	sed -i '/^hostssl/a hostssl    all             all           all        md5' /var/lib/pgsql/12/data/pg_hba.conf
	echo "********pg_hba.conf was updated*******"
	
	echo "###############Enabling SSL Certficates###########################"
	
	echo "###############Kindly use the path /var/lib/pgsql/12/data#########"
	mkdir -p /var/lib/pgsql/12/data/postgres-certs
	cd /var/lib/pgsql/12/data/postgres-certs
	echo "******** went to the path /var/lib/pgsql/12/data*******"
	
	echo "##########Generate a postgresCA.key##########"
	openssl genrsa -des3 -passout pass:Psql_Admin@2023 -out postgresCA.key 4086
	echo "********postgresCA.key generated*******"
	
	echo "##########Generate a postgresCA.pem##########"
	openssl req -new -nodes -passin pass:Psql_Admin@2023 -key postgresCA.key  -sha256 -days 3650 -out postgresCA.pem -x509 -subj "/C=IN/ST=DELHI/L=NEWDELHI/O=ACCENTURE /OU=myWizardClient/CN=myWizard"
	echo "********postgresCA.pem generated*******"
	
	echo "##########Generate HOSTNAME.key##########"
	openssl genrsa -out $HOSTNAME.key 4086
	echo "**********HOSTNAME.key Generated**********"
	
	echo "##########Generate HOSTNAME.csr###########$"
	openssl req -new -key $HOSTNAME.key -out $HOSTNAME.csr -subj "/C=IN/ST=DELHI/L=NEWDELHI/O=ACCENTURE /OU=myWizardClient/CN=$HOSTNAME"
	echo "**********HOSTNAME.csr Generated**********"
	
	echo "##########Generate HOSTNAME.pem###########$"
	openssl x509 -req -days 2048 -passin pass:Psql_Admin@2023 -in $HOSTNAME.csr -CA postgresCA.pem -CAkey postgresCA.key -CAcreateserial -out $HOSTNAME.pem
	echo "**********HOSTNAME.pem Generated**********"
	
	echo "##################update the certificate user to postgresql#####################"
	chown -R postgres:postgres /var/lib/pgsql/12/data/postgres-certs*
	chmod -R 700 /var/lib/pgsql/12/data/postgres-certs
	chmod -R 600 /var/lib/pgsql/12/data/postgres-certs/*
	
	echo "********certificate user to postgresql*******"
	echo "###############Copy the cdrtificates into /var/www/appConfigFiles/certificates folder#############"
	cp -rf /var/lib/pgsql/12/data/postgres-certs/* /var/www/appConfigFiles/certificates
	echo "*************Certificates copied into /var/www/appConfigFiles/certificates folder*****************"
	
	echo "##################Creating environment Variables#####################"
	touch /etc/profile.d/env.sh
cat > /etc/profile.d/env.sh << EOL
export PATH=/usr/pgsql-12/bin:$PATH
export PGSSLROOTCERT=/var/lib/pgsql/12/data/postgres-certs/postgresCA.pem
EOL
	echo "**********Environment Variables Added**********"
	cd /etc/profile.d
	sh env.sh
	echo "**********Executed Environment Variables**********"
	printenv
	
	echo "###################Restart the postgresql server########################"
	systemctl restart postgresql-12
	echo "********postgresql-12 restarted*******"
	
	echo "##################Status the postgresql server#########################"
	#systemctl status postgresql-12
	echo "********postgresql-12 status*******"