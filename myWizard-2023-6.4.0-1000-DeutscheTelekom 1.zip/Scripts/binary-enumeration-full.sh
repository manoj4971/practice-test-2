#!/bin/bash
IP=$(hostname -I|cut -d" " -f 1)


pwsh ./binary-enumeration.ps1 -nodeName $IP -reportType Full