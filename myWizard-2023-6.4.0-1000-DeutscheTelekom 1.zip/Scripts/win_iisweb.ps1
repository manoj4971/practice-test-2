﻿param(
    $ipAddress = "" ,
    $AdminUser = "",
    $AdminPassword = ""
)

begin{
    Clear-Host 
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    winrm set winrm/config/client '@{TrustedHosts="' $ipAddress '"}' | Out-Null
    [securestring]$password = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
    $credentials = New-Object System.Management.Automation.PSCredential ($AdminUser, $password)
    $session = New-PSSession –ComputerName $ipAddress -Credential $credentials
    Write-Host "Installing IIS"
}

process{
       
    Invoke-Command -Session $session -ScriptBlock {
        if ((Get-WindowsOptionalFeature -Online -FeatureName "IIS-WebServerRole").State -ne 'Enabled') {
            Enable-WindowsOptionalFeature -Online -FeatureName "IIS-WebServerRole"
        }
        if ((Get-WindowsFeature -Name "Web-Net-Ext45").InstallState -ne 'Installed') {
            Add-WindowsFeature -Name "Web-Net-Ext45"
        }
        if ((Get-WindowsFeature -Name "Web-Asp-Net45").InstallState -ne 'Installed') {
            Add-WindowsFeature -Name "Web-Asp-Net45"
        }
        if ((Get-WindowsFeature -Name "Web-ISAPI-Ext").InstallState -ne 'Installed') {
            Add-WindowsFeature -Name "Web-ISAPI-Ext"
        }
        if ((Get-WindowsFeature -Name "Web-ISAPI-Filter").InstallState -ne 'Installed') {
            Add-WindowsFeature -Name "Web-ISAPI-Filter"
        }
        if ((Get-WindowsFeature -Name "Web-CGI").InstallState -ne 'Installed') {
            Add-WindowsFeature -Name "Web-CGI"
        }
    }
}
end{
    Write-Host "Installation completed"
}
