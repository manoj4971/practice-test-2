Clear-Host
$User = "Domain\user"
$Folder = $_.PSIsContainer
$Type = $_.Extension

$ip = Get-NetIPAddress -AddressFamily IPv4 -InterfaceIndex $(Get-NetConnectionProfile | Select-Object -ExpandProperty InterfaceIndex) | Select-Object -ExpandProperty IPAddress

[string[]]$volumes = $(Get-Volume | Where-Object { $_.DriveLetter -ne $null -and $_.DriveLetter -ne "" } | Select-Object @{ n="DriveLetter";e={ $($_.DriveLetter+":\") }}).DriveLetter
    
foreach($drive in $volumes) {
    
    $destination = $("C:\ScanReports\"   + $ip +  "_" + $drive.Replace(":\","") + "_scanfiles")
    New-Item -Path "C:\ScanReports\" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
    $filepath = $($destination + ".csv")

    

        $found = Get-ChildItem -Path $drive -Recurse -File -ErrorAction SilentlyContinue |  
                        Where-Object { 
                                        $_.Extension -in '.doc', '.xlsx', '.xls', '.pdf', '.docx', '.csv', '.json', '.xml' -and (
                                            $_.Name -notmatch ".dll" -or
                                            $_.Name -notmatch ".exe" -or
                                             
											

                                            $_.FullName -notmatch "AWS SDK for .NET" -or
                                            $_.FullName -notmatch "LCU" -or 
                                            $_.FullName -notmatch "WinSxS" -or 
                                            $_.FullName -notmatch "ServiceProfiles" -or 
                                            $_.FullName -notmatch "Openxml")
                                        } | 
                        Select-Object  Name,Directory,Length, @{Name="Owner";Expression={(Get-ACL $_.Fullname).Owner}},@{N="FileType";E={$_.Extension.ToLower()}},LastAccessTime,LastWriteTime,CreationTime 
    $found |  ConvertTo-Csv | Set-Content -Path $filepath 


}