#!/bin/bash
#######Install googlechrome
cd /tmp
echo -e "Installing Google Chrome"
wget https://dl.google.com/linux/direct/google-chrome-stable_current_x86_64.rpm
yum localinstall google-chrome-stable_current_x86_64.rpm -y
