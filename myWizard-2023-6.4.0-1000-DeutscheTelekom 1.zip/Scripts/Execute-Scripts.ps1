﻿param (
    $mountUserName = "",
    $mountPassword = "",
    $ipAddress = "",
    $scriptPaths = "",
    $runningFor = ""
)


Configuration LinuxMountDrive
{
    param (
        $mntPath,
        $smbPath,
        $nxLogFile
    )
    Import-DscResource -Module nx
    
    Node $ipAddress {
        nxScript "LinuxMountDrive" {
            GetScript  = @"
#!/bin/pwsh
Write-Host "mounting drive"
"@
            TestScript = @"
#!/bin/pwsh
Write-Host "mounting drive test"
exit 1
"@
            SetScript  = @"
#!/bin/pwsh
New-Item -ItemType Directory -Path $mntPath -Force -ErrorAction SilentlyContinue | Out-Null
chmod -R 777 $mntPath
mount -t cifs $smbPath $mntPath -o username=$mountUserName,password=$mountPassword,vers=2.0,guest,noacl,noperm,rw

Add-Content -Path $nxLogFile -Value "New-Item -ItemType Directory -Path $mntPath -Force -ErrorAction SilentlyContinue | Out-Null"
Add-Content -Path $nxLogFile -Value "chmod -R 777 $mntPath"
Add-Content -Path $nxLogFile -Value "mount -t cifs $smbPath $mntPath -o username=$mountUserName,password=$mountPassword,vers=2.0,guest,noacl,noperm,rw"
Add-Content -Path $nxLogFile -Value ""
"@
        }
    }
}

Configuration ExecuteScripts
{
    param (
        $mntPath,
        $scripts,
        $nxLogFile
    )
    Import-DscResource -Module nx
    
    Node $ipAddress {
        nxScript "ExecuteScripts" {
            GetScript  = @"
#!/bin/pwsh
Write-Host "executing scripts"
"@
            TestScript = @"
#!/bin/pwsh
Write-Host "executing scripts test"
exit 1
"@
            SetScript  = @"
#!/bin/pwsh
foreach(`$script in "$scripts".Split(',')) {

Add-Content -Path $nxLogFile -Value "************************************************************************************************************************************************"
Add-Content -Path $nxLogFile -Value "********************************************************************`$script********************************************************************"
Add-Content -Path $nxLogFile -Value "************************************************************************************************************************************************"

Add-Content -Path $nxLogFile -Value ""

Add-Content -Path $nxLogFile -Value "cd $mntPath"
cd $mntPath

Add-Content -Path $nxLogFile -Value "dos2unix $mntPath/`$script"
dos2unix "$mntPath/`$script" >> $nxLogFile

Add-Content -Path $nxLogFile -Value "sudo chmod -R 777 `$script"
sudo chmod -R 777 `$script

if(`$script.Contains(".sh")) {
    Add-Content -Path $nxLogFile -Value "sh $mntPath/`$script"
    sh "$mntPath/`$script" >> $nxLogFile
}
elseif(`$script.Contains(".ps1")) {
    Add-Content -Path $nxLogFile -Value "pwsh $mntPath/`$script"
    pwsh "$mntPath/`$script" >> $nxLogFile
}

Add-Content -Path $nxLogFile -Value ""
}
"@
        }
    }
}

Configuration LinuxUnMountDrive
{
    param (
        $mntPath,
        $nxLogFile
    )
    Import-DscResource -Module nx
    
    Node $ipAddress {
        nxScript "LinuxUnMountDrive" {
            GetScript  = @"
#!/bin/pwsh
Write-Host "unmounting drive"
"@
            TestScript = @"
#!/bin/pwsh
Write-Host "unmounting drive test"
exit 1
"@
            SetScript  = @"
#!/bin/pwsh
Add-Content -Path $nxLogFile -Value "umount $mntPath"
Add-Content -Path $nxLogFile -Value ""
Move-Item -Path $nxLogFile -Destination $mntPathLogs												
umount $mntPath
"@
        }
    }
}


function Init {
    param (
    )
    begin {
        Clear-Host
        $credentials = Get-Credential -Message $("Enter credential for " + $ipAddress) -UserName "root"
        $sessOpt = New-CimSessionOption -UseSsl -SkipCACheck -SkipCNCheck -SkipRevocationCheck
        $session = New-CimSession -Credential $credentials -ComputerName $ipAddress -Port 5986 -Authentication basic -SessionOption $sessOpt -OperationTimeoutSec 900

        $thisPath = $(Split-Path -Path $PSCommandPath -Parent)
        $MOFPath = $($thisPath + "\MOF\")
        $sourceIP = (Get-NetIPAddress | Where-Object {$_.AddressFamily -eq "IPv4" -and $_.InterfaceAlias -match "Ethernet"}).IPAddress
        $smbPath = $thisPath.Replace([System.IO.Path]::GetPathRoot($thisPath),"\\"+$sourceIP+"\")
        $mntPath = "/mnt/win/OneClickTools"
		$mntPathLogs = "/mnt/win/OneClickTools/Logs"
		$OCIPath = "/var/www/OneClickInstaller"								  

        $scriptPaths = $scriptPaths -replace "\s+"," " -replace " ,",","

        $logFile = $($runningFor + "_DSCLog_" + $ipAddress + "_" + (Get-Date -Format "yyyyMMdd_HHmm") + ".txt")

        $nxLogFile = $($OCIPath + "/Logs/" + $logFile.Replace("_DSCLog_","_ExecutionLog_"))
        $logPath = $($thisPath + "\Logs\" + $logFile)

        #New-Item "D:\Accenture\" –Type directory -Force -Verbose
        #New-SmbShare -Name "Installers" -Path "C:\Accenture\" -FullAccess "Everyone" -ErrorAction SilentlyContinue -Verbose
        #Set-SmbPathAcl -ShareName "Installers" -ErrorAction SilentlyContinue -Verbose

        Start-Transcript -Path $logPath -Force | Out-Null
    }
    process {
        New-Item -ItemType Directory -Path $MOFPath -Force -ErrorAction SilentlyContinue | Out-Null
        Write-Host "Starting for server " $ipAddress -BackgroundColor DarkGreen
        Write-Host
        Stop-DscConfiguration -Force -ErrorAction SilentlyContinue -InformationAction SilentlyContinue -WarningAction SilentlyContinue | Out-Null
        Remove-DscConfigurationDocument -Force -Stage Current -ErrorAction SilentlyContinue -InformationAction SilentlyContinue -WarningAction SilentlyContinue | Out-Null
        Remove-DscConfigurationDocument -Force -Stage Pending -ErrorAction SilentlyContinue -InformationAction SilentlyContinue -WarningAction SilentlyContinue | Out-Null
        Remove-DscConfigurationDocument -Force -Stage Previous -ErrorAction SilentlyContinue -InformationAction SilentlyContinue -WarningAction SilentlyContinue | Out-Null



        Write-Host "This Path : "$thisPath -BackgroundColor DarkCyan
        Write-Host "MOF Path : "$MOFPath -BackgroundColor DarkCyan
        Write-Host "SMB Path : "$smbPath -BackgroundColor DarkCyan
        Write-Host "Mount Path : "$mntPath -BackgroundColor DarkCyan
        Write-Host "Log Path : "$logPath -BackgroundColor DarkCyan
        Write-Host "nx Log Path : "$nxLogFile -BackgroundColor DarkCyan


        Write-Host "Mounting drive..." -BackgroundColor Yellow -ForegroundColor Black
        LinuxMountDrive -OutputPath $MOFPath -mntPath $mntPath -smbPath $smbPath -nxLogFile $nxLogFile | Out-Null
        Start-DscConfiguration -Path $MOFPath -CimSession $session -Wait -Force -ErrorAction Stop
        Move-Item -Path $($MOFPath + "\" + $ipAddress + ".mof") -Destination $($MOFPath + "\LinuxMountDrive_" + $ipAddress + ".mof") -Force
        Write-Host "Mounting drive complete..."

        Write-Host

        Write-Host "Executing scripts..." -BackgroundColor Yellow -ForegroundColor Black
        ExecuteScripts -OutputPath $MOFPath -mntPath $mntPath -scripts $scriptPaths -nxLogFile $nxLogFile | Out-Null
        Start-DscConfiguration -Path $MOFPath -CimSession $session -Wait -Force -ErrorAction Stop
        Move-Item -Path $($MOFPath + "\" + $ipAddress + ".mof") -Destination $($MOFPath + "\ExecuteScripts_" + $ipAddress + ".mof") -Force
        Write-Host "Executing scripts complete..."

        Write-Host

        Write-Host "Un-Mounting drive..." -BackgroundColor Yellow -ForegroundColor Black
        LinuxUnMountDrive -OutputPath $MOFPath -mntPath $mntPath -nxLogFile $nxLogFile | Out-Null
        Start-DscConfiguration -Path $MOFPath -CimSession $session -Wait -Force
        Move-Item -Path $($MOFPath + "\" + $ipAddress + ".mof") -Destination $($MOFPath + "\LinuxUnMountDrive_" + $ipAddress + ".mof") -Force
        Write-Host "Un-Mounting drive complete..."
    }
    end {
        Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
    }
}


Init