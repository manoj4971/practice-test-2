#!/bin/bash

#######Install nodejs

curl -sL https://rpm.nodesource.com/setup_14.x | sudo -E bash
sudo yum clean all && sudo yum makecache fast
yum install -y gcc-c++ make
yum -y install nodejs