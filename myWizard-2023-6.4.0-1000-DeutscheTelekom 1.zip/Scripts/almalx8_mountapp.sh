#!/bin/bash
#Ports need to be opened before running nfs_client script
#Client end Or Target End
#Install the nfs utilities
yum install nfs-utils -y

#Create mount path
mkdir -p /mnt/myWizard-Phoenix
chown -R nginx:nginx /mnt/myWizard-Phoenix

#create the NFS directory mount points:
#Edit the fstab file with below for permanent mount (Change the ip address with Web server ip)
echo "192.168.16.83:/mnt/myWizard-Phoenix  /mnt/myWizard-Phoenix    nfs     0 0" >> /etc/fstab

#Execute below command to mount the drive (Change the ip address with Web server ip)
mount 192.168.16.83:/mnt/myWizard-Phoenix  /mnt/myWizard-Phoenix