IP=$(hostname -I|cut -d" " -f 1)

mkdir -p /etc/systemd/system/MyWIzard
mkdir -p /var/www/Logs/OCI.Cryptography
logfile=$IP-CryptoLog-`date "+%Y%m%d%H%M"`.log
while read line
do 
if [[ $line == *"TestOptimizer.WebAPI.Tomcat"* ]]; then

cd /etc/tomcat9/conf/TestOptimizer
echo "Updating the encription enabled flag for the file " $line
sed -i 's|EncryptionEnabled=false|EncryptionEnabled=true|g' application.properties
echo "Running the encryption for" $line
java -jar -Dmode="AES/CBC/PKCS5PADDING" ./application-common-cryptography.jar --sourcePropertyFile ./application.properties  --destinationPropertyFile ./application.properties --operation encrypt --configFile ./app.json --overwriteDestinationPropertyFile true
cd /etc/tomcat9/conf/ID
echo "Updating the encription enabled flag for the file Risk"
sed -i 's|encryption=false|encryption=true|g' connection.properties
echo "Running the encryption for Risk"
java -jar -Dmode="AES/CBC/PKCS5PADDING" ./application-common-cryptography.jar --sourcePropertyFile ./connection.properties  --destinationPropertyFile ./connection.properties --operation encrypt --configFile ./app_risk.json --overwriteDestinationPropertyFile true
systemctl restart tomcat

elif [[ $line == *"InstantTestAutomation.WebAPI.Tomcat"* ]]; then

cd /etc/tomcat9/conf/InstantTestAutomation
echo "Updating the encription enabled flag for the file " $line
sed -i 's|EncryptionEnabled=false|EncryptionEnabled=true|g' application.properties
echo "Running the encryption for" $line
java -jar -Dmode="AES/CBC/PKCS5PADDING" ./application-common-cryptography.jar --sourcePropertyFile ./application.properties  --destinationPropertyFile ./application.properties --operation encrypt --configFile ./app.json --overwriteDestinationPropertyFile true
systemctl restart tomcat

elif [[ $line == *"RequirementsTraceabilityAssistant.AIModel"* ]]; then

echo "Running the encryption for" $line
cd $line/pythonscripts
echo "Updating the encription enabled flag for the file " $line/app.ini
sed -i 's|false|true|g' $line/pythonscripts/app.ini
chmod -R 777 $line/pythonscripts
cd $line/pythonscripts && source rta_env/bin/activate && python  encryptor.py
chmod -R 755 $line/pythonscripts
deactivate
sed -i 's|false|true|g' $line/app.json
echo "Ecnrypting the confg files mentioned in " $line/app.json
dotnet /var/www/appConfigFiles/OCI.Cryptography/myWizard.OCI.Cryptography.Console.dll $line/app.json encrypt

elif [[ $line == *"RequirementsTraceabilityAssistant.MetricModel"* ]]; then

echo "Running the encryption for" $line
cd $line/pythonscripts
echo "Updating the encription enabled flag for the file " $line/app.ini
sed -i 's|false|true|g' $line/pythonscripts/app.ini
chmod -R 777 $line/pythonscripts
cd $line/pythonscripts && source rta_env/bin/activate && python  encryptor.py
chmod -R 755 $line/pythonscripts
deactivate
sed -i 's|false|true|g' $line/app.json
echo "Ecnrypting the confg files mentioned in " $line/app.json
dotnet /var/www/appConfigFiles/OCI.Cryptography/myWizard.OCI.Cryptography.Console.dll $line/app.json encrypt

elif [[ $line == *"InsightfulTestPatternMining.WebAPI.Python"* ]]; then

cd $line
echo "Updating the encription enabled flag for the file " $line/app.ini
sed -i 's|false|true|g' $line/app.ini
chmod -R 777 $line/
cd $line && source PM_env/bin/activate && python  encryptor.py
chmod -R 755 $line
deactivate

elif [[ $line == *"PatternMiningForSAP.WebAPI.Python"* ]]; then

cd $line
echo "Updating the encryption enabled flag for the file " $line/app.ini
sed -i 's|false|true|g' $line/app.ini
chmod -R 777 $line/
cd $line && source PMSAP_env/bin/activate && python encryptor.py
chmod -R 755 $line
deactivate

elif [[ $line == *"IngrAIn.SelfServiceAI"* ]]; then

echo "Running the encryption for" $line
cd $line
sh IngrAIn_Python/main/encryptPythonfile.sh -e
echo "Updating the encription enabled flag for the file " $line/app.json
sed -i 's|false|true|g' $line/app.json
echo "Ecnrypting the confg files mentioned in " $line/app.json
dotnet /var/www/appConfigFiles/OCI.Cryptography/myWizard.OCI.Cryptography.Console.dll $line/app.json encrypt

elif [[ $line == *"IngrAInPredictionService"* ]]; then

echo "Running the encryption for" $line
cd $line
sh IngrAIn_Python/main/encryptPythonfile.sh -e

elif [[ $line == *"IngrAIn"* && $line == *"WebAPI.Python"* ]]; then

echo "Running the encryption for" $line
cd $line
sh encryptPythonfile.sh -e

elif [[ $line == *"WebAPI.Python"* ]]; then

echo "Running the encryption for" $line
cd $line
sh toggle_encryption.sh -e

else

echo "Updating the encription enabled flag for the file " $line/app.json
sed -i 's|false|true|g' $line/app.json
echo "Ecnrypting the confg files mentioned in " $line/app.json
dotnet /var/www/appConfigFiles/OCI.Cryptography/myWizard.OCI.Cryptography.Console.dll $line/app.json encrypt

fi
systemctl restart $line
done < /mnt/win/OneClickTools/Encrypt.txt

yes | cp /var/www/Logs/OCI.Cryptography/$logfile /mnt/win/OneClickTools/Logs