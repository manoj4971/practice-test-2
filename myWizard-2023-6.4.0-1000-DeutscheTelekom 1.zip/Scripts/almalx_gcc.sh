#!/bin/bash

######Install GCC
sudo yum -y install gcc

sudo yum install gcc-c++