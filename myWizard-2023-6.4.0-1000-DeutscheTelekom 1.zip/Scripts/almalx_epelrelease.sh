#!/bin/bash

######Install epel
sudo rpm -ivh https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
sudo yum update
yum -y install epel-release