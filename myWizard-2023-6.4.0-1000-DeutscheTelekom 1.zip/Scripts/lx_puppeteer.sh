#!/bin/bash
#######Install puppeteer
sudo npm i puppeteer@3.0.1

