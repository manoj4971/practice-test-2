#!/bin/bash

echo "*********Installing docker*********"
cd /tmp
dnf install yum-utils
dnf config-manager --add-repo=https://download.docker.com/linux/centos/docker-ce.repo
dnf install docker-ce docker-ce-cli containerd.io docker-compose-plugin --exclude=moby-* -y
sudo systemctl enable docker
sudo systemctl start docker
