#!/bin/sh
yum install gssntlmssp -y

