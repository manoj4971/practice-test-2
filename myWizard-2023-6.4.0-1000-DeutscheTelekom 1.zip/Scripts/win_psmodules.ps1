﻿param(
    $ipAddress = "" ,
    $AdminUser = "",
    $AdminPassword = ""
)

begin{
    Clear-Host 
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    winrm set winrm/config/client '@{TrustedHosts="' $ipAddress '"}' | Out-Null
    [securestring]$password = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
    $credentials = New-Object System.Management.Automation.PSCredential ($AdminUser, $password)
    $session = New-PSSession –ComputerName $ipAddress -Credential $credentials
    Write-Host "Installing required modules, Please wait..."
    Write-Host "If you feel that the script is taking lot more time, Please close the script, comment line numbers 24 to 33 and retry..."
}

process{
       
    Invoke-Command -Session $session -ScriptBlock {

        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

        Write-Host 
        Write-Host 
        Write-Host "Installaling PackageProvider" -BackgroundColor Yellow -ForegroundColor Black
        Install-PackageProvider -Name "NuGet" -Force -ForceBootstrap -ErrorAction SilentlyContinue | Out-Null

        Write-Host "Installaling PackageManagement" -BackgroundColor Yellow -ForegroundColor Black
        Install-Module -Name "PackageManagement" -MinimumVersion 1.4.6 -AllowClobber -Force | Out-Null

        Write-Host "Setting Repository" -BackgroundColor Yellow -ForegroundColor Black
        Set-PSRepository -Name PSGallery -InstallationPolicy Trusted -PackageManagementProvider NuGet | Out-Null
        #Register-PSRepository -Default -InstallationPolicy Trusted
        #Register-PSRepository -Name PSGallery -SourceLocation https://www.powershellgallery.com/api/v2/ -InstallationPolicy Trusted

        $psModules = Get-Module -ListAvailable | Select-Object -Property Name, Version
        
        if ($null -eq ($psModules | Where-Object { $_.Name -match "xWebAdministration" })) {
            Write-Host "Installing xWebAdministration module"
            Install-Module -Name xWebAdministration -Force
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "xCertificate" })) {
            Write-Host "Installing xCertificate module"
            Install-Module -Name xCertificate -Force
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "xDatabase" })) {
            Write-Host "Installing xDatabase module"
            Install-Module -Name xDatabase -Force
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "xPSDesiredStateConfiguration" })) {
            Write-Host "Installing xPSDesiredStateConfiguration module"
            Install-Module -Name xPSDesiredStateConfiguration -Force
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "nx" })) {
           Write-Host "Installing nx module"
           Install-Module -Name nx -Force
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "ComputerManagementDsc" })) {
            Write-Host "Installing ComputerManagementDsc module"
            Install-Module -Name ComputerManagementDsc -Force
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "SqlServerDsc" })) {
            Write-Host "Installing SqlServerDsc module"
            Install-Module -Name SqlServerDsc -Force
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "xNetworking" })) {
            Write-Host "Installing xNetworking module"
            Install-Module -Name xNetworking -Force
        }
        if ($null -eq ($psModules | Where-Object { $_.Name -match "Microsoft.PowerShell.Archive" -and $_.Version -eq "1.2.3.0" })) {
            Write-Host "Installing Microsoft.PowerShell.Archive module"
            Install-Module Microsoft.PowerShell.Archive -MaximumVersion "1.2.3.0" -Force -AllowClobber -ErrorAction Stop
        }

    }
}
end{
    Write-Host "Installation completed"
}