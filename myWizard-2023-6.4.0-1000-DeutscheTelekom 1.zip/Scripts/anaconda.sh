#!/bin/bash

#######Install anaconda
echo "*********Installing anaconda*********"
sudo yum -y install bzip2
pwsh /mnt/win/OneClickTools/wget-files.ps1 -url "https://repo.anaconda.com/archive/Anaconda3-5.3.1-Linux-x86_64.sh"
echo "file downloaded"
bash Anaconda3-5.3.1-Linux-x86_64.sh -b -p /opt/anaconda
cd /opt/anaconda
source bin/activate
conda install -y python=3.7.6
source bin/deactivate
conda deactivate
ln -f -s /opt/anaconda/bin/python3.7 /usr/bin/python3.7
ln -f -s /opt/anaconda/bin/python3.7 /usr/local/bin/python3.7
ln -f -s /opt/anaconda/bin/pip /usr/bin/pip
ln -f -s /opt/anaconda/bin/pip /usr/local/bin/pip