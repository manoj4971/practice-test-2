#!/bin/bash

export PYTHONIOENCODING=utf8
export CLUSTER_NAME=`curl -u admin:admin -X GET -s http://localhost:8090/api/v1/clusters/ | python2 -c "import sys, json; print json.load(sys.stdin)['items'][0]['Clusters']['cluster_name']"`
export PASSWORD=admin
curl -u admin:$PASSWORD -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo": {"context" :"Stop SmartSense via REST"}, "Body": {"ServiceInfo": {"state": "INSTALLED"}}}' http://localhost:8090/api/v1/clusters/$CLUSTER_NAME/services/SMARTSENSE 